import { Component, OnInit } from '@angular/core';
//import {FeedbackForm } from './feedback.component';
@Component({
  selector: 'app-feedback',
  templateUrl: './feedback.component.html',
  styleUrls: ['./feedback.component.css']
})
export class FeedbackComponent implements OnInit {

comments;


  constructor() { }

  ngOnInit() {
  }
sendData1(data)
{
   
  this.comments=data;
}


}
