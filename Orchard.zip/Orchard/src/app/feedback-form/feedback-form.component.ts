import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FeedbackService } from "../feedback.service";

@Component({
  selector: 'app-feedback-form',
  templateUrl: './feedback-form.component.html',
  styleUrls: ['./feedback-form.component.css']
})
export class FeedbackFormComponent implements OnInit {
  name: string
  mid: string = "";
  comment: string = "";
  goals = [];
  @Output() sendData = new EventEmitter<any>();

  constructor() {
    
  }

  ngOnInit() {
  }
  display() {
    this.goals.push(this.name);
    this.goals.push(this.mid);
    this.goals.push(this.comment);
    this.sendData.emit(this.goals);

  }

  onClear() {
    this.name = '',
      this.mid = '',
      this.comment = ''
      this.goals.pop()
      this.goals.pop()
      this.goals.pop()
      this.sendData.emit(this.goals);
    
  }

}
