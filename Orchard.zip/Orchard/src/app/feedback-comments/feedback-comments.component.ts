import { Component, OnInit, Input } from '@angular/core';
import { FeedbackService } from "../feedback.service";

@Component({
  selector: 'app-feedback-comments',
  templateUrl: './feedback-comments.component.html',
  styleUrls: ['./feedback-comments.component.css']
})
export class FeedbackCommentsComponent implements OnInit {



  ngOnInit() {

  }

}
