import { Injectable } from '@angular/core';

@Injectable()
export class FeedbackService {
   goals:any[];
  constructor() { }
  setData(data:any[]){
this.goals=data;
  }
  getData(){
    return this.goals;
  }

}
