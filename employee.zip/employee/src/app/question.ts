export class Question{
    question1:string;
    option:number;
    sop1:string;
    sop2:string;
    sop3:string;
    sop4:string;
    sop5:string;
    sop6:string;
}