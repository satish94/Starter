import { Component, OnInit } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HttpClient } from "@angular/common/http";

@Component({
  selector: 'app-lead',
  templateUrl: './lead.component.html',
  styleUrls: ['./lead.component.css']
})
export class LeadComponent implements OnInit {
 campusMind: any;

  constructor(private http: HttpClient) {
    
    this.http.get('../assets/campusMind.json').subscribe((data:any)=>{  this.campusMind=data; {console.log(this.campusMind)}})
   }

  ngOnInit() {
  }

}
