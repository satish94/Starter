import { ReflectiveInjector } from '@angular/core';
class A{};
class B{};
class C{};

let injector = ReflectiveInjector.resolveAndCreate([
   { provide: C, useClass:C},
   { provide:B, useExisting:C},
   {provide:A, useExisting:C}
   ]
);
let a1=injector.get(A);
console.log(a1);
let a2 = injector.get(B);
console.log(a2);
let a3 = injector.get(C);
console.log(a3);