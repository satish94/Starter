import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
//import {routingComponents} from './app-routing.module';
import { HttpClientModule } from "@angular/common/http";
import { FormControl } from '@angular/forms';

import { AppComponent } from './app.component';
import { LoginComponent } from './login/login.component';
import { LeadComponent } from './lead/lead.component';
import { CapabilitiesComponent } from './capabilities/capabilities.component';
import { CampusmindsComponent } from './campusminds/campusminds.component';
//import { AppRoutingModule } from "./app-routing.module";
import { FormsModule } from '@angular/forms';
import { NewsService } from './news.service';


const routes: Routes = [

   {
    path: '',
    component: LoginComponent
  },
  
    {
    path: 'login',
    component: LoginComponent
  },

  {
    path: 'lead',
    component: LeadComponent //canActivate:[LoginComponent]
  },

  {
    path: 'capabilities',
    component: CapabilitiesComponent
  },
  {
    path: 'campusminds',
    component: CampusmindsComponent, //canActivate:[LoginComponent]
  }
 ];
@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    LeadComponent,
    CapabilitiesComponent,
    CampusmindsComponent

          
    
     
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(routes)

  ],
  providers: [NewsService],
  bootstrap: [AppComponent]
  
})
export class AppModule { }
