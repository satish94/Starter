import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";

@Injectable()
export class NewsService {
   url:any[];
  constructor(private http:HttpClient) { 
   
   
}

}
