import { Component, OnInit } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CanActivate } from '@angular/router';
import { Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  uname;
  psw;
  login:boolean=false;
  constructor(private router: Router) { }
  logindata(){
     if(this.uname=='admin' && this.psw==1234)
      this.login=true;
    else this.login = false;
    
   }
    logoutdata(){
  
     this.login = false;
    
   }
   canActivate() {
       if(this.uname=='admin' && this.psw=='1234') return true;
       else{
      this.router.navigate(['/login']);
      return false;
       }
      //return false;
   }

  ngOnInit() {
  }

}
