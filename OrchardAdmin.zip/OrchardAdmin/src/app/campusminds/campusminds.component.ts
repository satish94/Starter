import { Component, OnInit } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import {NewsService } from '../news.service';
@Component({
  selector: 'app-campusminds',
  templateUrl: './campusminds.component.html',
  styleUrls: ['./campusminds.component.css']
})
export class CampusmindsComponent implements OnInit {
 campusMind: any;
 items:any;
 stream:any[];

  constructor(private http: HttpClient) {
    this.http.get('../assets/campusMind.json').subscribe((data)=>{this.campusMind= data ; console.log(data)})
    console.log(this.campusMind);
    //this.campusMind.filter
    //this.items= Array.of(this.campusMind);
    
    
   }

  ngOnInit() {
      

  }

}
