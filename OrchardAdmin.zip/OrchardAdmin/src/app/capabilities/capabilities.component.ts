import { Component, OnInit } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HttpClient } from "@angular/common/http";

@Component({
  selector: 'app-capabilities',
  templateUrl: './capabilities.component.html',
  styleUrls: ['./capabilities.component.css']
})
export class CapabilitiesComponent implements OnInit {
  capabilities:any;
  constructor(private http: HttpClient) { 
    this.http.get('../assets/capabilities.json').subscribe((data:any)=>{this.capabilities=data; console.log(this.capabilities)})
  }

  ngOnInit() {
  }

}
