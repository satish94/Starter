import { ForgetpasswordService } from './forgetpassword/forgetpassword.service';
import { ForgetPasswordGuard } from './shared/guard/forgetpassword.gaurd';

import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { HttpModule } from "@angular/http";
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AuthGuard } from './shared';
import { LogInService } from './login/login.service';
import { Routes, RouterModule } from '@angular/router';
import { MatTableModule } from '@angular/material';


// AoT requires an exported function for factories

import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


import { MatInputModule, MatSelectModule,MatSnackBarModule } from '@angular/material';

export function createTranslateLoader(http: HttpClient) {
    return new TranslateHttpLoader(http, './assets/i18n/', '.json');
}

@NgModule({
    imports: [
        NgbModule.forRoot(),
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        MatTableModule,
        BrowserModule,
        MatInputModule,
        MatSelectModule,
        MatSnackBarModule,
        BrowserAnimationsModule,
        HttpClientModule,
        HttpModule,
        NgbModule.forRoot(),
        TranslateModule.forRoot({
            loader: {
                provide: TranslateLoader,
                useFactory: (createTranslateLoader),
                deps: [HttpClient]
            }
        }),
        AppRoutingModule,
        NgbModule.forRoot(),
        RouterModule,
    ],
    declarations: [AppComponent],
    providers: [
        AuthGuard,
        LogInService,
        ForgetPasswordGuard,
        ForgetpasswordService,
    ],
    bootstrap: [AppComponent]
})
export class AppModule { }
