export class SendNewPassword{
    email: String;
    newPassword: String;

    constructor(){

    }
}