import { ForgetPasswordGuard } from './../shared/guard/forgetpassword.gaurd';
import { ConfirmPasswordComponent } from './confirmpassword/confirmpassword.component';
import { ConfirmEmailComponent } from './confirmemail/confirmemail.component';
import { ForgetPasswordComponent } from './forgetpasswod.component';
import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';

const routes: Routes = [
    {
        path: '',
        component: ForgetPasswordComponent,
        children: [
            {
                path: "",
                redirectTo: "confirmcomponent"
            },
            {
                path: "confirmcomponent",
                component: ConfirmEmailComponent
            },
            {
                path: "confirmpassword",
                component: ConfirmPasswordComponent,
                canActivate: [
                    ForgetPasswordGuard,
                ]
            }
        ]
    },
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ForgetPasswordRoutingModule { }
