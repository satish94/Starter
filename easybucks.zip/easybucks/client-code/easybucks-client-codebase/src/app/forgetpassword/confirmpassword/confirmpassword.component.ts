import { SendNewPassword } from './../sendnewpassword';
import { Validators } from '@angular/forms';
import { FormBuilder, FormControl } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { ForgetpasswordService } from './../forgetpassword.service';
import { Component, OnInit, SimpleChanges, Input } from '@angular/core';

@Component({
    selector: 'app-confirmpassword',
    templateUrl: './confirmpassword.component.html',
    styleUrls: ['./confirmpassword.component.scss']
})
export class ConfirmPasswordComponent implements OnInit {

    email: any;
    OTP: Number;
    changepasswordform: FormGroup = new FormGroup({
        otp: new FormControl(null, [Validators.required]),
        newpassword: new FormControl(null, [Validators.required, Validators.pattern('((?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%&]).{8,15})')]),
        confirmpassword: new FormControl(null, [Validators.required])
    });
    wrongOtp: Boolean = false;
    wrongPwd: Boolean = false;
    sendNewPassword: SendNewPassword = new SendNewPassword();
    result: String;
    resultshow:boolean = false;

    changePwd: {
        otp: 0,
        newpassword: "",
        confirmpassword: ""
    };

    get otp() {
        return this.changepasswordform.get('otp');
    }

    get newpassword() {
        return this.changepasswordform.get('newpassword');
    }
    get confirmpassword() {
        return this.changepasswordform.get('confirmpassword');
    }



    constructor(private forgetPasswordServ: ForgetpasswordService, private formBuilder: FormBuilder) {
        this.email = this.forgetPasswordServ.getEmail();

        this.forgetPasswordServ.getOTP(this.email).subscribe(
            otp => {
                this.OTP = otp;
            }
        )

    }

    ngOnInit() {
    }


    onPasswordChange() {
        this.wrongPwd = false;
        this.wrongOtp = false;
        this.changePwd = this.changepasswordform.value;
        if (this.changePwd.otp == this.OTP) {
            if (this.changePwd.newpassword === this.changePwd.confirmpassword) {
                this.sendNewPassword.email = this.email;
                this.sendNewPassword.newPassword = this.changePwd.newpassword;
                this.forgetPasswordServ.sendNewPassword(this.sendNewPassword).subscribe(
                    result => {
                        if (result == 1) {
                            this.resultshow = true;
                            this.result ="Password changed successfully";
                        }
                        else {
                            this.resultshow = true;
                            this.result = "Cannot change password";
                        }
                    }
                )
            }
            else {
                this.wrongPwd = true;
            }
        }
        else {
            this.wrongOtp = true;
        }
    }

}