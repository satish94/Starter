import { Router } from '@angular/router';
import { ForgetpasswordService } from './../forgetpassword.service';
import { Validators, FormBuilder, FormControl } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { Component, OnInit } from '@angular/core';
@Component({
    selector: 'app-confirmemail',
    templateUrl: './confirmemail.component.html',
    styleUrls: ['./confirmemail.component.scss']
})
export class ConfirmEmailComponent implements OnInit {

    email : any;

    emailform: FormGroup ;

    constructor(private formBuilder: FormBuilder, private forgetPasswordServ: ForgetpasswordService, private router: Router,) { 
        this.emailform = formBuilder.group({
            emailtxt: new FormControl(null, [Validators.required, Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.(com|in|net|co)')]),
        }) ;
    }

    ngOnInit() { }

    emailConfirmation(){

        this.email = this.emailform.value;

        this.forgetPasswordServ.setEmail(this.email.emailtxt);

        this.router.navigate(['/forgetpassword/confirmpassword']);

    }
}