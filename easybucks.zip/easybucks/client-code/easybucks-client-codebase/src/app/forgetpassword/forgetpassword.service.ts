import { SendNewPassword } from './sendnewpassword';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { Subject } from 'rxjs/Subject';
import { Injectable } from '@angular/core';
import { post_header, EasyBucksConstants } from '../EasyBucks';

@Injectable()
export class ForgetpasswordService {

    private email : String;

    private _options;

    constructor(
        private httpClient: HttpClient
    ){
            this._options = new RequestOptions({ headers: post_header});
    }

    setEmail(email: string){
        this.email = email;
    }

    getEmail(): String{
        return this.email;
    }

    getOTP(email: String): Observable<any>{
        return this.httpClient.post(EasyBucksConstants.baseUrl+"login/sendemail", email, this._options );
    }

    sendNewPassword(sendNewPassword: SendNewPassword): Observable<any>{
        return this.httpClient.post(EasyBucksConstants.baseUrl+"login/changepassword", sendNewPassword, this._options);
    }


}