import { Headers } from '@angular/http';

export const EasyBucksConstants = {
    baseUrl: 'https://easybucks-api-qa-jvn.azurewebsites.net/easybucks/',
};


const headers: Headers = new Headers();
headers.append('Content-Type', 'application/json');
headers.append('Access-Control-Allow-Origin', '*');
headers.append('Access-Control-Allow-Methods', 'POST, GET, DELETE, OPTIONS');
headers.append('Access-Control-Allow-Headers', 'Origin, X-Requested-With, Content-Type, Accept');

export const post_header = headers;
