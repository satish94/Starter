import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { EasyBucksConstants } from "../../EasyBucks";
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { post_header } from '../../EasyBucks';

@Injectable()
export class ManageusersService {
 private _baseUrl = EasyBucksConstants.baseUrl ;
    options ;
  constructor(private http : HttpClient) { 
    this.options = new RequestOptions({ headers: post_header});
  }

  getAllUsers()
  {
    return this.http.get(this._baseUrl +"seekassistance/allusers");
    //return this.http.get("http://localhost:8081/easybucks/seekassistance/allusers");
  }

  deleteUser(id)
  {
    return this.http.delete(this._baseUrl +"signup/deleteuser/"+id);
    //return this.http.delete("http://localhost:8081/easybucks/signup/deleteuser/"+id);
  }

  getAllAdvisorRequests()
  {
    return this.http.get(this._baseUrl +"signup/allAdvisorRequests");
    //return this.http.get("http://localhost:8081/easybucks/signup/allAdvisorRequests");
  }

  deleteAdvisorRequest(id)
  { 
    return this.http.delete(this._baseUrl +"signup/deleteAdvisorRequest/"+id);
    //return this.http.delete("http://localhost:8081/easybucks/signup/deleteAdvisorRequest/"+id);
  }

}
