import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';
import { ManageusersService } from "./manageusers.service";
import { Router, NavigationEnd } from "@angular/router";
import { Profile } from "../profile/profile";
import { ProfileService } from "../profile/profile.service";

@Component({
  selector: 'app-manage-users',
  templateUrl: './manage-users.component.html',
  styleUrls: ['./manage-users.component.scss'],
  animations: [routerTransition()]
})
export class ManageUsersComponent implements OnInit {

  alladvisors: any[];
  allusers: any[];
  allRequests: any[];
  isEmpty:boolean;
  message:string;
  profile = new Profile(null, null, null, '', '', null, null, '', '', '');

  constructor(private manageusersservice:ManageusersService,private router:Router, private profileService:ProfileService) 
  { 
    this.router.routeReuseStrategy.shouldReuseRoute = function(){
        return false;
    }
    this.router.events.subscribe((evt) => {
        if (evt instanceof NavigationEnd) {
           
           this.router.navigated = false;
           
           window.scrollTo(0, 0);
        }
    });
  }

  ngOnInit() {

    this.manageusersservice.getAllUsers().subscribe((data:any[])=>{
             this.allusers=data;
             this.alladvisors = this.allusers.filter((elem)=>{
                   return elem.userRole.roleName == 'advisor';
              })
              
        }
        )

        this.manageusersservice.getAllAdvisorRequests().subscribe((data:any[])=>{
            this.allRequests=data;
            if(this.allRequests.length==0)
              {
                  this.isEmpty = false;
              }
              else
              {
                this.isEmpty = true;
              }
        }
        )
  }

  deleteAdvisor(id)
  {
    this.message='Advisor denied successfully';
    this.manageusersservice.deleteUser(id).subscribe(
      res=>{}
    )
    this.callSnackBar();
  }

  approveAdvisor(em)
  {
    this.message = 'Advisor request approved successfully';
    for (let user of this.allusers)
      {
        if(user.userEmail==em)
        {
          this.profile.RoleId=2;
          this.profile.UserName = user.userName;
          this.profile.UserId=user.userId;
          this.profile.UserEmail = user.userEmail;
          this.profile.UserPassword = user.userPassword;
        }
      }
      
      this.profileService.updateProfile(this.profile).subscribe(
        res=>{
          for(let re of this.allRequests)
          {
            if(re.email == em)
            {
              this.manageusersservice.deleteAdvisorRequest(re.advisorRequestId).subscribe(res=>{});
            }
          }
        }
      )
      this.callSnackBar();
      
  }

  declineAdvisor(id)
  {
    this.message="Advisor request declined successfully";
    this.manageusersservice.deleteAdvisorRequest(id).subscribe(res=>{});
    this.callSnackBar(); 
  }

  callSnackBar()
    {
        var x = document.getElementById("snackbar")    
        x.className = "show";
        setTimeout(function(){ x.className = x.className.replace("show", ""); }, 2500); 
        setTimeout(() => {this.router.navigate(['/manag-users']);},2750);
    }
}
