import { ManageUsersModule } from './manage-users.module';

describe('ManageUsersModule', () => {
  let manageusersModule: ManageUsersModule;

  beforeEach(() => {
    manageusersModule = new ManageUsersModule();
  });

  it('should create an instance', () => {
    expect(manageusersModule).toBeTruthy();
  });
});
