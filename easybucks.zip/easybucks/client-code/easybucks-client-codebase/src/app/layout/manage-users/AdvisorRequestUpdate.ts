export class AdvisorRequestUpdate
{
    advisorRequestId:number;
    email:string;
    status:string;

    constructor(advisorRequestId:number,email:string,status:string)
    {
        this.email=email;
        this.status=status;
        this.advisorRequestId=advisorRequestId;
    }

    set Email(email:string)
    {
        this.email=email;
    }
     set Status(status:string)
     {
         this.status=status;
     }

     set AdvisorRequestId(advisorRequestId:number)
     {
         this.advisorRequestId=advisorRequestId;
     }
}