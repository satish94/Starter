import { PageHeaderModule } from './../../shared/modules/page-header/page-header.module';
import { ManageUsersComponent } from './manage-users.component';
import { ManageUsersRoutingModule } from './manage-users-routing.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTabsModule } from "@angular/material/tabs";
import { ManageusersService } from "./manageusers.service";
import { ProfileService } from "../profile/profile.service";

@NgModule({
    declarations: [
        ManageUsersComponent
    ],
    imports: [ CommonModule, ManageUsersRoutingModule, PageHeaderModule,MatTabsModule ],
    exports: [],
    providers: [ManageusersService,ProfileService],
})
export class ManageUsersModule {}