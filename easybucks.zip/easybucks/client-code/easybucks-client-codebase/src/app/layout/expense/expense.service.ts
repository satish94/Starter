import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { post_header, EasyBucksConstants } from "../../EasyBucks";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs/Observable";

@Injectable()
export class ExpenseService {
    private _baseUrl = EasyBucksConstants.baseUrl ;
    private _options ;

     constructor(private http: HttpClient) {
        this._options = new RequestOptions({ headers: post_header});
     }
     getExpenses(id:any): Observable<any> {
        return this.http.get(this._baseUrl+"expense/"+id+"/all");
}

 addExpense(expense: any,id:any): Observable<any> {
    return this.http.post( this._baseUrl + 'expense/add/'+id, expense, this._options)
  }

  deleteExpense(uid :any,eid:any)
  {
      return this.http.delete(this._baseUrl+'expense/delete/'+uid+'/'+eid);
  }
  updateExpense(expense : any)
  {
      return this.http.put(this._baseUrl+'expense/update',expense,this._options);
  }

  getUser(id:any)
  {
      return this.http.get(this._baseUrl+'signup/'+id);
  }

}