import { Component, OnInit } from '@angular/core';
import { routerTransition } from "../../router.animations";
import { User } from "../../user/user";
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { ExpenseService } from "./expense.service";
import { Subject } from "rxjs/Subject";
import { debounceTime } from "rxjs/operator/debounceTime";
import { MatSnackBar } from "@angular/material/snack-bar";


@Component({
  selector: 'app-expense',
  templateUrl: './expense.component.html',
  styleUrls: ['./expense.component.scss'],
  animations: [routerTransition()]
})
export class ExpenseComponent implements OnInit {

  loggedInUser: User = new User();
  userDetail: any;
  ExpenseForm: FormGroup;
  closeResult: string;
  total: number = 0;
  balance:number ;
  monthlySalary: number;
  public isminus = true;
  modalSet:any;

  constructor(fb: FormBuilder, private modalService: NgbModal, private expenseService: ExpenseService, private snackBar: MatSnackBar) {
    this.userDetail = sessionStorage.getItem("userDetail");
    this.loggedInUser = JSON.parse(this.userDetail);
    this.getExpenses();
    this.getUser();
    this.monthlySalary=(this.loggedInUser.userIncome) / 12;
    this.balance = this.monthlySalary;
    this.ExpenseForm = fb.group({
      amount: ['',
        [Validators.required,
        Validators.pattern('[0-9 ]+')
        ]],
      description: ['', [Validators.required, Validators.pattern('[a-zA-Z&,. ]+')]],
    });
  }

  expenses: any[] = [];
  
  ngOnChanges() {
    this.ExpenseForm.reset();
    this.calculateTotalExpense();
  }

  ngOnInit() {
   
  }

  open(content) {
    this.modalSet=this.modalService.open(content);
    this.modalSet.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    });
  }

  getExpenses() {
    this.expenseService.getExpenses(this.loggedInUser.userId)
      .subscribe(
      expenses => {
        this.expenses = expenses;
        this.calculateTotalExpense();
      }
      )
  }

   openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });
}

  calculateTotalExpense() {
    this.total=0;
    this.balance=this.monthlySalary;
    this.expenses.forEach(expense => {
      this.total += expense.amount;
      this.balance-=expense.amount;
      this.changeColor();
    })

  }

   onSubmit() {
     console.log(this.ExpenseForm.value);
    this.expenseService.addExpense(this.ExpenseForm.value,this.loggedInUser.userId)
      .subscribe(responses => {
      }) ;
      this.expenses.push(this.ExpenseForm.value);
      this.calculateTotalExpense();
      this.ExpenseForm.reset();
      this.modalSet.close();
      this.openSnackBar('Expense Added Successfully','') ;
}

  deleteExpense(expense:any )
  {
    this.expenseService.deleteExpense(this.loggedInUser.userId,expense.id)
    .subscribe(response=>{

    });
    this.expenses.splice(this.expenses.indexOf(expense), 1);
     this.openSnackBar('Expense Deleted Successfully','') ;
    this.total-=expense.amount;
    this.balance+=expense.amount;
    this.changeColor();
  }

  updateExpense(expense:any)
  {
    this.expenseService.updateExpense(expense)
    .subscribe(response=>{

    });
  }
  changeColor()
  {
    if(this.balance<0)
    {
      this.isminus=true;
    }
    else{
      this.isminus=false;
    }
  }
  data:any;
  getUser()
  {
    this.expenseService.getUser(this.loggedInUser.userId)
    .subscribe(response=>{
        this.data=response;
       let userDetail = JSON.stringify(response);
       sessionStorage.setItem("userDetail", userDetail);
       this.loggedInUser = JSON.parse(sessionStorage.getItem("userDetail"));
      }) ;
      this.changeColor() ;
  }
}

