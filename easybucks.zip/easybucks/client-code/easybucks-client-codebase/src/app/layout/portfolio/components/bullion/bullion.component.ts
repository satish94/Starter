import { PortfolioService } from './../../portfolio.service';
import { ActivatedRoute, Router } from '@angular/router';
import { User } from './../../../../user/user';
import { Validators } from '@angular/forms';
import { FormControl } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { Component, OnInit, ViewChild } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-bullion',
  templateUrl: './bullion.component.html',
  styleUrls: ['./bullion.component.scss']
})
export class BullionComponent implements OnInit {

  closeResult: string;
  @ViewChild('content') private content ;
  bullionForm : FormGroup = new FormGroup({
    quantity: new FormControl('', [Validators.required,Validators.min(1)])
  })
  form:any;
  loggedInUser:User;
  public prodId;
  exception : boolean = false;
  modalData: any ;

  get quantity(){
    return this.bullionForm.get("quantity");
  }

  constructor(
    private modalService: NgbModal,
    private route: ActivatedRoute,
     private portfolioServ : PortfolioService,
     private router : Router
     ) {
       this.prodId = route.snapshot.paramMap.get("id");
      }

  ngOnInit() {
    this.open(this.content) ;
    let userDetails = sessionStorage.getItem("userDetail");
    this.loggedInUser = JSON.parse(userDetails);
  }
  open(content) {
    this.modalData = this.modalService.open(content) ;
    this.modalData.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    });
  }

  
  onClick(){
    this.form = this.bullionForm.value
    this.portfolioServ.addBullionsPortfolio(this.prodId, this.loggedInUser.userId,this.form.quantity)
    .subscribe(
      result => {
        if(result == 2){
          this.exception = true;
        }
        else{
          this.closeModal();
        }
      }
    )
  }

  
  closeModal(){
    this.modalData.close() ;
    this.router.navigate(['/home']) ;
  }

}
