import { Injectable } from '@angular/core';
import { EasyBucksConstants } from "../../../EasyBucks";
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { User } from "../../../user/user";

@Injectable()
export class AdvisorService {

   private _url = EasyBucksConstants.baseUrl ;
   loggedInUser: User = new User();
  constructor(private http: HttpClient) {
    let userDetail = sessionStorage.getItem("userDetail");
        this.loggedInUser = JSON.parse(userDetail);
   }

  getQueries(): Observable<any>{
    return this.http.get(this._url+"seekassistance/alldetails") ;
  }

  getAppointments(): Observable<any>{
    return this.http.get(this._url+"seekassistance/allAppointments") ;
  }

}
