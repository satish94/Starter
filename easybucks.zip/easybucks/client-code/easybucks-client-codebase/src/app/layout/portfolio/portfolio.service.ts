import { getTestBed } from '@angular/core/testing';
import { EasyBucksConstants } from './../../EasyBucks';
import { Observable } from 'rxjs/Observable';
import { RequestOptions } from '@angular/http';
import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { post_header } from "../../EasyBucks";

@Injectable()
export class PortfolioService {

    private _options;

    constructor(
        private httpClient: HttpClient
    ){
        this._options = new RequestOptions({ headers: post_header});
    }

    addStocksPortfolio(prodId: number, userId: number, noOfStocks:number):Observable<any>{
        return this.httpClient.get(EasyBucksConstants.baseUrl+ "/portfolio/addstocks/"+prodId+"/"+userId+"/"+noOfStocks, this._options);
    }

    addBankingPortfolio(prodId: number, userId: number, noOfMonths:number,amount:number):Observable<any>{
        return this.httpClient.get(EasyBucksConstants.baseUrl+ "/portfolio/addbanking/"+prodId+"/"+userId+"/"+noOfMonths+"/"+amount, this._options);
    }

    addBullionsPortfolio(prodId: number, userId: number, quantity:number):Observable<any>{
        return this.httpClient.get(EasyBucksConstants.baseUrl+ "/portfolio/addbullion/"+prodId+"/"+userId+"/"+quantity, this._options);
    }

    addMFPortfolio(prodId: number, userId: number, quantity:number):Observable<any>{
        return this.httpClient.get(EasyBucksConstants.baseUrl+ "/portfolio/addmfportfolio/"+prodId+"/"+userId+"/"+quantity, this._options);
    }

    getPortfolio(userId : number): Observable<any>{
        return this.httpClient.get(EasyBucksConstants.baseUrl+"/portfolio/getPortfolio/"+userId , this._options);
    }


    deleteStocksPort(stocksPortId:number,userId:number):Observable <any>{
        return this.httpClient.get(EasyBucksConstants.baseUrl+"/portfolio/deleteStocks/"+stocksPortId+"/"+userId,this._options);
    }

    deleteBankingPort(bankingPortId:number,userId:number):Observable <any>{
        return this.httpClient.get(EasyBucksConstants.baseUrl+"/portfolio/deletebanking/"+bankingPortId+"/"+userId,this._options);
    }

    deleteBullionsPort(bullionsPortId:number,userId:number):Observable <any>{
        return this.httpClient.get(EasyBucksConstants.baseUrl+"/portfolio/deletebullions/"+bullionsPortId+"/"+userId,this._options);
    }

    deleteMFPort(mfPortId:number,userId:number):Observable <any>{
        return this.httpClient.get(EasyBucksConstants.baseUrl+"/portfolio/deletemf/"+mfPortId+"/"+userId,this._options);
    }

}