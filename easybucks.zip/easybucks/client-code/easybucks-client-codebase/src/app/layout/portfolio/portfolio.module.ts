import { PortfolioService } from './portfolio.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PortfolioRoutingModule } from './portfolio-routing.module';
import { PortfolioComponent } from './portfolio.component';
import { PageHeaderModule } from './../../shared';
import { CategoryStatsComponent } from './category-stats/category-stats.component';
import { BullionComponent } from './components/bullion/bullion.component';
import { MfComponent } from './components/mf/mf.component';
import { StocksComponent } from './components/stocks/stocks.component';
import { BankingComponent } from './components/banking/banking.component';
import { NavComponent } from './components/nav/nav.component';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { AdvisorDashboardComponent } from './advisor-dashboard/advisor-dashboard.component';
import { AdminService } from './admin-dashboard/admin.service';


import { AdvisorService } from './advisor-dashboard/advisor.service';

import {
    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatStepperModule,
} from '@angular/material';
import { StocksPortfolioComponent } from './components/stocks-portfolio/stocks-portfolio.component';
import { MfPortfolioComponent } from './components/mf-portfolio/mf-portfolio.component';
import { BankingPortfolioComponent } from './components/banking-portfolio/banking-portfolio.component';
import { BullionsPortfolioComponent } from './components/bullions-portfolio/bullions-portfolio.component';

@NgModule({
    imports: [CommonModule, PortfolioRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    PageHeaderModule,
    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatStepperModule,
    ],
    declarations: [PortfolioComponent, CategoryStatsComponent, BullionComponent, MfComponent, StocksComponent, BankingComponent, NavComponent, AdminDashboardComponent, AdvisorDashboardComponent, StocksPortfolioComponent, MfPortfolioComponent, BankingPortfolioComponent, BullionsPortfolioComponent],
    providers: [AdminService, AdvisorService, PortfolioService]
})
export class PortfolioModule { }
