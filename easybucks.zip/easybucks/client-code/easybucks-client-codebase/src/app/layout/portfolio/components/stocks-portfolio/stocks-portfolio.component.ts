import { User } from './../../../../user/user';
import { PortfolioService } from './../../portfolio.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-stocks-portfolio',
  templateUrl: './stocks-portfolio.component.html',
  styleUrls: ['./stocks-portfolio.component.scss']
})
export class StocksPortfolioComponent implements OnInit {

  loggedInUser: User;
  stocksPort:any [];

  constructor(
    private portfolioServ : PortfolioService
  ) { 
    let userDetail = sessionStorage.getItem("userDetail");
    this.loggedInUser = JSON.parse(userDetail);
    this.getPortfolio();
  }

  ngOnInit() {
  }

  getPortfolio() {
    this.portfolioServ.getPortfolio(this.loggedInUser.userId)
      .subscribe(
      result => {
        this.getBanking(result.stocksPort);
      }
      )

  }

  getBanking(result: any) {
    this.stocksPort = result.reverse();
    this.getMaturityValue();
  }

  getMaturityValue(){
    let item : any;
    for(item of this.stocksPort){
      item.maturityValue = (item.stocksProd.currTradingPrice - item.purchasePrice)*item.noOfShares;
    }
  }

  onDelete(stocksPortId: number){
    this.portfolioServ.deleteStocksPort(stocksPortId, this.loggedInUser.userId)
    .subscribe(
      result =>{
        if(result == 1){
          this.getPortfolio();
        }
      }
    )
  }

}
