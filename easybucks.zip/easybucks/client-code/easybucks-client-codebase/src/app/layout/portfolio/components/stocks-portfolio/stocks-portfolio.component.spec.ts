import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { StocksPortfolioComponent } from './stocks-portfolio.component';

describe('StocksPortfolioComponent', () => {
  let component: StocksPortfolioComponent;
  let fixture: ComponentFixture<StocksPortfolioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ StocksPortfolioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(StocksPortfolioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
