import { Injectable } from '@angular/core';
import { EasyBucksConstants } from "../../../EasyBucks";
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';

@Injectable()
export class AdminService {

  private _url = EasyBucksConstants.baseUrl ;

  constructor(private http: HttpClient) { }

  getUsers(): Observable<any>{
      return this.http.get(this._url+"signup/getusers") ;
  }

  getQueries(): Observable<any>{
    return this.http.get(this._url+"seekassistance/alldetails") ;
  }

  getRequests(): Observable<any>{
    return this.http.get(this._url+"signup/allAdvisorRequests") ;
  }
}
