import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';
import { User } from "../../user/user";

@Component({
    selector: 'app-portfolio',
    templateUrl: './portfolio.component.html',
    styleUrls: ['./portfolio.component.scss'],
    animations: [routerTransition()]
})
export class PortfolioComponent implements OnInit {

    loggedInUser: User = new User();
    role:any;
    investor: boolean ;
    advisor:boolean ;
    admin:boolean ;
    constructor() {}

    ngOnInit() {
        let userDetail = sessionStorage.getItem("userDetail");
        this.loggedInUser = JSON.parse(userDetail);
        this.role = this.loggedInUser.userRole.roleName;
        if (this.role == "investor")
        {
            this.investor = true;
            this.admin = false;
            this.advisor = false;
        }

        if (this.role == "admin")
        {
            this.investor = false;
            this.admin = true;
            this.advisor = false;
        }
        if(this.role == "advisor")
        {
             this.investor = false;
            this.admin = false;
            this.advisor = true;
        }
    }
}
