import { Component, OnInit } from '@angular/core';
import { User } from "../../../user/user";
import { AdvisorService } from './advisor.service';
import Chart from 'chart.js';

@Component({
  selector: 'app-advisor-dashboard',
  templateUrl: './advisor-dashboard.component.html',
  styleUrls: ['./advisor-dashboard.component.scss']
})
export class AdvisorDashboardComponent implements OnInit {
  loggedInUser: User = new User();
  answered_count = 0;
  pending_count = 0;
  display: any ;
  pendingAppointment_count = 0 ;
  approvedAppointment_count = 0 ;
  constructor(private advisorService: AdvisorService) {
    this.getQueries() ;
    this.getAppointments() ;
   }

  ngOnInit() {
    let userDetail = sessionStorage.getItem("userDetail");
    this.loggedInUser = JSON.parse(userDetail);
  }

  getQueries(){
    this.advisorService.getQueries().subscribe(
      result => {
        this.getQueryCount(result);
      }
    );
  }

  getQueryCount(queries: any){
    let item: any
    for (item of queries) {
      console.log(item.status) ;
      if (item.status === 'approved' && item.advisorId===this.loggedInUser.userId) {
        this.pending_count += 1;
      }
      if (item.status === 'answered'&& item.advisorId===this.loggedInUser.userId) {
        this.answered_count += 1;
      }
    }
    this.display = `<canvas id="queriesChart"></canvas>`;
    document.getElementById("querypie").innerHTML += this.display;
    var ctx = document.getElementById("queriesChart");
    var queriesChart = new Chart(ctx, {
      type: 'pie',
      data: {
        datasets: [{
          data: [
            this.answered_count,
            this.pending_count 
          ],
          backgroundColor: [
            '#3cba9f',
            'crimson'
          ],
        }],
        labels: [
          "Answered",
          "Pending"
        ]
      },
      options: {
        responsive: true,
        title: {
          display: true,
          text: 'Investor Queries Status'
        }
      }
    });
  }

  getAppointments(){
    this.advisorService.getAppointments().subscribe(
      result => {
        this.getAppointmentCount(result);
      }
    );
  }

  getAppointmentCount(appointments: any){
    let item: any
    for (item of appointments) {
      console.log(item.status) ;
      if (item.status === 'approved' && item.advisorId===this.loggedInUser.userId) {
        this.approvedAppointment_count += 1;
      }
      if (item.status === 'pending'&& item.advisorId===this.loggedInUser.userId) {
        this.pendingAppointment_count += 1;
      }
    }
    this.display = `<canvas id="appointmentChart"></canvas>`;
    document.getElementById("appointmentpie").innerHTML += this.display;
    var ctx = document.getElementById("appointmentChart");
    var appointmentChart = new Chart(ctx, {
      type: 'pie',
      data: {
        datasets: [{
          data: [
            this.approvedAppointment_count,
            this.pendingAppointment_count 
          ],
          backgroundColor: [
            '#3cba9f',
            'crimson'
          ],
        }],
        labels: [
          "Approved",
          "Pending"
        ]
      },
      options: {
        responsive: true,
        title: {
          display: true,
          text: 'Appointment Status'
        }
      }
    });
  }

}
