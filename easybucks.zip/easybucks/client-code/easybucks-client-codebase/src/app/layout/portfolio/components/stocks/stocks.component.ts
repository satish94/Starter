import { PortfolioService } from './../../portfolio.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormControl, Validators } from '@angular/forms';
import { FormGroup } from '@angular/forms';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { User } from "../../../../user/user";
@Component({
  selector: 'app-stocks',
  templateUrl: './stocks.component.html',
  styleUrls: ['./stocks.component.scss']
})
export class StocksComponent implements OnInit {

  closeResult: string;
  @ViewChild('content') private content ;
  public prodId;
  exception : boolean;
  loggedInUser:User;

  form:any;
  modalData: any ;
  
  stocksPort: FormGroup = new FormGroup({
    noOfStocks: new FormControl('', [Validators.required,Validators.min(1)])
  })

get noOfStocks(){
  return this.stocksPort.get("noOfStocks");
}

  constructor(private modalService: NgbModal,
   private route: ActivatedRoute,
    private portfolioServ : PortfolioService,
    private router: Router 
    ) {
    this.prodId = this.route.snapshot.paramMap.get("id");
   }

  ngOnInit() {
    this.open(this.content) ;
    let userDetails = sessionStorage.getItem("userDetail");
    this.loggedInUser = JSON.parse(userDetails);
  }
  open(content) {
    this.modalData = this.modalService.open(content) ;
    this.modalData.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    });
  }

  onClick(){
    this.form = this.stocksPort.value;
    this.portfolioServ.addStocksPortfolio(this.prodId, this.loggedInUser.userId, this.form.noOfStocks)
    .subscribe(
      result => {
        console.log(result);
        if(result == 2){
          this.exception = true;
        }
        else{
          this.closeModal();
        }
      }
    )
  }

  closeModal(){
    this.modalData.close() ;
    this.router.navigate(['/home']) ;
  }

}
