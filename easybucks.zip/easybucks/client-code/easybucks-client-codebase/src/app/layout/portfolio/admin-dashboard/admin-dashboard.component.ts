import { Component, OnInit } from '@angular/core';
import { AdminService } from './admin.service';
import Chart from 'chart.js';
import { Subscription } from 'rxjs/Subscription';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.scss']
})
export class AdminDashboardComponent implements OnInit {

  investor_count = 0;
  advisor_count = 0;
  display: any;
  approved_count = 0;
  answered_count = 0;
  pending_count = 0;
  request_count = 0 ;
  constructor(private adminService: AdminService) {
    this.getUsers();
    this.getQueries() ;
  }

  ngOnInit() {
  }

  getUsers() {
    this.adminService.getUsers().subscribe(
      result => {
        this.getCount(result);
      }
    );
  }

  getCount(users: any) {
    let item: any
    for (item of users) {
      if (item.userRole.roleName === 'investor') {
        this.investor_count += 1;
      }
      if (item.userRole.roleName === 'advisor') {
        this.advisor_count += 1;
      }
    }
     this.getRequests() ;
    this.display = `<canvas id="usersChart"></canvas>`;
    document.getElementById("userpie").innerHTML += this.display;
    var ctx = document.getElementById("usersChart");
    var usersChart = new Chart(ctx, {
      type: 'pie',
      data: {
        datasets: [{
          data: [
            this.investor_count,
            this.advisor_count
          ],
          backgroundColor: [
            '#3cba9f',
            '#3e95cd'
          ],
        }],
        labels: [
          "Investors",
          "Advisors",
        ]
      },
      options: {
        responsive: true,
        title: {
          display: true,
          text: 'Users Statistics'
        }
      }
    });
  }

  getQueries() {
    this.adminService.getQueries().subscribe(
      result => {
        this.getQueryCount(result);
      }
    );
  }

  getQueryCount(queries: any) {
    let item: any
    for (item of queries) {
      console.log(item.status) ;
      if (item.status === 'approved') {
        this.approved_count += 1;
      }
      if (item.status === 'answered') {
        this.answered_count += 1;
      }
      if (item.status === 'pending') {
        this.pending_count += 1;
      }
    }
    this.display = `<canvas id="queriesChart"></canvas>`;
    document.getElementById("queryPie").innerHTML += this.display;
    var ctx = document.getElementById("queriesChart");
    var queriesChart = new Chart(ctx, {
      type: 'pie',
      data: {
        datasets: [{
          data: [
            this.approved_count,
            this.answered_count,
            this.pending_count 
          ],
          backgroundColor: [
            '#3cba9f',
            '#3e95cd',
            'crimson'
          ],
        }],
        labels: [
          "Answered",
          "Approved",
          "Pending"
        ]
      },
      options: {
        responsive: true,
        title: {
          display: true,
          text: 'Investor Queries Status'
        }
      }
    });
  }
  getRequests(){
    this.adminService.getRequests().subscribe(
      response =>{
        this.getRequestChart(response) ;
      }
    ) ;
  }

  getRequestChart(response){
    this.request_count = response.length ;
    this.display = `<canvas id="requestChart"></canvas>`;
    document.getElementById("requestPie").innerHTML += this.display;
    var ctx = document.getElementById("requestChart");
    var requestChart = new Chart(ctx, {
      type: 'pie',
      data: {
        datasets: [{
          data: [
            this.request_count,
            this.advisor_count 
          ],
          backgroundColor: [
            '#e8c3b9',
            '#3cba9f',
          ],
        }],
        labels: [
          "Pending Requests",
          "Approved Requests",
        ]
      },
      options: {
        responsive: true,
        title: {
          display: true,
          text: 'Advisor Requests'
        }
      }
    });
  }
}
