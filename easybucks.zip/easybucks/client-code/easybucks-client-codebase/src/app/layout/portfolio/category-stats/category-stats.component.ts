import { Component, OnInit } from '@angular/core';
import { MatTooltip  } from '@angular/material/tooltip';

@Component({
  selector: 'app-category-stats',
  templateUrl: './category-stats.component.html',
  styleUrls: ['./category-stats.component.scss']
})
export class CategoryStatsComponent implements OnInit {

  name = 'left';

  constructor() { }

  ngOnInit() {
  }

}
