import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BankingPortfolioComponent } from './banking-portfolio.component';

describe('BankingPortfolioComponent', () => {
  let component: BankingPortfolioComponent;
  let fixture: ComponentFixture<BankingPortfolioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BankingPortfolioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BankingPortfolioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
