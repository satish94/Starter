import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BullionsPortfolioComponent } from './bullions-portfolio.component';

describe('BullionsPortfolioComponent', () => {
  let component: BullionsPortfolioComponent;
  let fixture: ComponentFixture<BullionsPortfolioComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BullionsPortfolioComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BullionsPortfolioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
