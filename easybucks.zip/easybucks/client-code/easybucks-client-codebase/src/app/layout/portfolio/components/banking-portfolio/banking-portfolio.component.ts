import { User } from './../../../../user/user';
import { PortfolioService } from './../../portfolio.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-banking-portfolio',
  templateUrl: './banking-portfolio.component.html',
  styleUrls: ['./banking-portfolio.component.scss']
})
export class BankingPortfolioComponent implements OnInit {


  loggedInUser: User;
  bankingPort: any[];

  constructor(
    private portfolioServ: PortfolioService
  ) {
    let userDetails = sessionStorage.getItem("userDetail");
    this.loggedInUser = JSON.parse(userDetails);
    this.getPortfolio();
  }

  ngOnInit() {
  }

  getPortfolio() {
    this.portfolioServ.getPortfolio(this.loggedInUser.userId)
      .subscribe(
      result => {
        this.getBanking(result.bankingPort);
      }
      )

  }

  getBanking(result: any) {
    this.bankingPort = result.reverse();
    this.getMaturityValue();
  }
  getMaturityValue() {
    let item: any;
    for (item of this.bankingPort) {
      if (item.bankingProdId.type === 'Fixed') {
        item.maturityValue = item.bankingProdId.rateOfInterest * item.amount * item.noOfMonths;
      }
      else {
        item.maturityValue = item.amount * ((1 + item.bankingProdId.rateOfInterest/4) ** ((4*(item.noOfMonths/12))));
      }
    }
  }

  onDelete(bankingPortId: number){
    this.portfolioServ.deleteBankingPort(bankingPortId, this.loggedInUser.userId)
    .subscribe(
      result =>{
        if(result == 1){
          this.getPortfolio();
        }
      }
    )
  }

  
}
