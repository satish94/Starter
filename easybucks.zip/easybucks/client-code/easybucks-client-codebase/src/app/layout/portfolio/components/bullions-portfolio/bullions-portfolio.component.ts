import { User } from './../../../../user/user';
import { PortfolioService } from './../../portfolio.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bullions-portfolio',
  templateUrl: './bullions-portfolio.component.html',
  styleUrls: ['./bullions-portfolio.component.scss']
})
export class BullionsPortfolioComponent implements OnInit {

  loggedInUser : User;
  bullionsPort: any[];

  constructor(
    private portfolioServ : PortfolioService
  ) {
    let userDetail = sessionStorage.getItem("userDetail");
    this.loggedInUser = JSON.parse(userDetail);
    this.getPortfolio();
   }

  ngOnInit() {
  }

  getPortfolio(){
    this.portfolioServ.getPortfolio(this.loggedInUser.userId)
    .subscribe(
      result =>{
        this.getBullionsPort(result.bullionsPort);
      }
    )
  }

  getBullionsPort(result: any){
    this.bullionsPort = result.reverse();
    this.getMaturityValue();
  }

  getMaturityValue(){
    let item : any;
    for(item of this.bullionsPort){
      item.maturityValue = (item.bullionProd.price - item.purchasePrice)*item.quantity;
    }
  }

  onDelete(bullionsPortId: number){
    this.portfolioServ.deleteBullionsPort(bullionsPortId, this.loggedInUser.userId)
    .subscribe(
      result =>{
        if(result == 1){
          this.getPortfolio();
        }
      }
    )
  }

}
