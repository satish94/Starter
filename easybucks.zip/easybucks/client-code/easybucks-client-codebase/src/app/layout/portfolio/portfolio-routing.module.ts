import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PortfolioComponent } from './portfolio.component';
import { ProductsModule } from '../products/products.module';
import { MfComponent } from "./components/mf/mf.component";
import { BankingComponent } from "./components/banking/banking.component";
import { BullionComponent } from "./components/bullion/bullion.component";
import { StocksComponent } from "./components/stocks/stocks.component";

const routes: Routes = [
    {path: '', component: PortfolioComponent},
    {path: 'portfolioMf/:id', component: MfComponent},
    {path: 'portfolioStocks/:id', component: StocksComponent},
    {path: 'portfolioDeposits/:id', component: BankingComponent},
    {path: 'portfolioBullions/:id', component: BullionComponent},
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class PortfolioRoutingModule {
}
