import { User } from './../../../../user/user';
import { PortfolioService } from './../../portfolio.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Validators } from '@angular/forms';
import { FormGroup, FormControl } from '@angular/forms';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-banking',
  templateUrl: './banking.component.html',
  styleUrls: ['./banking.component.scss']
})
export class BankingComponent implements OnInit {

 closeResult: string;

 bankingPort: FormGroup = new FormGroup({
   noOfMonths: new FormControl('',[Validators.required,Validators.min(1)]),
   amount: new FormControl('',[Validators.required,Validators.min(1)]) 
 })

 get noOfMonths(){
  return this.bankingPort.get("noOfMonths");
}
 get amount(){
  return this.bankingPort.get("amount");
}


 @ViewChild('content') private content ;

 public prodId;
 loggedInUser:User;
 form: any;
 exception : boolean = false;
 modalData: any ;

  constructor(private modalService: NgbModal,
  private route: ActivatedRoute,
   private portfolioServ : PortfolioService,
       private router: Router 
   ) {
    this.prodId = route.snapshot.paramMap.get("id");
   }

  ngOnInit() {
    this.open(this.content) ;
    let userDetails = sessionStorage.getItem("userDetail");
    this.loggedInUser = JSON.parse(userDetails);

  }
  open(content) {
    this.modalData = this.modalService.open(content) ;
    this.modalData.result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    });
  }

  onClick(){
    this.form = this.bankingPort.value;
    this.portfolioServ.addBankingPortfolio(this.prodId, this.loggedInUser.userId,this.form.noOfMonths,this.form.amount)
    .subscribe(
      result =>{
        if(result == 2){
          this.exception = true;
        }
        else{
          this.closeModal();
        }
      }
    )
  }

  
  closeModal(){
    this.modalData.close() ;
    this.router.navigate(['/home']) ;
  }

}
