import { PortfolioService } from './../../portfolio.service';
import { User } from './../../../../user/user';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mf-portfolio',
  templateUrl: './mf-portfolio.component.html',
  styleUrls: ['./mf-portfolio.component.scss']
})
export class MfPortfolioComponent implements OnInit {

  loggedInUser:User;
  mfPort:any [];

  constructor(
    private portfolioServ: PortfolioService
  ) {
    let userDetail = sessionStorage.getItem("userDetail");
    this.loggedInUser = JSON.parse(userDetail);
    this.getPortfolio();
   }

  ngOnInit() {
  }

  getPortfolio(){
    this.portfolioServ.getPortfolio(this.loggedInUser.userId)
    .subscribe(
      result =>{
        this.getmfPort(result.mfPort);
      }
    )
  }

  getmfPort(result : any){
    this.mfPort = result.reverse();
    this.getMaturityValue();
  }

  getMaturityValue(){
    let item : any;
    for(item of this.mfPort){
      let profitPercentage = ((item.mfProd.netAssetValue-item.purNAV)*100)/item.purNAV ;
      item.maturityValue = ((profitPercentage/100)+1)*item.purchasePrice;
    }
  }

  onDelete(mfPortId: number){
    this.portfolioServ.deleteMFPort(mfPortId, this.loggedInUser.userId)
    .subscribe(
      result =>{
        if(result == 1){
          this.getPortfolio();
        }
      }
    )
  }

}
