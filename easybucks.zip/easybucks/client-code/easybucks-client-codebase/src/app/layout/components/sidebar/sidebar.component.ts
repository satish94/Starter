import { Role } from './../../../user/role';
import { User } from './../../../user/user';
import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.scss']
})
export class SidebarComponent implements OnInit {
       

    isActive: boolean = false;
    showMenu: string = '';
    loggedInUser: User = new User();
    admin : string = "admin";
    assist:string;
    review: string ;
    home: string ;

    costructor(){
    }

     ngOnInit(): void {
            
         let userDetail = sessionStorage.getItem("userDetail");
        this.loggedInUser = JSON.parse(userDetail);
        if(this.loggedInUser.userRole.roleName=='admin')
        {
            this.assist='Manage Assistance';
            this.review = 'Manage Reviews' ;
            this.home = 'Dashboard' ;
        }
        if(this.loggedInUser.userRole.roleName=='advisor')
        {
            this.assist='Assistance';
            this.review = 'Write Review' ;
            this.home = 'Dashboard' ;
        }
        if(this.loggedInUser.userRole.roleName=='investor')
        {
            this.assist='Seek Assistance';
            this.review = 'Write Review' ;
            this.home = 'Portfolio' ;
        }
        }


    eventCalled() {
        this.isActive = !this.isActive;
    }

    addExpandClass(element: any) {
        if (element === this.showMenu) {
            this.showMenu = '0';
        } else {
            this.showMenu = element;
        }
    }
}
