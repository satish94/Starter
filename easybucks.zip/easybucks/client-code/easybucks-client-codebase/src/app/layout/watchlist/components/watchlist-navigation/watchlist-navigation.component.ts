import { Component, OnInit } from '@angular/core';
import { routerTransition } from "../../../../router.animations";

@Component({
  selector: 'app-watchlist-navigation',
  templateUrl: './watchlist-navigation.component.html',
  styleUrls: ['./watchlist-navigation.component.scss'],
  animations: [routerTransition()]
})

export class WatchlistNavigationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
