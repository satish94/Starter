import { Component, OnInit } from '@angular/core';
import { DepositWatchlistService } from "./deposit-watchlist.service";
import { User } from "../../../../user/user";
import { MatSnackBar } from "@angular/material/snack-bar";
import { Sort } from "@angular/material/sort";
import { Router } from "@angular/router";

@Component({
    selector: 'app-deposit-watchlist',
    templateUrl: './deposit-watchlist.component.html',
    styleUrls: ['./deposit-watchlist.component.scss']
})
export class DepositWatchlistComponent implements OnInit {

    loggedInUser: User = new User();
    userDetail: any;
    role: any ;
    investor: boolean ;
    advisor:boolean ;
    admin:boolean ;
     private sortedData;
    constructor(private depositWatchlistService: DepositWatchlistService,private snackBar: MatSnackBar,private router: Router) {
                this.userDetail = sessionStorage.getItem("userDetail");
        this.loggedInUser = JSON.parse(this.userDetail);
        this.getBankingProducts();
    }

    ngOnInit() {
        this.role = this.loggedInUser.userRole.roleName;
        if (this.role == "investor")
        {
            this.investor = true;
            this.admin = false;
            this.advisor = false;
        }

        if (this.role == "admin")
        {
            this.investor = false;
            this.admin = true;
            this.advisor = false;
        }
        if(this.role == "advisor")
        {
             this.investor = false;
            this.admin = false;
            this.advisor = true;
        }
    }

    products: any[] = [];
    getBankingProducts() {
        this.depositWatchlistService.getBankingProducts(this.loggedInUser.userId)
            .subscribe(
            products => {

                this.products = products;
            }
            )
    }

    deleteFromBankingWatchlist(product: any) {
        this.depositWatchlistService.deleteFromBankingWatchlist(this.loggedInUser.userId, product.id)
            .subscribe(
            products => {
            }
            )
            this.openSnackBar('Product Deleted Successfully','') ;
            this.products.splice(this.products.indexOf(product), 1);
    }
      openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });
}

sortData(sort: Sort) {
    const data = this.products ;
    if (!sort.active || sort.direction === '') {
      this.sortedData = data;
      return;
    }
    this.sortedData = data.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'bankName': return this.compare(a.bankName, b.bankName, isAsc);
        case 'type': return this.compare(+a.type, +b.type, isAsc);
        case 'rateOfInterest': return this.compare(+a.rateOfInterest, +b.rateOfInterest, isAsc);
        default: return 0;
      }
    });
  }
  compare(a, b, isAsc): number {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}

navigateme(id)
{
    this.router.navigate(['../../../home/portfolioDeposits',id])
}
}
