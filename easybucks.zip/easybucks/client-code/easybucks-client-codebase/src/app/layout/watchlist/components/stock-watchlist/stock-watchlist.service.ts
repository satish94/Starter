import { Injectable } from '@angular/core';
import { Observable } from "rxjs/Observable";
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { post_header, EasyBucksConstants } from "../../../../EasyBucks";
import { HttpClient } from "@angular/common/http";

@Injectable()
export class StockWatchlistService {
    localUrl:String="http://localhost:8077/easybucks/";
    private _baseUrl = EasyBucksConstants.baseUrl ;
     private _headers = new Headers({ 'Content-Type': 'application/json' });
    private _options = new RequestOptions({ headers: this._headers });
    constructor(private http: HttpClient) {
     }

          private _handleError(err: any) {     
        return Observable.throw(err);
    }   

    ngOnChanges() {
    }


      getStockProducts(id:any): Observable<any> {
        return this.http.get(this._baseUrl+"watchlist/stocks/all/"+id);

    }

    addToStockWatchlist(uid: any,pid:any) {
        return this.http.get( this._baseUrl + "watchlist/stocks/"+uid+'/'+pid)
  }

  deleteFromStockWatchlist(uid : any,pid : any){
      return this.http.delete(this._baseUrl + "watchlist/stocks/delete/"+uid+'/'+pid);
      
  }
}