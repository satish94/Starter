import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MutualfundWatchlistComponent } from './mutualfund-watchlist.component';

describe('MutualfundWatchlistComponent', () => {
  let component: MutualfundWatchlistComponent;
  let fixture: ComponentFixture<MutualfundWatchlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MutualfundWatchlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MutualfundWatchlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
