import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { WatchlistRoutingModule } from './watchlist-routing.module';
import { WatchlistComponent } from './watchlist.component';
import { PageHeaderModule } from './../../shared';
import { WatchlistService } from "./watchlist.service";
import { MatFormFieldModule } from '@angular/material';
import { MatFormFieldControl } from '@angular/material';
import { MatTableModule, MatSelectModule, MatTabsModule, MatTooltipModule, MatSortModule } from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { WatchlistNavigationComponent } from './components/watchlist-navigation/watchlist-navigation.component';
import { MutualfundWatchlistComponent } from './components/mutualfund-watchlist/mutualfund-watchlist.component';
import { StockWatchlistComponent } from './components/stock-watchlist/stock-watchlist.component';
import { BullionWatchlistComponent } from './components/bullion-watchlist/bullion-watchlist.component';
import { DepositWatchlistComponent } from './components/deposit-watchlist/deposit-watchlist.component';
import { BullionWatchlistService } from "./components/bullion-watchlist/bullion-watchlist.service";
import { DepositWatchlistService } from "./components/deposit-watchlist/deposit-watchlist.service";
import { StockWatchlistService } from "./components/stock-watchlist/stock-watchlist.service";
import {MatSnackBarModule} from '@angular/material/snack-bar';
import { MutualfundWatchlistService } from "./components/mutualfund-watchlist/mutualfund-watchlist.service";
@NgModule({
    imports: [CommonModule, 
    WatchlistRoutingModule, 
    PageHeaderModule,
    MatSelectModule,
    MatFormFieldModule,
    MatTableModule,
    FormsModule,
    ReactiveFormsModule,
    MatTabsModule,
    MatSortModule,
    MatTooltipModule,
    MatSnackBarModule
    ],
    declarations: [WatchlistComponent, WatchlistNavigationComponent, MutualfundWatchlistComponent, StockWatchlistComponent, BullionWatchlistComponent, DepositWatchlistComponent],
    providers:[WatchlistService,
    BullionWatchlistService,
    DepositWatchlistService,
    MutualfundWatchlistService,
    StockWatchlistService
    ]
})
export class WatchlistModule {
    
}
