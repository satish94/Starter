import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DepositWatchlistComponent } from './deposit-watchlist.component';

describe('DepositWatchlistComponent', () => {
  let component: DepositWatchlistComponent;
  let fixture: ComponentFixture<DepositWatchlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DepositWatchlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DepositWatchlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
