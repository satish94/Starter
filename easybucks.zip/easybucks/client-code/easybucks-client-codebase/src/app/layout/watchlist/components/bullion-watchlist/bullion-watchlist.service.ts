import { Injectable } from '@angular/core';
import { Observable } from "rxjs/Observable";
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { post_header, EasyBucksConstants } from "../../../../EasyBucks";
import { HttpClient } from "@angular/common/http";
import { User } from "../../../../user/user";

@Injectable()
export class BullionWatchlistService {
    localUrl:String="http://localhost:8077/easybucks/";
    private _baseUrl = EasyBucksConstants.baseUrl ;
     private _headers = new Headers({ 'Content-Type': 'application/json' });
    private _options = new RequestOptions({ headers: this._headers });

    constructor(private http: HttpClient) {

     }

     private _handleError(err: any) {     
        return Observable.throw(err);
    }   

 

       getBullionProducts(id:any): Observable<any> {
        return this.http.get(this._baseUrl+"watchlist/bullions/all/"+id);
     }
     addToBullionWatchlist(uid:any,pid:any) {
        return this.http.get( this._baseUrl + "watchlist/bullions/"+uid+'/'+pid)
  }

  deleteFromBullionWatchlist(uid : any,pid:any){
      return this.http.delete(this._baseUrl + "watchlist/bullions/delete/"+uid+'/'+pid);
      
  }
}