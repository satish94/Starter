import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WatchlistNavigationComponent } from './watchlist-navigation.component';

describe('WatchlistNavigationComponent', () => {
  let component: WatchlistNavigationComponent;
  let fixture: ComponentFixture<WatchlistNavigationComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WatchlistNavigationComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WatchlistNavigationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
