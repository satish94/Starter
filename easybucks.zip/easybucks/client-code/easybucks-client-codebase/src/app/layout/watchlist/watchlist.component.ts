import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';
import { WatchlistService } from "./watchlist.service";
import { MatFormFieldControl } from '@angular/material';

@Component({
    selector: 'app-watchlist',
    templateUrl: './watchlist.component.html',
    styleUrls: ['./watchlist.component.scss'],
    animations: [routerTransition()]
})
export class WatchlistComponent implements OnInit {
  

   
    ngOnInit() {
    }


    constructor() {

    }


    
}


