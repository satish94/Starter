import { Component, OnInit } from '@angular/core';
import { StockWatchlistService } from "./stock-watchlist.service";
import { User } from "../../../../user/user";
import { MatSnackBar } from "@angular/material/snack-bar";
import { Sort } from "@angular/material/sort";
import { Router } from "@angular/router";

@Component({
    selector: 'app-stock-watchlist',
    templateUrl: './stock-watchlist.component.html',
    styleUrls: ['./stock-watchlist.component.scss']
})
export class StockWatchlistComponent implements OnInit {

    loggedInUser: User = new User();
    userDetail: any;
    private sortedData;
    role:any ;
    investor: boolean ;
    advisor:boolean ;
    admin:boolean ;
    constructor(private stockWatchlistService: StockWatchlistService, private snackBar: MatSnackBar, private router: Router) {
        this.userDetail = sessionStorage.getItem("userDetail");
        this.loggedInUser = JSON.parse(this.userDetail);
        this.getStockProducts();

    }

    ngOnInit() {
        this.role = this.loggedInUser.userRole.roleName;
        if (this.role == "investor")
        {
            this.investor = true;
            this.admin = false;
            this.advisor = false;
        }

        if (this.role == "admin")
        {
            this.investor = false;
            this.admin = true;
            this.advisor = false;
        }
        if(this.role == "advisor")
        {
             this.investor = false;
            this.admin = false;
            this.advisor = true;
        }
    }

    products: any[] = [];
    getStockProducts() {
        this.stockWatchlistService.getStockProducts(this.loggedInUser.userId)
            .subscribe(
            products => {

                this.products = products;
            }
            )
    }

    deleteFromStockWatchlist(product: any) {
        this.stockWatchlistService.deleteFromStockWatchlist(this.loggedInUser.userId, product.id)
            .subscribe(
            products => {
            }
            )
            this.openSnackBar('Product Deleted Successfully','') ;
            this.products.splice(this.products.indexOf(product), 1);
    }

         openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });

}

sortData(sort: Sort) {
    const data = this.products ;
    if (!sort.active || sort.direction === '') {
      this.sortedData = data;
      return;
    }
    this.sortedData = data.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'name': return this.compare(a.name, b.name, isAsc);
        case 'code': return this.compare(+a.code, +b.code, isAsc);
        case 'currTradingPrice': return this.compare(+a.currTradingPrice, +b.currTradingPrice, isAsc);
        case 'lastTradingPrice': return this.compare(+a.lastTradingPrice, +b.lastTradingPrice, isAsc);
        default: return 0;
      }
    });
  }
  compare(a, b, isAsc): number {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}

navigateme(id)
{
    this.router.navigate(['../../../home/portfolioStocks',id])
}
}
