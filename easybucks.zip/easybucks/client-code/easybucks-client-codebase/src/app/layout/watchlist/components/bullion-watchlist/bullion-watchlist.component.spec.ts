import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BullionWatchlistComponent } from './bullion-watchlist.component';

describe('BullionWatchlistComponent', () => {
  let component: BullionWatchlistComponent;
  let fixture: ComponentFixture<BullionWatchlistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BullionWatchlistComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BullionWatchlistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
