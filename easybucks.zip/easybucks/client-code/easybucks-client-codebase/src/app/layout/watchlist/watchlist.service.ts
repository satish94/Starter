import { Injectable } from '@angular/core';
import { Observable } from "rxjs/Observable";
import { HttpClient } from "@angular/common/http";
import { EasyBucksConstants } from "../../EasyBucks";
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { post_header } from '../../EasyBucks' ;

@Injectable()
export class WatchlistService {

}
