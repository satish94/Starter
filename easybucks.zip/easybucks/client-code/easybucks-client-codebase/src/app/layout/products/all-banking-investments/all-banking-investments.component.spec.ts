import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AllBankingInvestmentsComponent } from './all-banking-investments.component';
import { AddBankingInvestmentsComponent } from '../../add-products/add-banking-investments/add-banking-investments.component';
import { ReactiveFormsModule, FormsModule, FormGroup, FormControl, Validators } from '@angular/forms';

describe('AllBankingInvestmentsComponent', () => {
  let component: AllBankingInvestmentsComponent;
  let fixture: ComponentFixture<AllBankingInvestmentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AllBankingInvestmentsComponent, AddBankingInvestmentsComponent],
      imports: [FormsModule, ReactiveFormsModule]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllBankingInvestmentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
