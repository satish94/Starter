import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { EasyBucksConstants } from './../../../EasyBucks';

@Injectable()
export class MutualFundsService {
private _url = EasyBucksConstants.baseUrl + 'products/mutualfunds/all' ;
  constructor(private http: HttpClient) { }


  getMutualFunds(): Observable<any> {
    return(this.http.get(this._url)) ;
  }

}
