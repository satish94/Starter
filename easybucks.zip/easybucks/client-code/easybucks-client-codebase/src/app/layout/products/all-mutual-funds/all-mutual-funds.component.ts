import { Component, OnInit } from '@angular/core';
import { MutualFundsService } from './mutual-funds.service';
import { MutualfundWatchlistService } from "../../watchlist/components/mutualfund-watchlist/mutualfund-watchlist.service";
import { User } from "../../../user/user";
import { Sort, MatTableDataSource, MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-all-mutual-funds',
  templateUrl: './all-mutual-funds.component.html',
  styleUrls: ['./all-mutual-funds.component.scss']
})
export class AllMutualFundsComponent implements OnInit {
  mf;
  loggedInUser: User = new User();
  userDetail: any;
  role: any ;
  investor: boolean ;
    advisor:boolean ;
    admin:boolean ;
  constructor(private mutualfundsService: MutualFundsService,private mutualfundWatchlistService : MutualfundWatchlistService,private snackBar: MatSnackBar) {
    this.getAll();
    this.userDetail = sessionStorage.getItem("userDetail");
    this.loggedInUser = JSON.parse(this.userDetail);
  }

  ngOnInit() {
    this.role = this.loggedInUser.userRole.roleName;
        if (this.role == "investor")
        {
            this.investor = true;
            this.admin = false;
            this.advisor = false;
        }

        if (this.role == "admin")
        {
            this.investor = false;
            this.admin = true;
            this.advisor = false;
        }
        if(this.role == "advisor")
        {
             this.investor = false;
            this.admin = false;
            this.advisor = true;
        }
  }

  getAll() {
    this.mutualfundsService.getMutualFunds()
      .subscribe(
      response => {
        this.getAllMutualFunds(response);
      },
      error => {
        console.log('error in loading products');
      }
      );
  }
  getAllMutualFunds(result: any): void {
    this.mf = result.reverse();
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });
      }

  addToMutualWatchlist(id:any)
  {
    this.mutualfundWatchlistService.addToMutualWatchlist(this.loggedInUser.userId,id)
     .subscribe(response=>{
        
    }

    );
    this.openSnackBar('Product Added Successfully','')
  }

}
