import { Component, OnInit } from '@angular/core';
import { BankingService } from './banking.service';
import { DepositWatchlistService } from '../../watchlist/components/deposit-watchlist/deposit-watchlist.service';
import { User } from '../../../user/user';
import { Sort, MatTableDataSource, MatSnackBar } from '@angular/material';
@Component({
  selector: 'app-all-banking-investments',
  templateUrl: './all-banking-investments.component.html',
  styleUrls: ['./all-banking-investments.component.scss']
})
export class AllBankingInvestmentsComponent implements OnInit {
  banking;
  loggedInUser: User = new User();
  userDetail: any;
  role: any ;
  investor: boolean ;
    advisor:boolean ;
    admin:boolean ;
  constructor(private bankingService: BankingService, private depositWatchlistService: DepositWatchlistService, private snackBar: MatSnackBar) {
    this.getAll();
    this.userDetail = sessionStorage.getItem('userDetail');
    this.loggedInUser = JSON.parse(this.userDetail);
  }

  ngOnInit() {
    this.role = this.loggedInUser.userRole.roleName;
        if (this.role == "investor")
        {
            this.investor = true;
            this.admin = false;
            this.advisor = false;
        }

        if (this.role == "admin")
        {
            this.investor = false;
            this.admin = true;
            this.advisor = false;
        }
        if(this.role == "advisor")
        {
             this.investor = false;
            this.admin = false;
            this.advisor = true;
        }
  }

  getAll() {
    this.bankingService.getBanking()
      .subscribe(
      response => {
        this.getAllBanking(response);
      },
      error => {
        console.log('error in loading products');
      }
      );
  }
  getAllBanking(result: any): void {
    this.banking = result.reverse();
  }

   openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });
      }

  addToBankingWatchlist(id:any)
  {     
    this.depositWatchlistService.addToBankingWatchlist(this.loggedInUser.userId,id)
     .subscribe(response=>{       
    });
    this.openSnackBar('Product Added Successfully','')
  }
}
