import { TestBed, inject } from '@angular/core/testing';

import { BullionsService } from './bullions.service';

describe('BullionsService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BullionsService]
    });
  });

  it('should be created', inject([BullionsService], (service: BullionsService) => {
    expect(service).toBeTruthy();
  }));
});
