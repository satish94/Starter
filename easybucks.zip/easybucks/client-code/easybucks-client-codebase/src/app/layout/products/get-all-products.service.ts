import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from "rxjs/Observable";
@Injectable()
export class GetAllProductsService {

  private _productUrl = 'https://www.quandl.com/api/v3/datasets/NSE/';

  constructor(private _http: HttpClient) { }

 getProducts(code: String): Observable<any>
  {
      let url : string;
      let currentDate = new Date() ;
      let date = currentDate.getFullYear() + '-' + (currentDate.getMonth() + 1) + '-' + (currentDate.getDate() - 10) ;
      url = this._productUrl + code +".json?api_key=Vs_ydVSSbYPezMwCgLWJ&start_date="+date ;
      return this._http.get(url) ;
  }



}
