import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { EasyBucksConstants } from './../../../EasyBucks';

@Injectable()
export class BullionsService {
private _url = EasyBucksConstants.baseUrl + 'products/bullions/all' ;
  constructor(private http: HttpClient) { }


  getBullions(): Observable<any> {
    return(this.http.get(this._url)) ;
  }

}
