import { Component, OnInit } from '@angular/core';
import { StocksService } from './stocks.service';
import { MatSnackBar } from "@angular/material";
import { StockWatchlistService } from "../../watchlist/components/stock-watchlist/stock-watchlist.service";
import { User } from "../../../user/user";

@Component({
  selector: 'app-all-stocks',
  templateUrl: './all-stocks.component.html',
  styleUrls: ['./all-stocks.component.scss'],
  providers: []
})
export class AllStocksComponent implements OnInit {

  stocks;
  loggedInUser: User = new User();
  userDetail: any;
  role:any ;
  investor: boolean ;
    advisor:boolean ;
    admin:boolean ;
  constructor(private stocksService: StocksService, private stockWatchlistService: StockWatchlistService, private snackBar: MatSnackBar) {
    this.getAll();
    this.userDetail = sessionStorage.getItem("userDetail");
    this.loggedInUser = JSON.parse(this.userDetail);
  }

  ngOnInit() {
    this.role = this.loggedInUser.userRole.roleName;
        if (this.role == "investor")
        {
            this.investor = true;
            this.admin = false;
            this.advisor = false;
        }

        if (this.role == "admin")
        {
            this.investor = false;
            this.admin = true;
            this.advisor = false;
        }
        if(this.role == "advisor")
        {
             this.investor = false;
            this.admin = false;
            this.advisor = true;
        }
  }

  getAll() {
    this.stocksService.getStocks()
      .subscribe(
      response => {
        this.getAllStocks(response);
      },
      error => {
        console.log('error in loading products');
      }
      );
  }
  getAllStocks(result: any): void {
    this.stocks = result.reverse();
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });
  }

  addToStockWatchlist(id: any) {
    this.stockWatchlistService.addToStockWatchlist(this.loggedInUser.userId, id)
      .subscribe(response => {

      });
      this.openSnackBar('Product Added Successfully','')
  }
}

