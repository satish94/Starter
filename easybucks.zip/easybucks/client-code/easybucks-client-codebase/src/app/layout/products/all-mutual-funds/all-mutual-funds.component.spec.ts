import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule, FormsModule, FormGroup, FormControl, Validators } from '@angular/forms';

import { AllMutualFundsComponent } from './all-mutual-funds.component';
import { AddMutualFundComponent } from '../../add-products/add-mutual-fund/add-mutual-fund.component';

describe('AllMutualFundsComponent', () => {
  let component: AllMutualFundsComponent;
  let fixture: ComponentFixture<AllMutualFundsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AllMutualFundsComponent, AddMutualFundComponent],
      imports: [FormsModule, ReactiveFormsModule]

    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllMutualFundsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
