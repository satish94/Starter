import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AllStocksComponent } from './all-stocks/all-stocks.component';
import { AllMutualFundsComponent } from './all-mutual-funds/all-mutual-funds.component';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AddProductsModule } from '../add-products/add-products.module';
import { AddMutualFundComponent } from '../add-products/add-mutual-fund/add-mutual-fund.component';
import { AllBankingInvestmentsComponent } from './all-banking-investments/all-banking-investments.component';
import { AllBullionsComponent } from './all-bullions/all-bullions.component';
import { ProductsComponent } from './products.component';
import { ProductsRoutingModule } from './products-routing.module';
import {
  MatAutocompleteModule,
  MatButtonModule,
  MatButtonToggleModule,
  MatCardModule,
  MatCheckboxModule,
  MatChipsModule,
  MatDatepickerModule,
  MatDialogModule,
  MatExpansionModule,
  MatGridListModule,
  MatIconModule,
  MatInputModule,
  MatListModule,
  MatMenuModule,
  MatNativeDateModule,
  MatPaginatorModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatRadioModule,
  MatRippleModule,
  MatSelectModule,
  MatSidenavModule,
  MatSliderModule,
  MatSlideToggleModule,
  MatSnackBarModule,
  MatSortModule,
  MatTableModule,
  MatTabsModule,
  MatToolbarModule,
  MatTooltipModule,
  MatStepperModule,
} from '@angular/material';
import { StocksService } from './all-stocks/stocks.service';
import { MutualFundsService } from './all-mutual-funds/mutual-funds.service';
import { BankingService } from './all-banking-investments/banking.service';
import { BullionsService } from './all-bullions/bullions.service';
import { MutualfundWatchlistService } from './../watchlist/components/mutualfund-watchlist/mutualfund-watchlist.service';
import { StockWatchlistService } from './../watchlist/components/stock-watchlist/stock-watchlist.service';
import { BullionWatchlistService } from './../watchlist/components/bullion-watchlist/bullion-watchlist.service';
import { DepositWatchlistService } from '../watchlist/components/deposit-watchlist/deposit-watchlist.service';
import { StocksDetailsComponent } from './stocks-details/stocks-details.component';
import { GetAllProductsService } from './get-all-products.service';
@NgModule({
  imports: [
    CommonModule,
    AddProductsModule,
    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatStepperModule,
    ProductsRoutingModule
  ],
  declarations: [AllStocksComponent,
    AllMutualFundsComponent,
    AllBankingInvestmentsComponent,
    AllBullionsComponent,
    ProductsComponent,
    StocksDetailsComponent],
  providers: [
    StocksService,
    MutualFundsService,
    BankingService,
    BullionsService,
    DepositWatchlistService,
    MutualfundWatchlistService,
    StockWatchlistService,
    BullionWatchlistService,
    GetAllProductsService]
})
export class ProductsModule { }
