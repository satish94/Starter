import { GetAllProductsService } from '../get-all-products.service';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import Chart from 'chart.js';

@Component({
  selector: 'app-stocks-details',
  templateUrl: './stocks-details.component.html',
  styleUrls: ['./stocks-details.component.scss']
})
export class StocksDetailsComponent implements OnInit {

  public code;
  public data;
  public display;
  public name;
  public disp;
  public stocksData: any[];
  constructor(private _route: ActivatedRoute, private _productService: GetAllProductsService) {
    this.code = this._route.snapshot.paramMap.get('code');
    this.name = this._route.snapshot.paramMap.get('name');
    this.getProducts();
  }

  ngOnInit() {
  }

  getProducts() {
    this._productService.getProducts(this.code).subscribe(
      response => {
        this.getAllProducts(response.dataset.data);
      }
    )
  }

  getAllProducts(response) {
    console.log(response);
    this.stocksData = response;
    this.display = `<canvas id="stocksChart"></canvas>`;
    document.getElementById("testgraph").innerHTML += this.display;
    var ctx = document.getElementById("stocksChart");
    var stocksChart = new Chart(ctx, {
      type: 'bar',
      data: {
        labels: [
          this.stocksData[4][0],
          this.stocksData[3][0],
          this.stocksData[2][0],
          this.stocksData[1][0],
          this.stocksData[0][0],
        ],
        datasets: [{
          label: 'Open',
          borderColor: "#3e95cd",
          
          backgroundColor: ["#3e95cd","#3e95cd","#3e95cd","#3e95cd","#3e95cd"],
          data: [
            this.stocksData[4][1],
            this.stocksData[3][1],
            this.stocksData[2][1],
            this.stocksData[1][1],
            this.stocksData[0][1],
          ],
        },
        {
          label: 'High',
          borderColor: "#8e5ea2",
          backgroundColor: ["#8e5ea2","#8e5ea2","#8e5ea2","#8e5ea2","#8e5ea2"],
          data: [
            this.stocksData[4][2],
            this.stocksData[3][2],
            this.stocksData[2][2],
            this.stocksData[1][2],
            this.stocksData[0][2],
          ],
        },
        {
          label: 'Low',
          borderColor: "#3cba9f",
          backgroundColor: ["#3cba9f","#3cba9f","#3cba9f","#3cba9f","#3cba9f"],
          data: [
            this.stocksData[4][3],
            this.stocksData[3][3],
            this.stocksData[2][3],
            this.stocksData[1][3],
            this.stocksData[0][3],
          ],
        },
        {
          label: 'Last',
          borderColor: "#e8c3b9",
          backgroundColor: ["#e8c3b9","#e8c3b9","#e8c3b9","#e8c3b9","#e8c3b9"],
          data: [
            this.stocksData[4][4],
            this.stocksData[3][4],
            this.stocksData[2][4],
            this.stocksData[1][4],
            this.stocksData[0][4],
          ],
        },
        {
          label: 'Close',
          borderColor: "#c45850",
          backgroundColor: ["#c45850","#c45850","#c45850","#c45850","#c45850"],
          data: [
            this.stocksData[4][5],
            this.stocksData[3][5],
            this.stocksData[2][5],
            this.stocksData[1][5],
            this.stocksData[0][5],
          ],
        }],
      },
      options: {
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero: false,
            },
            scaleLabel: {
              display: true,
              labelString: 'Price(in Rs)'
            }
          }],
          xAxes: [{
            scaleLabel: {
              display: true,
              labelString: 'Date'
            }
          }]
        }
      }
    });
    this.disp = `<canvas id="stocksturnoverChart"></canvas>`;
    document.getElementById("turnovergraph").innerHTML += this.disp;
    var turnoverctx = document.getElementById("stocksturnoverChart");
    var stocksturnoverChart = new Chart(turnoverctx, {
      type: 'bar',
      data: {
        labels: [
          this.stocksData[4][0],
          this.stocksData[3][0],
          this.stocksData[2][0],
          this.stocksData[1][0],
          this.stocksData[0][0],
        ],
        datasets: [{
          label: 'Total Trade Quantity',
          borderColor: "#3e95cd",
          backgroundColor: ["#3e95cd","#3e95cd","#3e95cd","#3e95cd","#3e95cd"],
          data: [
            this.stocksData[4][6],
            this.stocksData[3][6],
            this.stocksData[2][6],
            this.stocksData[1][6],
            this.stocksData[0][6],
          ],
        },
        {
          label: 'Turnover(in Thousands)',
          borderColor: "#e8c3b9",
          backgroundColor: ["#e8c3b9","#e8c3b9","#e8c3b9","#e8c3b9","#e8c3b9"],
          data: [
            this.stocksData[4][7] * 1000,
            this.stocksData[3][7] * 1000,
            this.stocksData[2][7] * 1000,
            this.stocksData[1][7] * 1000,
            this.stocksData[0][7] * 1000,
          ],
        }],
      },
      options: {
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero: false
            },
            scaleLabel: {
              display: true,
              labelString: 'Price(in Thousands)'
            }
          }],
          xAxes: [{
            scaleLabel: {
              display: true,
              labelString: 'Date'
            }
          }]
        }
      }
    });
  }

}