import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { EasyBucksConstants } from './../../../EasyBucks';

@Injectable()
export class BankingService {
private _url = EasyBucksConstants.baseUrl + 'products/banking/all' ;
  constructor(private http: HttpClient) { }


  getBanking(): Observable<any> {
    return(this.http.get(this._url)) ;
  }

}
