import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Rx';
import { EasyBucksConstants } from './../../../EasyBucks';

@Injectable()
export class StocksService {

private _url = EasyBucksConstants.baseUrl + 'products/stocks/all' ;
private _productUrl = 'https://www.quandl.com/api/v3/datasets/NSE/';
  constructor(private http: HttpClient) { }


  getStocks(): Observable<any> {
    return(this.http.get(this._url)) ;
  }

  getProducts(code: String): Observable<any> {
      let url: string;
      const currentDate = new Date() ;
      const date = currentDate.getFullYear() + '-' + (currentDate.getMonth() + 1) + '-' + (currentDate.getDate() - 10) ;
      url = this._productUrl + code + '.json?api_key=Vs_ydVSSbYPezMwCgLWJ&start_date=' + date ;
      return this.http.get(url) ;
  }
}
