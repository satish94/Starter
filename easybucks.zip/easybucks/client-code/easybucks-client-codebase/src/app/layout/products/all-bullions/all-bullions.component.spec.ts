import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule, FormsModule, FormGroup, FormControl, Validators } from '@angular/forms';

import { AllBullionsComponent } from './all-bullions.component';
import { AddBullionsComponent } from '../../add-products/add-bullions/add-bullions.component';

describe('AllBullionsComponent', () => {
  let component: AllBullionsComponent;
  let fixture: ComponentFixture<AllBullionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AllBullionsComponent, AddBullionsComponent],
      imports: [FormsModule, ReactiveFormsModule]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllBullionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
