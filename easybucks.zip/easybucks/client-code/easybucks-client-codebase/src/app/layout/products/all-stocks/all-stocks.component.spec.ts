import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule, FormsModule, FormGroup, FormControl, Validators } from '@angular/forms';

import { AllStocksComponent } from './all-stocks.component';
import { AddStockComponent } from '../../add-products/add-stock/add-stock.component';

describe('AllStocksComponent', () => {
  let component: AllStocksComponent;
  let fixture: ComponentFixture<AllStocksComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AllStocksComponent, AddStockComponent],
            imports: [FormsModule, ReactiveFormsModule]

    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AllStocksComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
