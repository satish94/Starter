import { Routes, RouterModule } from '@angular/router';
import { NgModule } from '@angular/core';

import { ProductsComponent } from './products.component';
import { AllStocksComponent } from './all-stocks/all-stocks.component';
import { AllMutualFundsComponent } from './all-mutual-funds/all-mutual-funds.component';
import { AllBankingInvestmentsComponent } from './all-banking-investments/all-banking-investments.component';
import { AllBullionsComponent } from './all-bullions/all-bullions.component';
import { StocksDetailsComponent } from './stocks-details/stocks-details.component';

const routes: Routes = [
    { path: '', component: ProductsComponent},
    { path: 'allStocks', component: AllStocksComponent },
    { path: 'allMutualFunds', component: AllMutualFundsComponent },
    { path: 'allBankingInvestments', component: AllBankingInvestmentsComponent},
    { path: 'allBullions', component: AllBullionsComponent},
    { path: 'details/:code/:name', component: StocksDetailsComponent},

];

@NgModule({
    imports: [RouterModule.forChild(routes)],
exports: [RouterModule]
})
export class ProductsRoutingModule {}
