import { Component, OnInit } from '@angular/core';
import { BullionsService } from './bullions.service';
import { routerTransition } from '../../../router.animations';
import { BullionWatchlistService } from "../../watchlist/components/bullion-watchlist/bullion-watchlist.service";
import { User } from "../../../user/user";
import { Sort, MatTableDataSource, MatSnackBar } from '@angular/material';

@Component({
  selector: 'app-all-bullions',
  templateUrl: './all-bullions.component.html',
  styleUrls: ['./all-bullions.component.scss'],
  animations: [routerTransition()]
})
export class AllBullionsComponent implements OnInit {
  bullions;
  loggedInUser: User = new User();
  userDetail: any;
  role: any ;
  investor: boolean ;
    advisor:boolean ;
    admin:boolean ;
  constructor(private bullionsService: BullionsService, private bullionWatchlistService: BullionWatchlistService, private snackBar: MatSnackBar) {
    this.getAll();
    this.userDetail = sessionStorage.getItem("userDetail");
    this.loggedInUser = JSON.parse(this.userDetail);
  }

  ngOnInit() {
    this.role = this.loggedInUser.userRole.roleName;
        if (this.role == "investor")
        {
            this.investor = true;
            this.admin = false;
            this.advisor = false;
        }

        if (this.role == "admin")
        {
            this.investor = false;
            this.admin = true;
            this.advisor = false;
        }
        if(this.role == "advisor")
        {
             this.investor = false;
            this.admin = false;
            this.advisor = true;
        }
  }

  getAll() {
    this.bullionsService.getBullions()
      .subscribe(
      response => {
        this.getAllBullions(response);
      },
      error => {
        console.log('error in loading products');
      }
      );
  }
  getAllBullions(result: any): void {
    this.bullions = result.reverse();
  }

  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });
  }

  addToBullionWatchlist(id: any) {
    this.bullionWatchlistService.addToBullionWatchlist(this.loggedInUser.userId, id)
      .subscribe(response => {

      }

      );
    this.openSnackBar('Product Added Successfully', '')
  }

}
