import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Input } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddBankingInvestmentsComponent } from './add-banking-investments.component';

describe('AddBankingInvestmentsComponent', () => {
  let component: AddBankingInvestmentsComponent;
  let fixture: ComponentFixture<AddBankingInvestmentsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AddBankingInvestmentsComponent],
      imports: [FormsModule, ReactiveFormsModule]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddBankingInvestmentsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should invalidate form when empty', () => {
    expect(component.investForm.valid).toBeFalsy();
  });

  it('should invalidate amount when empty', () => {
    expect(component.investForm.controls['amount'].value).toBe('1');
  });

  it('should invalidate rateOfInvestment when empty', () => {
    expect(component.investForm.controls['rateOfInvestment'].value).toBe('7.0');
  });


});
