import { Component, OnInit, Input } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-add-stock',
  templateUrl: './add-stock.component.html',
  styleUrls: ['./add-stock.component.scss']
})
export class AddStockComponent implements OnInit {

  model;
  date: { year: number, month: number };

  @Input('schemeName') schemeName;

  investForm = new FormGroup({
    date: new FormControl('', [Validators.required]),
    numberOfStocks: new FormControl('1', [Validators.required, Validators.pattern('[1-9]*[0-9]+')]),
    investmentPrice: new FormControl('1000', [Validators.required, Validators.pattern('[1-9]*[0-9]+')])

  });



  get numberOfStocks() {
    return this.investForm.get('numberOfStocks');
  }

  get investmentPrice() {
    return this.investForm.get('investmentPrice');
  }
  reset: Boolean = false;

  constructor() { }

  ngOnInit() {
   }

  submitForm() {
  }

  resetForm() {
    this.investForm.reset();
    this.reset = true;
    this.investForm = new FormGroup({
      date: new FormControl('', [Validators.required]),
      numberOfStocks: new FormControl('1', [Validators.required, Validators.pattern('[1-9]*[0-9]+')]),
      investmentPrice: new FormControl('1000', [Validators.required, Validators.pattern('[1-9]*[0-9]+')])
    });
    this.reset = false;
  }
}
