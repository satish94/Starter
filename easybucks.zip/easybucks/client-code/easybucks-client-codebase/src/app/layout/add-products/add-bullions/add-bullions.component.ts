import { Component, OnInit, Input } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-add-bullions',
  templateUrl: './add-bullions.component.html',
  styleUrls: ['./add-bullions.component.scss']
})
export class AddBullionsComponent implements OnInit {

  constructor() { }
  // tslint:disable-next-line:no-input-rename
  @Input('schemeName') bullionName;


  investForm = new FormGroup({
    date: new FormControl('', [Validators.required]),
    units: new FormControl('1', [Validators.required, Validators.pattern('[1-9]*[0-9]+')]),
    price: new FormControl('12120', [Validators.required, Validators.pattern('[1-9]*[0-9]+')])
  });
  reset: Boolean = false;

  ngOnInit() {
  }

  get numberOfStocks() {
    return this.investForm.get('units');
  }

  get investmentPrice() {
    return this.investForm.get('price');
  }

  submitForm() {

  }


  resetForm() {
    this.investForm.reset();
    this.reset = true;
    this.investForm = new FormGroup({
      date: new FormControl('', [Validators.required]),
      units: new FormControl('1', [Validators.required, Validators.pattern('[1-9]*[0-9]+')]),
      price: new FormControl('12120', [Validators.required, Validators.pattern('[1-9]*[0-9]+')])
    });
    this.reset = false;
  }



}
