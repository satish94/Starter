import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Input } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AddMutualFundComponent } from './add-mutual-fund.component';

describe('AddMutualFundComponent', () => {
  let component: AddMutualFundComponent;
  let fixture: ComponentFixture<AddMutualFundComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AddMutualFundComponent],
      imports: [FormsModule, ReactiveFormsModule]

    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddMutualFundComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should invalidate form when empty', () => {
    expect(component.investForm.valid).toBeFalsy();
  });

  it('should invalidate numberOfMutualFunds when empty', () => {
    expect(component.investForm.controls['numberOfMutualFunds'].value).toBe('1');
  });

  it('should invalidate investmentPrice when empty', () => {
    expect(component.investForm.controls['investmentPrice'].value).toBe('10000');
  });



});
