import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddStockComponent } from './add-stock/add-stock.component';
import { AddMutualFundComponent } from './add-mutual-fund/add-mutual-fund.component';
import { AddBullionsComponent } from './add-bullions/add-bullions.component';
import { AddBankingInvestmentsComponent } from './add-banking-investments/add-banking-investments.component';
import { ReactiveFormsModule } from '@angular/forms';
import { FormsModule } from '@angular/forms';


 @NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [AddMutualFundComponent, AddStockComponent, AddBullionsComponent, AddBankingInvestmentsComponent],
  exports: [AddStockComponent,
    AddMutualFundComponent, AddBullionsComponent,
    AddBankingInvestmentsComponent
  ]
})
export class AddProductsModule { }
