import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Input } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddBullionsComponent } from './add-bullions.component';

describe('AddBullionsComponent', () => {
  let component: AddBullionsComponent;
  let fixture: ComponentFixture<AddBullionsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AddBullionsComponent],
      imports: [FormsModule, ReactiveFormsModule]

    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddBullionsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

it('should invalidate units when empty', () => {
    expect(component.investForm.controls['units'].value).toBe('1');
  });

  it('should invalidate price when empty', () => {
    expect(component.investForm.controls['price'].value).toBe('12120');
  });


});
