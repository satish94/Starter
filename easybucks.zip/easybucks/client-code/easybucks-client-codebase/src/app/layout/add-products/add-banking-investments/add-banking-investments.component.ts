import { Component, OnInit, Input } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-add-banking-investments',
  templateUrl: './add-banking-investments.component.html',
  styleUrls: ['./add-banking-investments.component.scss']
})
export class AddBankingInvestmentsComponent implements OnInit {


  model;
  date: { year: number, month: number };


  constructor() { }
  @Input('schemeName') schemeName;
  reset: Boolean = false;

  investForm = new FormGroup({
    date: new FormControl('', [Validators.required]),
    amount: new FormControl('1', [Validators.required, Validators.pattern('[1-9]*[0-9]+')]),
    rateOfInvestment: new FormControl('7.0', [Validators.required, Validators.pattern('[1-9 ]*[0-9]+[.][0-9 ]+')])
  });



  get amount() {
    return this.investForm.get('amount');
  }

  get rateOfInvestment() {
    return this.investForm.get('rateOfInvestment');
  }

  submitForm() {

  }


  resetForm() {
    this.investForm.reset();
    this.reset = true;
    this.investForm = new FormGroup({
      date: new FormControl('', [Validators.required]),
      amount: new FormControl('1', [Validators.required, Validators.pattern('[1-9]*[0-9]+')]),
      rateOfInvestment: new FormControl('7.0', [Validators.required, Validators.pattern('[1-9]*[0-9]+[.][0-9]+')])
    });
    this.reset = false;
  }

  ngOnInit() {
  }

}
