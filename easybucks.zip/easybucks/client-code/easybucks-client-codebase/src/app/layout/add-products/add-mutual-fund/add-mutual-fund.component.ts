import { Component, OnInit, Input } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-add-mutual-fund',
  templateUrl: './add-mutual-fund.component.html',
  styleUrls: ['./add-mutual-fund.component.scss']
})
export class AddMutualFundComponent implements OnInit {

  constructor() { }

  @Input('schemeName') schemeName;
  reset: Boolean = false;

  investForm = new FormGroup({
    date: new FormControl('', [Validators.required]),
    numberOfMutualFunds: new FormControl('1', [Validators.required, Validators.pattern('[1-9]*[0-9]+')]),
    investmentPrice: new FormControl('10000', [Validators.required, Validators.pattern('[1-9]*[0-9]+')])

  });



  get numberOfMutualFunds() {
    return this.investForm.get('numberOfMutualFunds');
  }

  get investmentPrice() {
    return this.investForm.get('investmentPrice');
  }

  submitForm() {

  }


  resetForm() {
    this.investForm.reset();
    this.reset = true;
    this.investForm = new FormGroup({
    date: new FormControl('', [Validators.required]),
    numberOfMutualFunds: new FormControl('1', [Validators.required, Validators.pattern('[1-9]*[0-9]+')]),
    investmentPrice: new FormControl('10000', [Validators.required, Validators.pattern('[1-9]*[0-9]+')])

  });

    this.reset = false;
  }
  ngOnInit() {
  }

}
