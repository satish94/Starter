import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Input } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AddStockComponent } from './add-stock.component';

describe('AddStockComponent', () => {
  let component: AddStockComponent;
  let fixture: ComponentFixture<AddStockComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [AddStockComponent],
      imports: [FormsModule, ReactiveFormsModule]

    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddStockComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should invalidate numberOfStocks when empty', () => {
    expect(component.investForm.controls['numberOfStocks'].value).toBe('1');
  });

  it('should invalidate investmentPrice when empty', () => {
    expect(component.investForm.controls['investmentPrice'].value).toBe('1000');
  });


});
