import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfileRoutingModule } from './profile-routing.module';
import { ProfileComponent } from './profile.component';
import { PageHeaderModule } from '../../shared';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import {ProfileService} from './profile.service';

@NgModule({
    imports: [CommonModule, ProfileRoutingModule, PageHeaderModule, FormsModule, ReactiveFormsModule, NgbModule],
    declarations: [ProfileComponent],
    providers: [ProfileService]
})
export class ProfileModule {}
