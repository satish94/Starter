export class Profile {
    private userId: number;
    private roleId: number;
    private userDOB: string;
    private userOccupation: string;
    private userCity: string;
    private userIncome: number;
    private userPhone: number;
    private userName: string;
    private userEmail: string;
    private userPassword: string;


    constructor(
        userId: number,
    roleId: number,
    userDOB: string,
    userOccupation: string,
    userCity: string,
    userIncome: number,
    userPhone: number,
    userName: string,
    userEmail: string,
    userPassword: string


    ) {
        this.userId = userId;
        this.roleId = roleId;
        this.userDOB = userDOB;
        this.userOccupation = userOccupation;
        this.userCity = userCity;
        this.userIncome = userIncome;
        this.userPhone = userPhone;
        this.userName = userName;
        this.userEmail = userEmail;
        this.userPassword = userPassword;


    }

    set UserId(userId: number) {
        this.userId = userId;
    }

    set RoleId(roleId: number) {
        this.roleId = roleId;
    }

    set UserOccupation(userOccupation: string) {
        this.userOccupation = userOccupation;
    }

    set UserDOB(userDOB: string) {
        this.userDOB = userDOB;
    }

    set UserCity(userCity: string) {
        this.userCity = userCity;
    }

    set UserIncome(userIncome: number) {
        this.userIncome = userIncome;
    }

    set UserPhone(userPhone: number) {
        this.userPhone = userPhone;
    }

    set UserName(userName: string) {
        this.userName = userName;
    }

    set UserEmail(userEmail: string) {
        this.userEmail = userEmail;
    }

    set UserPassword(userPassword: string) {
        this.userPassword = userPassword;
    }


}
