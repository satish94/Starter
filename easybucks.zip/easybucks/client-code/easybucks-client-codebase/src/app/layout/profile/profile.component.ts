import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';
import { FormGroup, FormControl, Validators } from '@angular/forms';


import { Router, NavigationEnd } from '@angular/router';
import { ProfileService } from './profile.service';
import { Profile } from './profile';
import { User } from '../../user/user';
@Component({
    selector: 'app-profile',
    templateUrl: './profile.component.html',
    styleUrls: ['./profile.component.scss'],
    animations: [routerTransition()]
})
export class ProfileComponent implements OnInit {

    loggedInUser: User = new User();
    displayId: number;
    message: string;
    editedProfile = new Profile(null, null, null, '', '', null, null, '', '', '');
    temp: string;
    profile = {
        userCity: '',
        userDOB: '',
        userEmail: '',
        userId: '',
        userIncome: '',
        userName: '',
        userOccupation: '',
        userPassword: '',
        userPhone: '',
        userRole: {
            roleId: 0,
            roleName: ''
        }
    };
    form = new FormGroup({
        name: new FormControl({ value: '', disabled: true }),
        email: new FormControl({ value: '', disabled: true }),
        city: new FormControl({ value: '', disabled: true }),
        // state: new FormControl({ value: '', disabled: true }),
        // zip: new FormControl({ value: '', disabled: true }),
        dob: new FormControl({ value: '', disabled: true }),
        occupation: new FormControl({ value: '', disabled: true }),
        income: new FormControl({ value: '', disabled: true }),
        mob: new FormControl({ value: '', disabled: true }),


    });

    get name() {

        return this.form.get('name');
    }

    get dob() {
        return this.form.get('dob');
    }
    get city() {
        return this.form.get('city');
    }
    // get state() {
    //     return this.form.get('state');
    // }
    // get zip() {
    //     return this.form.get('zip');
    // }

    get occupation() {
        return this.form.get('occupation');
    }
    get income() {
        return this.form.get('income');
    }
    get mob() {
        return this.form.get('mob');
    }

    Save() {
        this.message="Profile updated successfully!!"
        this.editedProfile.UserId = this.loggedInUser.userId;
        this.editedProfile.RoleId = this.loggedInUser.userRole.roleId;
        this.editedProfile.UserOccupation = this.form.get('occupation').value;
        this.editedProfile.UserDOB = this.form.get('dob').value;
        this.editedProfile.UserCity = this.form.get('city').value;
        this.editedProfile.UserIncome = this.form.get('income').value;
        this.editedProfile.UserPhone = this.form.get('mob').value;
        this.editedProfile.UserName = this.profile.userName;
        this.editedProfile.UserEmail = this.profile.userEmail;
        this.editedProfile.UserPassword = this.profile.userPassword;


        const annu = <HTMLInputElement>document.getElementById('annual');
        annu.disabled = true;
         const occupation = <HTMLInputElement>document.getElementById('occupation');
        occupation.disabled = true;
        const dob = <HTMLInputElement>document.getElementById('dob');
        dob.disabled = true;


        const mob = <HTMLInputElement>document.getElementById('mob');
        mob.disabled = true;
        const city = <HTMLInputElement>document.getElementById('city');
        city.disabled = true;
        this.data.updateProfile(this.editedProfile).subscribe(
            res => {              
            }

        );
        this.callSnackBar();
    }



    Edit() {

        const annu = <HTMLInputElement>document.getElementById('annual');
        annu.disabled = false;
        const occupation = <HTMLInputElement>document.getElementById('occupation');
        occupation.disabled = false;
        const dob = <HTMLInputElement>document.getElementById('dob');
        dob.disabled = false;


        const mob = <HTMLInputElement>document.getElementById('mob');
        mob.disabled = false;
        const city = <HTMLInputElement>document.getElementById('city');
        city.disabled = false;


        this.form = new FormGroup({
            name: new FormControl(this.profile.userName),
            email: new FormControl(this.profile.userEmail),
            // tslint:disable-next-line:max-line-length
            city: new FormControl(this.profile.userCity, [Validators.required, Validators.pattern('^\\w+\\s*\\w*$')]),

            dob: new FormControl(this.profile.userDOB, [Validators.required]),

            // tslint:disable-next-line:max-line-length
            occupation: new FormControl(this.profile.userOccupation, Validators.compose([Validators.required, Validators.pattern('^\\D+$')])),
            income: new FormControl(this.profile.userIncome, [Validators.required, Validators.pattern('[1-9]{1}[0-9]{3,10}')]),
            mob: new FormControl(this.profile.userPhone, [Validators.required, Validators.pattern('^([7-9][0-9]{9})$')]),


        });

    }

    constructor(private data: ProfileService,private router: Router) { 

        this.router.routeReuseStrategy.shouldReuseRoute = function(){
        return false;
    }
    this.router.events.subscribe((evt) => {
        if (evt instanceof NavigationEnd) {
           
           this.router.navigated = false;
           
           window.scrollTo(0, 0);
        }
    });

    }

    ngOnInit() {

        const userDetail = sessionStorage.getItem('userDetail');
        this.loggedInUser = JSON.parse(userDetail);
        this.displayId = this.loggedInUser.userId;

        this.data.getProfile(this.displayId).subscribe((pro: {
            userCity: '',
            userDOB: '',
            userEmail: '',
            userId: '',
            userIncome: '',
            userName: '',
            userOccupation: '',
            userPassword: '',
            userPhone: '',
            userRole: {
                roleId: 0,
                roleName: ''
            }
        }) => {
            this.profile = pro;
        }

        );




    }

    callSnackBar()
    {
        var x = document.getElementById("snackbar")    
        x.className = "show";
        setTimeout(function(){ x.className = x.className.replace("show", ""); }, 2500); 
        setTimeout(() => {this.router.navigate(['/profile']);},2750);
    }
}
