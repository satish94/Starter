import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { Profile } from './profile';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { post_header } from '../../EasyBucks';
import { EasyBucksConstants } from './../../EasyBucks';
@Injectable()
export class ProfileService {

  private _options ;
  private _baseUrl = EasyBucksConstants.baseUrl + 'profile/' ;
  constructor(private http: HttpClient) {
    this._options = new RequestOptions({ headers: post_header});
   }

  getProfile(id): Observable <any> {
    return this.http.get( this._baseUrl + id);
  }

  updateProfile(updatedProfile: Profile) {
    //console.log(updatedProfile);
    return this.http.post(this._baseUrl + 'update', updatedProfile, this._options);
    //return this.http.post('http://localhost:8081/easybucks/profile/update', updatedProfile, this._options);
  }
}


