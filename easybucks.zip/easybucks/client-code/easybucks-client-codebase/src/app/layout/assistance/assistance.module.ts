import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AssistanceRoutingModule } from './assistance-routing.module';
import { AssistanceComponent } from './assistance.component';
import { PageHeaderModule } from './../../shared';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms'
import { AssistanceService } from "./assistance.service";
import { MatTabsModule } from "@angular/material/tabs";
import { MatCardModule} from "@angular/material";

@NgModule({
    imports: [CommonModule, AssistanceRoutingModule, PageHeaderModule,FormsModule,MatTabsModule,MatCardModule],
    declarations: [AssistanceComponent],
    providers : [AssistanceService]
})
export class AssistanceModule { }
