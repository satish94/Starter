import { HttpClientModule } from '@angular/common/http';
import { AssistanceService } from './assistance.service';
import { FormsModule } from '@angular/forms';
import { PageHeaderModule } from './../../shared/modules/page-header/page-header.module';
import { AssistanceRoutingModule } from './assistance-routing.module';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AssistanceComponent } from './assistance.component';

describe('GridComponent', () => {
  let component: AssistanceComponent;
  let fixture: ComponentFixture<AssistanceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AssistanceComponent ],
      imports: [
        AssistanceRoutingModule,
         PageHeaderModule,
         FormsModule,
         HttpClientModule
         ],
          providers : [AssistanceService]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AssistanceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
