import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { EasyBucksConstants } from "../../EasyBucks";
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { post_header } from '../../EasyBucks';

@Injectable()
export class AssistanceService {
    private _baseUrl = EasyBucksConstants.baseUrl ;
    options ;
  constructor(private http : HttpClient) {
    this.options = new RequestOptions({ headers: post_header});
   }


  getAllUsers()
  {
    return this.http.get(this._baseUrl +"seekassistance/allusers");
    //return this.http.get("http://localhost:8081/easybucks/seekassistance/allusers");
  }

  addAssistance(seekAssistanceAdd)
  {
   return this.http.post(this._baseUrl+"seekassistance/addAssistance",seekAssistanceAdd,this.options);
    //return this.http.post("http://localhost:8081/easybucks/seekassistance/addAssistance",seekAssistanceAdd,this.options);
  }

  updateAssistance(seekAssistanceUpdate)
  {
    return this.http.put(this._baseUrl+"seekassistance/updateAssistance",seekAssistanceUpdate,this.options);
    //return this.http.put("http://localhost:8081/easybucks/seekassistance/updateAssistance",seekAssistanceUpdate,this.options);
  }

  deleteAssistance(id)
  {
    return this.http.delete(this._baseUrl+"seekassistance/deleteAssistance/"+id);
    //return this.http.delete("http://localhost:8081/easybucks/seekassistance/deleteAssistance/"+id);
  }

  getAllAssistanceDetails()
  {
    return this.http.get(this._baseUrl +"seekassistance/alldetails");
    //return this.http.get("http://localhost:8081/easybucks/seekassistance/alldetails");
  }

  addAppointment(bookAppointmentAdd)
  {
    return this.http.post(this._baseUrl+"seekassistance/addBookAppointment",bookAppointmentAdd,this.options);
    //return this.http.post("http://localhost:8081/easybucks/seekassistance/addBookAppointment",bookAppointmentAdd,this.options);
  }

  getAllAppointments()
  {
    return this.http.get(this._baseUrl +"seekassistance/allAppointments");
    //return this.http.get("http://localhost:8081/easybucks/seekassistance/allAppointments");
  }

  updateAppointment(bookAppointmentUpdate)
  {
    return this.http.put(this._baseUrl+"seekassistance/updateBookAppointment",bookAppointmentUpdate,this.options);
    //return this.http.put("http://localhost:8081/easybucks/seekassistance/updateBookAppointment",bookAppointmentUpdate,this.options);
  }

  deleteAppointment(id)
  {
    return this.http.delete(this._baseUrl+"seekassistance/deleteAppointment/"+id);
    //return this.http.delete("http://localhost:8081/easybucks/seekassistance/deleteAppointment/"+id);
  }
}
