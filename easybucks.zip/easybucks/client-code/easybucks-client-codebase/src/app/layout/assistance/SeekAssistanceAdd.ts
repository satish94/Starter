export class SeekAssistanceAdd
{
    private investor : number;
    private advisor : number;
    private query : string;
    private answer : string;
    private status : string;
    
    constructor(
        investor : number,
        advisor : number,
        query : string,
        answer : string,
        status : string
    )
    {
        this.investor=investor;
        this.advisor=advisor;
        this.query=query;
        this.answer=answer;
        this.status=status;
    }

    set Investor(investor : number)
    {
        this.investor=investor;
    }

    set Advisor(advisor : number)
    {
        this.advisor=advisor;
    }

    set Query(query : string)
    {
        this.query=query;
    }

    set Answer(answer : string)
    {
        this.answer=answer;
    }

    set Status(status : string)
    {
        this.status=status;
    }

    get Investor() : number
    {
        return this.investor;
    }

    get Advisor() : number
    {
        return this.advisor;
    }

    get Query() : string
    {
        return this.query;
    }

    get Answer() : string
    {
        return this.answer;
    }

    get Status() : string
    {
        return this.status;
    }
}