export class BookAppointmentAdd
{
    investor:number;
    advisor:number;
    reason:string;
    appointmentDate:string;
    place:string;
    status:string;

    constructor(
        investor:number,
        advisor:number,
        reason:string,
        appointmentDate:string,
        place:string,
        status:string
    )
    {
        this.investor=investor;
        this.advisor=advisor;
        this.reason=reason;
        this.appointmentDate=appointmentDate;
        this.place=place;
        this.status=status;
    }

    set Investor(investor : number)
    {
        this.investor=investor;
    }

    set Advisor(advisor : number)
    {
        this.advisor=advisor;
    }

    set Reason(reason : string)
    {
        this.reason=reason;
    }

    set AppointmentDate(appointmentDate : string)
    {
        this.appointmentDate=appointmentDate;
    }

    set Place(place : string)
    {
        this.place=place;
    }

    set Status(status : string)
    {
        this.status=status;
    }
}