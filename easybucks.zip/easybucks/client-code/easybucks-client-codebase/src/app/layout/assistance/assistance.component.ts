import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';
import { SeekAssistanceAdd } from "./SeekAssistanceAdd";
import { SeekAssistanceUpdate } from "./SeekAssistanceUpdate";
import { AssistanceService } from "./assistance.service";
import { $ } from "protractor/built";
import { User } from "../../user/user";
import { Role } from "../../user/role";
import { Router, NavigationEnd } from '@angular/router';
import { BookAppointmentAdd } from "./BookAppointmentAdd";
import { BookAppointmentUpdate } from "./BookAppointmentUpdate";



@Component({
    selector: 'app-assistance',
    templateUrl: './assistance.component.html',
    styleUrls: ['./assistance.component.scss'],
    animations: [routerTransition()]
})
export class AssistanceComponent implements OnInit {
        message: string;
        msg: string;

    loggedInUser: User = new User();

    alladvisors: any[];
    userRole: any[];
    approvedRequests: any[];
    pendingAppointments: any[];
    pendingQueries:any[];
    
    advisorSeekAssistanceIdSelectedValue:number;
    advisorSeekAssistanceIdValue:number;
    advisorEnteredAnswer:string;
    advisorAnswered:string;
    investorIdUpdate:number;
    advisorIdUpdate:number;
    queryUpdate:string;

        

    advisorId:number;
    queryEntered:string;
    loggedInInvestorId:number;
    loggedInAdvisorId:number;
    loggedInAdminId:number;
    
    
    seekAssistanceAdd = new SeekAssistanceAdd(null,null,'','',''); 
    seekAssistanceUpdate = new SeekAssistanceUpdate(null,null,null,'','',''); 
    bookAppointmentAdd = new BookAppointmentAdd(null,null,'','','','');
    bookAppointmentUpdate = new BookAppointmentUpdate(null,null,null,'','','','');

    advisorName:string;
    advisorNamevalue:string;
    query:string;
    
    role:string;
    
    
    allusers:any[] 
    allAssistanceDetails: any[]; 
    allAppointmentDetails:any[];
    allInvestorsQueries:any[];
    investorsAppointments:any[];

   
    investorDiv:boolean;
    advisorDiv:boolean;
    adminDiv:boolean;
    isPending:boolean;

    selecteddate:string;
    reason:string;
    place:string;

    cdate:string;
    mdate:string;
    isVal:boolean;

    appointmentUpdateInvestor:number;
    appointmentUpdateReason:string;
    appointmentUpdatePlace:string;
    appointmentUpdateDate:string;
    isPendingAppointments:boolean;
    isInvestorsQueries:boolean;
    isQueriesPending:boolean;
    isInvestorAppointments:boolean;

    
    constructor(private assistanceService:AssistanceService , public router : Router) 
    {
        this.router.routeReuseStrategy.shouldReuseRoute = function(){
        return false;
    }
    this.router.events.subscribe((evt) => {
        if (evt instanceof NavigationEnd) {
           
           this.router.navigated = false;
           
           window.scrollTo(0, 0);
        }
    });

    }

    ngOnInit() 
    {

        let userDetail = sessionStorage.getItem("userDetail");
        this.loggedInUser = JSON.parse(userDetail);
        this.role = this.loggedInUser.userRole.roleName;
        this.loggedInInvestorId = this.loggedInUser.userId;
        this.loggedInAdvisorId = this.loggedInUser.userId;
        this.loggedInAdminId = this.loggedInUser.userId;
        
        
        if (this.role == "investor")
        {
            this.investorDiv = true;
            this.advisorDiv = false;
            this.adminDiv = false;
        }
        
        else if(this.role == "advisor")
        {
            this.investorDiv = false;
            this.advisorDiv = true;
            this.adminDiv = false;
        }
        else
        {
            this.investorDiv = false;
            this.advisorDiv = false;
            this.adminDiv = true;
        }

        
        this.assistanceService.getAllUsers().subscribe((data:any[])=>{
             this.allusers=data;
             this.alladvisors = this.allusers.filter((elem)=>{
                   return elem.userRole.roleName == 'advisor';
              })
        }
        )
       
     

       this.assistanceService.getAllAppointments().subscribe((data:any[])=>{
           this.allAppointmentDetails=data;
           this.pendingAppointments = this.allAppointmentDetails.filter((elem)=>{
               return (elem.status=='pending' && elem.advisorId==this.loggedInAdvisorId); 
           })
           this.investorsAppointments = this.allAppointmentDetails.filter((elem)=>{
                return (elem.investorId==this.loggedInInvestorId)
           })
           if(this.pendingAppointments.length==0)
           {
                this.isPendingAppointments=false;
           }
           else
           {
               this.isPendingAppointments=true;
           }
           if(this.investorsAppointments.length==0)
           {
                this.isInvestorAppointments=false;
           }
           else
           {
                this.isInvestorAppointments=true;
           }

       })

        
        this.assistanceService.getAllAssistanceDetails().subscribe((data:any[])=>{
            this.allAssistanceDetails=data;
            this.approvedRequests = this.allAssistanceDetails.filter((ele)=>{
                    return (ele.answer == '' && ele.status == 'approved');
            })

                    
                    if(this.approvedRequests.length==0)
                    {
                        this.isPending=false;
                    }
                    else
                    {
                        this.isPending=true;
                    }
                     
        })


        this.assistanceService.getAllAssistanceDetails().subscribe((data:any[])=>{
            this.allAssistanceDetails=data;
            this.pendingQueries = this.allAssistanceDetails.filter((ele)=>{
                    return (ele.status == 'pending');
            })

                    
                    if(this.pendingQueries.length==0)
                    {
                        this.isQueriesPending=false;
                    }
                    else
                    {
                        this.isQueriesPending=true;
                    }
                    
        })

        this.assistanceService.getAllAssistanceDetails().subscribe((data:any[])=>{
            this.allAssistanceDetails=data;
            this.allInvestorsQueries = this.allAssistanceDetails.filter((ele)=>{
                return ele.investorId==this.loggedInInvestorId;
            })
                if(this.allInvestorsQueries.length==0)
                {
                    this.isInvestorsQueries=false;
                }
                else
                {
                    this.isInvestorsQueries=true;
                }
        })

        let today=new Date();
        let mtoday:string;
        let year=today.getFullYear();
        let month=today.getMonth()+1;
        let day=today.getDate();
        let hours=today.getHours();
        let min=today.getMinutes();
        let md:string;
        let mm:string;
        let mm1:string;
        let mh:string;
        let mmin:string;
        let msg:string;
    
        if(day<10) 
        {
            md = '0'+day.toString();
        }
        else
        {
            md = day.toString();
        } 

        if(month<10) 
        {
            mm = '0'+month.toString();
            mm1 = '0'+(month+2).toString();           
        }
        else
        {
            mm = month.toString();
            mm1 = (month+1).toString();
        }
        if(min<10)
        {
            mmin='0'+min.toString();
        }
        else
        {
            mmin=min.toString();
        }
        if(hours<10)
        {
            mh = '0'+hours.toString();
        }
        else
        {
            mh=hours.toString();
        }
       
        mtoday=year+'-'+mm+'-'+day+'T'+mh+':'+mmin;
    
        this.cdate=mtoday;
        this.mdate=year+'-'+mm1+'-'+day+'T'+mh+':'+mmin;
        console.log(this.cdate);
        console.log(this.mdate);
        

        this.assistanceService.getAllAppointments().subscribe((data:any[])=>{
        this.allAppointmentDetails=data;
        }
        )

        

    }


    
    addDetails()
    {       
        this.message='Query submitted successfully!';
        
        this.advisorName = this.advisorNamevalue; 
        
        this.queryEntered=this.query; 
        
        this.findUserId(this.advisorName); 

        this.seekAssistanceAdd.Investor=this.loggedInInvestorId; 
        this.seekAssistanceAdd.Advisor=this.advisorId; 
        this.seekAssistanceAdd.Query=this.queryEntered; 
        this.seekAssistanceAdd.Status='pending';

        this.assistanceService.addAssistance(this.seekAssistanceAdd).subscribe(
            res=>{
                
            }
        )
        this.callSnackBar();
    }


    
    updateDetails()
    {

        this.message='Query Answered Successfully!';
        this.advisorSeekAssistanceIdSelectedValue=this.advisorSeekAssistanceIdValue;
        this.advisorEnteredAnswer=this.advisorAnswered;
        this.findUpdates(this.advisorSeekAssistanceIdSelectedValue);
        
        this.seekAssistanceUpdate.SeekAssistanceId=this.advisorSeekAssistanceIdSelectedValue;
        this.seekAssistanceUpdate.Investor=this.investorIdUpdate;
        this.seekAssistanceUpdate.Advisor=this.advisorIdUpdate;
        this.seekAssistanceUpdate.Query=this.queryUpdate;
        this.seekAssistanceUpdate.Answer=this.advisorEnteredAnswer;
        this.seekAssistanceUpdate.Status='answered';
        this.assistanceService.updateAssistance(this.seekAssistanceUpdate).subscribe(
            res=>{
                
            }
        )
        this.callSnackBar();
    }

    
    


    getAllSeekAssistanceData()
    {
       this.assistanceService.getAllAssistanceDetails().subscribe((data:any[])=>{
            this.allAssistanceDetails=data;
            
        })
    }

    
    findUserId(advi)
    {
        for(let user of this.allusers)
        {
            if(user.userName==advi)
            {
                this.advisorId=user.userId;
            }
        }
    }


    findUpdates(seekAssistanceId)
    {
        for(let assistance of this.allAssistanceDetails)
        {
            if(assistance.seekAssistanceId==seekAssistanceId)
            {
                this.investorIdUpdate=assistance.investorId;
                this.advisorIdUpdate=assistance.advisorId;
                this.queryUpdate=assistance.query;
            }
        }
    }

    

    approveQuery(id)
    {
        this.message='Query Approved Successfully!'
        console.log(id);
        this.findUpdates(id);
        this.seekAssistanceUpdate.SeekAssistanceId = id;
        this.seekAssistanceUpdate.Investor=this.investorIdUpdate;
        this.seekAssistanceUpdate.Advisor=this.advisorIdUpdate;
        this.seekAssistanceUpdate.Query=this.queryUpdate;
        this.seekAssistanceUpdate.Status='approved';
        this.assistanceService.updateAssistance(this.seekAssistanceUpdate).subscribe(
            res=>{
                
            }
        )
        
        this.callSnackBar();
    }

    declineQuery(id)
    {
        this.message='Query Deleted Successfully'
        this.assistanceService.deleteAssistance(id).subscribe(
            res=>{

            }
        )
        this.callSnackBar();
    }

    postAppointmentDetails()
    {
        this.message='Appointment Booked Successfully'
        this.advisorName = this.advisorNamevalue;
        this.findUserId(this.advisorName); 
        this.bookAppointmentAdd.Investor=this.loggedInInvestorId;
        this.bookAppointmentAdd.Advisor = this.advisorId;
        this.bookAppointmentAdd.Reason=this.reason;
        this.bookAppointmentAdd.AppointmentDate=this.selecteddate;
        this.bookAppointmentAdd.Place=this.place;
        this.bookAppointmentAdd.Status='pending';
        this.assistanceService.addAppointment(this.bookAppointmentAdd).subscribe(
            res=>{

            }
        )
        this.callSnackBar();
    }

    findAppointmentUpdate(bookAppointmentId)
    {
        for(let appointment of this.allAppointmentDetails)
        {
            if(appointment.bookAppointmentId==bookAppointmentId)
            {
                this.appointmentUpdateInvestor=appointment.investorId;
                this.appointmentUpdateReason=appointment.reason;
                this.appointmentUpdateDate=appointment.appointmentDate;
                this.appointmentUpdatePlace=appointment.place;
            }
        }
    }

    acceptAppointment(i)
    {
        this.message='Appointment Approved Successfully!'
        console.log(i);
        this.findAppointmentUpdate(i);
        this.bookAppointmentUpdate.BookAppointmentId=i;
        this.bookAppointmentUpdate.Investor=this.appointmentUpdateInvestor;
        this.bookAppointmentUpdate.Advisor=this.loggedInAdvisorId;
        this.bookAppointmentUpdate.Reason=this.appointmentUpdateReason;
        this.bookAppointmentUpdate.AppointmentDate=this.appointmentUpdateDate;
        this.bookAppointmentUpdate.Place=this.appointmentUpdatePlace;
        this.bookAppointmentUpdate.Status='approved';
        this.assistanceService.updateAppointment(this.bookAppointmentUpdate).subscribe(
            res=>{}
        )
        this.callSnackBar();
    }

    declineAppointment(i)
    {
        this.message='Appointment Deleted Successfully!'
        this.assistanceService.deleteAppointment(i).subscribe(
            res=>{}
        )
        this.callSnackBar();
    }

    callSnackBar()
    {
        var x = document.getElementById("snackbar")    
        x.className = "show";
        setTimeout(function(){ x.className = x.className.replace("show", ""); }, 2500); 
        setTimeout(() => {this.router.navigate(['/assistance']);},2750);
    }

    

    
}
