import { TestBed, inject } from '@angular/core/testing';

import { BulliansService } from './bullians.service';

describe('BulliansService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [BulliansService]
    });
  });

  it('should be created', inject([BulliansService], (service: BulliansService) => {
    expect(service).toBeTruthy();
  }));
});
