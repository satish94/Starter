import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';

@Component({
    selector: 'app-manage-products',
    templateUrl: './manage-products.component.html',
    styleUrls: ['./manage-products.component.scss'],
    animations: [routerTransition()]
})
export class ManageProductsComponent implements OnInit {
    constructor() {}

    ngOnInit() {}
}
