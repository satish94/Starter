import { HttpClient } from '@angular/common/http';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { Injectable } from '@angular/core';
import { EasyBucksConstants, post_header } from '../../../EasyBucks';

@Injectable()
export class StocksService {
  private _url = EasyBucksConstants.baseUrl + 'products/stocks/';
  private _options ;

  constructor(private _http: Http) {
        this._options = new RequestOptions({ headers: post_header});
   }

  private _handleError(err: any) {
        return Observable.throw(err);
  }

  private _extractData(res: Response) {
        const body = res.text();
        return body ? res.json() : {};
  }

  addStocks(stocks: any): Observable<any> {
    return this._http.post( this._url + 'add', stocks, this._options)
          .map(this._extractData)
          .catch(this._handleError);
  }

  getAllStocks(): Observable<any> {
     return this._http.get(this._url + 'all')
            .catch(this._handleError);
    }

    deleteStocks(stocks:any): Observable<any> {
         return this._http.delete(this._url + 'delete/' + stocks.id) ;
    }
}
