import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { BankingService } from './banking.service';
import { BankingListComponent } from './../banking/banking-list/banking-list.component';
import { debounceTime } from 'rxjs/operator/debounceTime';
import { Subject } from 'rxjs/Subject';
import { Router } from '@angular/router';

@Component({
  selector: 'app-banking-form',
  templateUrl: './banking-form.component.html',
  styleUrls: ['./banking-form.component.scss']
})
export class BankingFormComponent implements OnInit {
  bankingForm: FormGroup;
  private _success = new Subject<string>();
  staticAlertClosed = false;
  successMessage: string;
  constructor(fb: FormBuilder, private bankingService: BankingService, private list: BankingListComponent,private router: Router) {
    this.bankingForm = fb.group({
      bankName: ['',
        [Validators.required,
        Validators.pattern('[a-zA-Z0-9 ]+')
        ]],
      type: ['', [Validators.required, Validators.pattern('[a-zA-Z0-9& ]+')]],
      rateOfInterest: ['', [Validators.required, Validators.min(0)]]
    });
  }

  ngOnChanges() {
    this.bankingForm.reset();
  }

  ngOnInit() {
    setTimeout(() => this.staticAlertClosed = true, 10000);
    this._success.subscribe((message) => this.successMessage = message);
    debounceTime.call(this._success, 5000).subscribe(() => this.successMessage = null);
  }

  get bankName() {
    return this.bankingForm.get('bankName');
  }

  get type() {
    return this.bankingForm.get('type');
  }

  get rateOfInterest() {
    return this.bankingForm.get('rateOfInterest');
  }

  get maturityValue() {
    return this.bankingForm.get('maturityValue');
  }

  getNameErrorMessage() {
    return this.bankName.hasError('required') ? 'You must enter a value' :
      this.bankName.hasError('pattern') ? 'Use only Alphabets and spaces' :
        '';
  }

  getTypeErrorMessage() {
    return this.type.hasError('required') ? 'You must enter a value' :
      this.type.hasError('pattern') ? 'Use only Alphabets and spaces' :
        '';
  }

  getROIErrorMessage() {
    return this.rateOfInterest.hasError('required') ? 'You must enter a value' :
      this.rateOfInterest.hasError('min') ? 'Rate Of Interest can not be less than 0' :
        '';
  }

  getMaturityValueErrorMessage() {
    return this.maturityValue.hasError('required') ? 'You must enter a value' :
      this.maturityValue.hasError('min') ? 'Maturity Value can not be less than 0' :
        '';
  }

  onSubmit() {
    this.bankingService.addBanking(this.bankingForm.value)
      .subscribe(response => {
        
      }) ;
    this._success.next('Product Added Successfully') ;
    this.ngOnChanges();
  }
}
