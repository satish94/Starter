import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ManageProductsComponent } from './manage-products.component';

const routes: Routes = [
    {
        path: '',
        component: ManageProductsComponent,
        // children: [
        //     { path: '', redirectTo: 'mutualfunds' },
        //     { path: 'mutualfunds', loadChildren: './mutual-funds/mutual-funds.module#MutualFundsModule' },
        //     { path: 'stocks', loadChildren: './stocks/stocks.module#StocksModule' },
        //     { path: 'bullians', loadChildren: './bullians/bullians.module#BulliansModule' },
        //     { path: 'bullians', loadChildren: './banking/banking.module#BankingModule' },
        // ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ManageProductsRoutingModule {}
