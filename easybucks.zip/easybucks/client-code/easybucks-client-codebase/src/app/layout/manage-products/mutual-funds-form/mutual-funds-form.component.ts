import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { MutualFundsService } from './mutual-funds.service';
// import { BankingListComponent } from './../banking/banking-list/banking-list.component';
import { debounceTime } from 'rxjs/operator/debounceTime';
import { Subject } from 'rxjs/Subject';
@Component({
    selector: 'app-mutual-funds-form',
    templateUrl: './mutual-funds-form.component.html',
    styleUrls: ['./mutual-funds-form.component.scss']
})
export class MutualFundsFormComponent implements OnInit {
    mfForm: FormGroup;
    private _success = new Subject<string>();
    staticAlertClosed = false;
    successMessage: string;
    constructor(fb: FormBuilder, private mfService: MutualFundsService) {
        this.mfForm = fb.group({
            scheme: ['',
                [Validators.required,
                Validators.pattern('[a-zA-Z0-9& ]+')
                ]],
            code: ['',
                [Validators.required,
                Validators.pattern('[a-zA-Z0-9 ]+')
                ]],
            netAssetValue: ['',
                [Validators.required,
                Validators.min(0)
                ]],
            repurchasePrice: ['',
                [Validators.required, Validators.min(0)
                ]],
            salePrice: ['',
                [Validators.required, Validators.min(0)
                ]],
        });
    }

    ngOnChanges() {
        this.mfForm.reset();
    }

    get scheme() {
        return this.mfForm.get('scheme');
    }


    get code() {
        return this.mfForm.get('code');
    }


    get netAssetValue() {
        return this.mfForm.get('netAssetValue');
    }

    get repurchasePrice() {
        return this.mfForm.get('repurchasePrice');
    }

    get salePrice() {
        return this.mfForm.get('salePrice');
    }


    ngOnInit() {
         setTimeout(() => this.staticAlertClosed = true, 10000);

    this._success.subscribe((message) => this.successMessage = message);
    debounceTime.call(this._success, 5000).subscribe(() => this.successMessage = null);
    }
    getSchemeErrorMessage() {
        return this.scheme.hasError('required') ? 'You must enter a value' :
            this.scheme.hasError('pattern') ? 'Use only Alphabets and spaces' :
                '';
    }

    getCodeErrorMessage() {
        return this.code.hasError('required') ? 'You must enter a value' :
            this.code.hasError('pattern') ? 'Use only Alphabets and spaces' :
                '';
    }

    getNavErrorMessage() {
        return this.netAssetValue.hasError('required') ? 'You must enter a value' :
            this.netAssetValue.hasError('min') ? 'Price can not be less than 0' :
                '';
    }

    getRePriceErrorMessage() {
        return this.repurchasePrice.hasError('required') ? 'You must enter a value' :
            this.repurchasePrice.hasError('min') ? 'Price can not be less than 0' :
                '';
    }

    getSalePriceErrorMessage() {
        return this.salePrice.hasError('required') ? 'You must enter a value' :
            this.salePrice.hasError('min') ? 'Price can not be less than 0' :
                '';
    }

    onSubmit() {
        this.mfService.addMF(this.mfForm.value)
            .subscribe(response => {
            });
        this._success.next('Product Added Successfully');
        // this.list.getAll();
        this.ngOnChanges();
    }

}
