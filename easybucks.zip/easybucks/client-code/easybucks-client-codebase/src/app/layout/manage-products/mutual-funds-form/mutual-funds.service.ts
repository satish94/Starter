import { HttpClient } from '@angular/common/http';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { Injectable } from '@angular/core';
import { EasyBucksConstants, post_header } from '../../../EasyBucks';

@Injectable()
export class MutualFundsService {
   private _url = EasyBucksConstants.baseUrl + 'products/mutualfunds/';
  private _options ;


  constructor(private _http: Http) {
      this._options = new RequestOptions({ headers: post_header});
   }

  private _handleError(err: any) {
        return Observable.throw(err);
    }

    private _extractData(res: Response) {
        const body = res.text();
        return body ? res.json() : {};
    }

    addMF(mutualFunds: any): Observable<any> {
    return this._http.post( this._url + 'add', mutualFunds, this._options)
          .map(this._extractData)
          .catch(this._handleError);
  }

  getAllMutualFunds(): Observable<any> {
     return this._http.get(this._url + 'all')
            .catch(this._handleError);
    }

    deleteMf(funds:any): Observable<any> {
         return this._http.delete(this._url + 'delete/' + funds.id) ;
    }

}
