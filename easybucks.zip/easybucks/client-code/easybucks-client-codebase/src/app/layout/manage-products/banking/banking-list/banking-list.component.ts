import { Component, OnInit } from '@angular/core';
import { BankingService } from '../../banking-form/banking.service';
import { Sort, MatTableDataSource, MatSnackBar } from '@angular/material';
import { User } from "../../../../user/user";

@Component({
  selector: 'app-banking-list',
  templateUrl: './banking-list.component.html',
  styleUrls: ['./banking-list.component.scss']
})
export class BankingListComponent implements OnInit {

  private banking: any;
  private sortedData;
  private dataSource;
  loggedInUser: User = new User();
  userDetail: any;
  constructor(private bankingService: BankingService, private snackBar: MatSnackBar) {
    this.getAll();
    this.userDetail = sessionStorage.getItem("userDetail");
    this.loggedInUser = JSON.parse(this.userDetail);

  }


  getAll() {
    this.bankingService.getAllBankings()
      .subscribe(
      response => {
        this.getAllBanking(response.json());
      },
      error => {
        console.log('error in loading products');
      }
      );
  }
  getAllBanking(result: any): void {
    this.banking = result.reverse();
  }
  openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });
  }

  ngOnInit() {
  }
  sortData(sort: Sort) {
    const data = this.banking;
    if (!sort.active || sort.direction === '') {
      this.sortedData = data;
      return;
    }
    this.sortedData = data.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'bankName': return this.compare(a.bankName, b.bankName, isAsc);
        case 'type': return this.compare(+a.type, +b.type, isAsc);
        case 'rateOfInterest': return this.compare(+a.rateOfInterest, +b.rateOfInterest, isAsc);
        default: return 0;
      }
    });
  }
  compare(a, b, isAsc): number {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
  }

  deleteBanking(banking: any) {
    this.bankingService.deleteBanking(banking).subscribe(response => {
      this.banking.splice(this.banking.indexOf(banking), 1);
    });
    this.openSnackBar('Product Deleted Successfully', '');
  }
}
