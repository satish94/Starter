import { HttpClient } from '@angular/common/http';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { Injectable } from '@angular/core';
import { EasyBucksConstants } from '../../../EasyBucks';
import { post_header } from '../../../EasyBucks';
@Injectable()
export class BankingService {
    private _url = EasyBucksConstants.baseUrl + 'products/banking/';
    private _options;

    constructor(private _http: Http) {
        this._options = new RequestOptions({ headers: post_header });
    }

    private _handleError(err: any) {
        return Observable.throw(err);
    }

    private _extractData(res: Response) {
        const body = res.text();
        return body ? res.json() : {};
    }

    addBanking(banking: any): Observable<any> {
        return this._http.post(this._url + 'add', banking, this._options)
            .map(this._extractData)
            .catch(this._handleError);
    }

    getAllBankings(): Observable<any> {
        return this._http.get(this._url + 'all')
            .catch(this._handleError);
    }

    deleteBanking(banking: any): Observable<any> {
        return this._http.delete(this._url + 'delete/' + banking.id);
    }
}
