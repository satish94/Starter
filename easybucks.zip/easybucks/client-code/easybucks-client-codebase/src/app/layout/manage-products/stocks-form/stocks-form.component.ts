import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { StocksService } from './stocks.service';
// import { BankingListComponent } from './../banking/banking-list/banking-list.component';
import { debounceTime } from 'rxjs/operator/debounceTime';
import { Subject } from 'rxjs/Subject';
import { StocksListComponent } from './../stocks/stocks-list/stocks-list.component';
@Component({
  selector: 'app-stocks-form',
  templateUrl: './stocks-form.component.html',
  styleUrls: ['./stocks-form.component.scss']
})
export class StocksFormComponent implements OnInit {

  stocksForm: FormGroup;
  private _success = new Subject<string>();
  staticAlertClosed = false;
  successMessage: string;
  stocksList: StocksListComponent ;

  constructor(fb: FormBuilder, private stocksService: StocksService) {
    this.stocksForm = fb.group({
      name: ['', [Validators.required, Validators.pattern('[a-zA-Z0-9& ]+')]],
      code: ['', [Validators.required, Validators.pattern('[a-zA-Z0-9 ]+')]],
      currTradingPrice: [ '', [Validators.required, Validators.min(0)]],
      lastTradingPrice: ['', [Validators.required, Validators.min(0)]]
    }) ;
  }

  ngOnChanges() {
    this.stocksForm.reset();
  }

  ngOnInit() {
    setTimeout(() => this.staticAlertClosed = true, 10000);
    this._success.subscribe((message) => this.successMessage = message);
    debounceTime.call(this._success, 5000).subscribe(() => this.successMessage = null);
  }

  get name() {
    return this.stocksForm.get('name');
  }

  get code() {
    return this.stocksForm.get('code');
  }

  get currTradingPrice() {
    return this.stocksForm.get('currTradingPrice') ;
  }

  get lastTradingPrice() {
    return this.stocksForm.get('lastTradingPrice') ;
  }

  getNameErrorMessage() {
    return this.name.hasError('required') ? 'You must enter a value' :
        this.name.hasError('pattern') ? 'Use only Alphabets and spaces' :
            '';
  }

  getCodeErrorMessage() {
    return this.code.hasError('required') ? 'You must enter a value' :
        this.code.hasError('pattern') ? 'Use only Alphabets and spaces' :
            '';
  }

  getCurrTradingPriceErrorMessage() {
    return this.currTradingPrice.hasError('required') ? 'You must enter a value' :
        this.currTradingPrice.hasError('min') ? 'Price can not be less than 0' :
            '';
  }

  getLastTradingPriceErrorMessage() {
    return this.lastTradingPrice.hasError('required') ? 'You must enter a value' :
        this.lastTradingPrice.hasError('min') ? 'Price can not be less than 0' :
            '';
  }

  onSubmit() {
    this.stocksService.addStocks(this.stocksForm.value)
      .subscribe(response => {
      }) ;
    this._success.next('Product Added Successfully') ;
    this.ngOnChanges();
  }
}
