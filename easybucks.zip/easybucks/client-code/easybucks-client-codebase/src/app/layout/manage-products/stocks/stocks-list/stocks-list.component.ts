import { Component, OnInit } from '@angular/core';
import { Sort, MatTableDataSource, MatSnackBar } from '@angular/material';
import { StocksService } from '../../stocks-form/stocks.service';
import { User } from "../../../../user/user";

@Component({
  selector: 'app-stocks-list',
  templateUrl: './stocks-list.component.html',
  styleUrls: ['./stocks-list.component.scss']
})
export class StocksListComponent implements OnInit {
  public stocks: any;
  private sortedData;
  private dataSource ;
    loggedInUser: User = new User();
  userDetail: any;
  constructor(private stocksService: StocksService, private snackBar: MatSnackBar) {
    this.getAll();
         this.userDetail = sessionStorage.getItem("userDetail");
        this.loggedInUser = JSON.parse(this.userDetail);
  }

  getAll() {
    this.stocksService.getAllStocks()
      .subscribe(
      response => {
        this.getAllStocks(response.json());
      },
      error => {
        console.log('error in loading products');
      }
      );
  }
  getAllStocks(result: any): void {
    this.stocks = result.reverse();
  }
     openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });
      }

  ngOnInit() {
  }

  sortData(sort: Sort) {
    const data = this.stocks ;
    if (!sort.active || sort.direction === '') {
      this.sortedData = data;
      return;
    }
    this.sortedData = data.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'name': return this.compare(a.name, b.name, isAsc);
        case 'code': return this.compare(+a.code, +b.code, isAsc);
        case 'currTradingPrice': return this.compare(+a.currTradingPrice, +b.currTradingPrice, isAsc);
        case 'lastTradingPrice': return this.compare(+a.lastTradingPrice, +b.lastTradingPrice, isAsc);
        default: return 0;
      }
    });
  }
  compare(a, b, isAsc): number {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}

deleteStocks(stocks: any){
  this.stocksService.deleteStocks(stocks).subscribe(response=>{
  this.stocks.splice(this.stocks.indexOf(stocks),1) ;
}) ;
this.openSnackBar('Product Deleted Successfully','') ;
}

}
