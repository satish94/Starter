import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BulliansFormComponent } from './bullians-form.component';

describe('BulliansFormComponent', () => {
  let component: BulliansFormComponent;
  let fixture: ComponentFixture<BulliansFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BulliansFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BulliansFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
