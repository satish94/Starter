import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { routerTransition } from '../../../router.animations';

@Component({
  selector: 'app-navigation',
  templateUrl: './navigation.component.html',
  styleUrls: ['./navigation.component.scss'],
  animations: [routerTransition()],
  encapsulation: ViewEncapsulation.None,
})
export class NavigationComponent implements OnInit {

  constructor() {}

  ngOnInit() {
  }

}
