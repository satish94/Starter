import { Component, OnInit } from '@angular/core';
import { Sort, MatTableDataSource, MatSnackBar } from '@angular/material';
import { BulliansService } from '../../bullians-form/bullians.service';
import { User } from "../../../../user/user";

@Component({
  selector: 'app-bullians-list',
  templateUrl: './bullians-list.component.html',
  styleUrls: ['./bullians-list.component.scss']
})
export class BulliansListComponent implements OnInit {
  private bullians: any;
  private sortedData;
  private dataSource;
  loggedInUser: User = new User();
  userDetail: any;
  constructor(private bulliansService: BulliansService, private snackBar: MatSnackBar) {
    this.getAll();
     this.userDetail = sessionStorage.getItem("userDetail");
        this.loggedInUser = JSON.parse(this.userDetail);
  }

  getAll() {
    this.bulliansService.getAllBullians()
      .subscribe(
      response => {
        this.getAllBullians(response.json());
      },
      error => {
        console.log('error in loading products');
      }
      );
  }
  getAllBullians(result: any): void {
    this.bullians = result.reverse();
  }
     openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });
      }

  ngOnInit() {
  }
  sortData(sort: Sort) {
    const data = this.bullians;
    if (!sort.active || sort.direction === '') {
      this.sortedData = data;
      return;
    }
    this.sortedData = data.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'name': return this.compare(a.name, b.name, isAsc);
        case 'price': return this.compare(+a.price, +b.price, isAsc);
        default: return 0;
      }
    });
  }
  compare(a, b, isAsc): number {
    return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
  }

  deleteBullians(bullians: any){
  this.bulliansService.deleteBullians(bullians).subscribe(response=>{
  this.bullians.splice(this.bullians.indexOf(bullians),1) ;
}) ;
this.openSnackBar('Product Deleted Successfully','') ;
}
}
