import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MutualFundsFormComponent } from './mutual-funds-form.component';

describe('MutualFundsFormComponent', () => {
  let component: MutualFundsFormComponent;
  let fixture: ComponentFixture<MutualFundsFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MutualFundsFormComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MutualFundsFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
