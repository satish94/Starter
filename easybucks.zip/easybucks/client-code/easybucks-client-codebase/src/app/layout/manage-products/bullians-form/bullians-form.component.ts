import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { BulliansService } from './bullians.service';
// import { BankingListComponent } from './../banking/banking-list/banking-list.component';
import { debounceTime } from 'rxjs/operator/debounceTime';
import { Subject } from 'rxjs/Subject';


@Component({
  selector: 'app-bullians-form',
  templateUrl: './bullians-form.component.html',
  styleUrls: ['./bullians-form.component.scss']
})
export class BulliansFormComponent implements OnInit {

  bulliansForm: FormGroup;
  private _success = new Subject<string>();
  staticAlertClosed = false;
  successMessage: string;

  constructor(fb: FormBuilder, private bulliansService: BulliansService) {
    this.bulliansForm = fb.group({
      name: ['', [Validators.required, Validators.pattern('[a-zA-Z0-9& ]+')]],
      price: ['', [Validators.required, Validators.min(0)]]
    });
  }

  ngOnChanges() {
    this.bulliansForm.reset();
  }

  ngOnInit() {
    setTimeout(() => this.staticAlertClosed = true, 10000);
    this._success.subscribe((message) => this.successMessage = message);
    debounceTime.call(this._success, 5000).subscribe(() => this.successMessage = null);
  }

  get name() {
    return this.bulliansForm.get('name');
  }

  get price() {
    return this.bulliansForm.get('price');
  }

  getNameErrorMessage() {
    return this.name.hasError('required') ? 'You must enter a value' :
      this.name.hasError('pattern') ? 'Use only Alphabets and spaces' :
        '';
  }

  getPriceErrorMessage() {
    return this.price.hasError('required') ? 'You must enter a value' :
      this.price.hasError('min') ? 'Price can not be less than 0' :
        '';
  }

  onSubmit() {
    this.bulliansService.addBullians(this.bulliansForm.value)
      .subscribe(response => {
      }) ;
    this._success.next('Product Added Successfully') ;
    this.ngOnChanges();
  }
}
