import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MutualFundsListComponent } from './mutual-funds-list.component';

describe('MutualFundsListComponent', () => {
  let component: MutualFundsListComponent;
  let fixture: ComponentFixture<MutualFundsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MutualFundsListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MutualFundsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
