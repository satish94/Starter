import { Component, OnInit } from '@angular/core';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
@Component({
  selector: 'app-bullians',
  templateUrl: './bullians.component.html',
  styleUrls: ['./bullians.component.scss']
})
export class BulliansComponent implements OnInit {

  closeResult: string;

  constructor(private modalService: NgbModal) { }

  open(content) {
    this.modalService.open(content).result.then((result) => {
      this.closeResult = `Closed with: ${result}`;
    });
  }


  ngOnInit() {
  }

}
