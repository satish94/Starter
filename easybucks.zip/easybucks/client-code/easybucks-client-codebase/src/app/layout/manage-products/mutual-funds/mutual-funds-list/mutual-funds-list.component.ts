import { Component, OnInit } from '@angular/core';
import { MutualFundsService } from '../../mutual-funds-form/mutual-funds.service';
import { Sort, MatTableDataSource, MatSnackBar } from '@angular/material';
import { User } from "../../../../user/user";
@Component({
  selector: 'app-mutual-funds-list',
  templateUrl: './mutual-funds-list.component.html',
  styleUrls: ['./mutual-funds-list.component.scss']
})
export class MutualFundsListComponent implements OnInit {

  private mfunds: any;
  private sortedData ;
  private dataSource ;
  loggedInUser: User = new User();
  userDetail: any;
  constructor(private mutualFundsService: MutualFundsService, private snackBar: MatSnackBar) {
    this.getAll() ;
    this.userDetail = sessionStorage.getItem("userDetail");
        this.loggedInUser = JSON.parse(this.userDetail);
  }

 getAll() {
    this.mutualFundsService.getAllMutualFunds()
      .subscribe(
      response => {
        this.getAllFunds(response.json());
      },
      error => {
        console.log('error in loading products');
      }
      );
  }
  getAllFunds(result: any): void {
    this.mfunds = result.reverse();
  }
     openSnackBar(message: string, action: string) {
    this.snackBar.open(message, action, {
      duration: 2000,
    });
      }

  ngOnInit() {
  }
sortData(sort: Sort) {
    const data = this.mfunds ;
    if (!sort.active || sort.direction === '') {
      this.sortedData = data;
      return;
    }
    this.sortedData = data.sort((a, b) => {
      const isAsc = sort.direction === 'asc';
      switch (sort.active) {
        case 'code': return this.compare(a.code, b.code, isAsc);
        case 'scheme': return this.compare(+a.scheme, +b.scheme, isAsc);
        case 'netAssetValue': return this.compare(+a.netAssetValue, +b.netAssetValue, isAsc);
        case 'repurchasePrice': return this.compare(+a.repurchasePrice, +b.repurchasePrice, isAsc);
        case 'salePrice': return this.compare(+a.salePrice, +b.salePrice, isAsc);
        default: return 0;
      }
    });
  }
  compare(a, b, isAsc): number {
  return (a < b ? -1 : 1) * (isAsc ? 1 : -1);
}

deleteMf(mutualFunds: any){
  this.mutualFundsService.deleteMf(mutualFunds).subscribe(response=>{
  this.mfunds.splice(this.mfunds.indexOf(mutualFunds),1) ;
}) ;
this.openSnackBar('Product Deleted Successfully','') ;
}
}
