import { MutualFundsService } from './mutual-funds-form/mutual-funds.service';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ManageProductsRoutingModule } from './manage-products-routing.module';
import { ManageProductsComponent } from './manage-products.component';
import { PageHeaderModule } from './../../shared';
import { NavigationComponent } from './navigation/navigation.component';
import { MutualFundsComponent } from './mutual-funds/mutual-funds.component';
import { StocksComponent } from './stocks/stocks.component';
import { BulliansComponent } from './bullians/bullians.component';
import { BankingComponent } from './banking/banking.component';
import { MutualFundsFormComponent } from './mutual-funds-form/mutual-funds-form.component';
import { BankingFormComponent } from './banking-form/banking-form.component';
import { StocksFormComponent } from './stocks-form/stocks-form.component';
import { BulliansFormComponent } from './bullians-form/bullians-form.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BulliansService } from './bullians-form/bullians.service' ;
import { StocksService } from './stocks-form/stocks.service' ;
import {
    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatStepperModule,
} from '@angular/material';
import { BankingService } from './banking-form/banking.service';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { BankingListComponent } from './banking/banking-list/banking-list.component';
import { MutualFundsListComponent } from './mutual-funds/mutual-funds-list/mutual-funds-list.component';
import { BulliansListComponent } from './bullians/bullians-list/bullians-list.component';
import { StocksListComponent } from './stocks/stocks-list/stocks-list.component';
import { MutualfundWatchlistService } from "../watchlist/components/mutualfund-watchlist/mutualfund-watchlist.service";
import { BullionWatchlistService } from "../watchlist/components/bullion-watchlist/bullion-watchlist.service";
import { DepositWatchlistService } from "../watchlist/components/deposit-watchlist/deposit-watchlist.service";
import { StockWatchlistService } from "../watchlist/components/stock-watchlist/stock-watchlist.service";
@NgModule({
    imports: [CommonModule,
    ManageProductsRoutingModule,
    PageHeaderModule,
    NgbModule,
    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatExpansionModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
    MatStepperModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule
    ],
    declarations: [ManageProductsComponent,
        NavigationComponent,
        MutualFundsComponent,
        StocksComponent,
        BulliansComponent,
        BankingComponent,
        MutualFundsFormComponent,
        BankingFormComponent,
        StocksFormComponent,
        BulliansFormComponent,
        BankingListComponent,
        MutualFundsListComponent,
        BulliansListComponent,
        StocksListComponent],
    providers: [
        BankingService,
        BankingListComponent,
        MutualFundsService,
        BulliansService,
        StocksService,
        MutualfundWatchlistService,
        BullionWatchlistService,
        DepositWatchlistService,
        StockWatchlistService
        ],
})
export class ManageProductsModule { }
