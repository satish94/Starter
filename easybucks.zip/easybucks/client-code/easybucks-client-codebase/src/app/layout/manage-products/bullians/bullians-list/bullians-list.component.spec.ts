import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BulliansListComponent } from './bullians-list.component';

describe('BulliansListComponent', () => {
  let component: BulliansListComponent;
  let fixture: ComponentFixture<BulliansListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BulliansListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BulliansListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
