import { ManageProductsModule } from './manage-products.module';

describe('ManageProductsModule', () => {
    let manageProductsModule: ManageProductsModule;

    beforeEach(() => {
        manageProductsModule = new ManageProductsModule();
    });

    it('should create an instance', () => {
        expect(ManageProductsModule).toBeTruthy();
    });
});
