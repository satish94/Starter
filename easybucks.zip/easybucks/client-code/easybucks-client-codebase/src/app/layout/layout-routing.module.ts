import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout.component';

const routes: Routes = [
    {
        path: '',
        component: LayoutComponent,
        children: [
            { path: '', redirectTo: 'dashboard' },
            { path: 'dashboard', loadChildren: './dashboard/dashboard.module#DashboardModule' },
            { path: 'profile', loadChildren: './profile/profile.module#ProfileModule' },
            { path: 'home', loadChildren: './portfolio/portfolio.module#PortfolioModule' },
            { path: 'watchlist', loadChildren: './watchlist/watchlist.module#WatchlistModule' },
            { path: 'write-review', loadChildren: './write-review/write-review.module#WriteReviewModule' },
            { path: 'assistance', loadChildren: './assistance/assistance.module#AssistanceModule' },
            { path: 'manag-users', loadChildren: './manage-users/manage-users.module#ManageUsersModule' },
            { path: 'products', loadChildren: './products/products.module#ProductsModule' },
            { path: 'manage-products', loadChildren: './manage-products/manage-products.module#ManageProductsModule' },
            { path: 'expensee', loadChildren: './expense/expense.module#ExpenseModule' },
        ]
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class LayoutRoutingModule { }
