import { NgModule, Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { MatToolbarModule} from '@angular/material';
import {MatCardModule} from '@angular/material/card';
import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';
import { LayoutModule } from "../layout/layout.module";
import { NgbCarouselModule, NgbAlertModule } from '@ng-bootstrap/ng-bootstrap';
import { WriteReviewService } from '../layout/write-review/write-review.service';
import { HttpClientModule } from "@angular/common/http";
import { HomeService } from "./home.service";
import { LogInService } from "../login/login.service";

@NgModule({
  imports: [
    CommonModule,
    MatToolbarModule,
    MatCardModule,
    HomeRoutingModule,
    LayoutModule,
    NgbCarouselModule.forRoot(),
    NgbModule.forRoot(),
    HttpClientModule,
    

  ],
  declarations: [HomeComponent],

  providers: [HomeService, WriteReviewService]



})
export class HomeModule { }
