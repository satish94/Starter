export interface Stocks {
    id:string;
    review:string;
    stars:string;

}