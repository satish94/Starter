import { WriteReviewService } from './../layout/write-review/write-review.service';
import { HomeService } from './home.service';
import { HttpClientModule } from '@angular/common/http';
import { HttpClient } from '@angular/common/http';

import { RouterTestingModule } from '@angular/router/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeComponent } from './home.component';
import { NgbCarouselModule, NgbModule } from "@ng-bootstrap/ng-bootstrap";

describe('ServerErrorComponent', () => {
  let component: HomeComponent;
  let fixture: ComponentFixture<HomeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HomeComponent ],
      imports:[
        RouterTestingModule,
        NgbCarouselModule.forRoot(),
        NgbModule.forRoot(),
        HttpClientModule,
      ],
      providers:[
        HomeService,
        WriteReviewService,
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
