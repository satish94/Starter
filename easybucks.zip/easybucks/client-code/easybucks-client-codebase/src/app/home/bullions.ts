    export class Bullions{
    id:string;
    review:string;
    stars:string;

}