import { Injectable } from '@angular/core';
import { Http, Response, RequestOptions, Headers } from '@angular/http';
import { post_header, EasyBucksConstants } from '../EasyBucks';
import { HttpClient } from '@angular/common/http';
import { Comments } from "./comment";
import { Observable } from "rxjs/Observable";
import { Bullions } from "./bullions";
import { Stocks } from "./stocks";
import { Banking } from "./banking";
@Injectable()
export class HomeService {

 private _options ;
  private _baseUrl = EasyBucksConstants.baseUrl ;
  constructor(private http: HttpClient) {
     this._options = new RequestOptions({ headers: post_header});
    
  }

  //getting news from public api as json
  getNews()
  {
      return this.http.get('https://hn.algolia.com/api/v1/search_by_date?query=stocks&tags=story');
  }

   getCommentsforMf():Observable<Comments[]>{
   return this.http.get<Comments[]>(this._baseUrl + "review/allMfComments");
  }

  getCommentsforStocks():Observable<Stocks[]>{
   return this.http.get<Stocks[]>(this._baseUrl + "review/allStocksComments");
  }

  getCommentsforBullion():Observable<Bullions[]>{
   return this.http.get<Bullions[]>(this._baseUrl + "review/allBullionComments");
  }

  getCommentsforBanking():Observable<Banking[]>{
  return this.http.get<Banking[]>(this._baseUrl + "review/allBankingComments");
  }

}
