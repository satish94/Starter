import { Component, OnInit } from '@angular/core';
import { $ } from "protractor/built";
import 'rxjs/add/operator/map';
import { HttpClient } from "@angular/common/http";
import { HomeService } from "./home.service";
import { WriteReviewComponent } from '../layout/write-review/write-review.component';
import { Comments } from "./comment";
import { Bullions } from "./bullions";
import { Observable } from "rxjs/Observable";
import { Stocks } from "./stocks";
import { Banking } from "./banking";



import { WriteReviewService } from '../layout/write-review/write-review.service';
import { User } from "../user/user";

@Component({
    selector: 'app-home',
    templateUrl: './home.component.html',
    styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {

    //Sliders for Carousals
    news = {};
    public sliders: Array<any> = [];
    loggedInUser: User = new User();
 
    writeReviewComponent:WriteReviewComponent;  

     
    
    
    
     comments:any[]=[];
     reviewMf1:string="";
     starsMf1 :number;

     reviewMf2:string="";
     starsMf2:number;

     reviewMf3:string="";
     starsMf3:number;
         

    reviewBullion1:string="";
     starsBullion1:number;

     reviewBullion2:string="";
     starsBullion2:number;

     reviewBullion3:string="";
     starsBullion3:number;

     reviewBank1:string="";
     starsBank1:number;

     reviewBank2:string="";
     starsBank2:number;

    reviewBank3:string="";
     starsBank3:number;

     
     reviewStocks1:string="";
     starsStocks1:number;

     reviewStocks2:string="";
     starsStocks2:number;

     reviewStocks3:string="";
     starsStocks3:number;

    currentRate=8;
    constructor(
        private http: HttpClient,
        private homeService : HomeService,
        ) {
        this.sliders.push(

            {
                imagePath: 'assets/images/mf1.png',

            },
            {
                imagePath: 'assets/images/bl.jpg',

            },
            {
                imagePath: 'assets/images/sm1.jpg',

            },
            {
                imagePath: 'assets/images/ba.jpg',

            }
        );

        this.homeService.getNews().subscribe((data:any)=>{
            this.news=data;

        let userDetail = sessionStorage.getItem("userDetail");
        this.loggedInUser = JSON.parse(userDetail);
   })

    this.homeService.getCommentsforMf().subscribe((data:Comments[]) => { this.reviewMf1=data[0].review; this.starsMf1=+data[0].stars;//console.log(this.reviewMf1);
 } );

   this.homeService.getCommentsforMf().subscribe((data:Comments[]) => { this.reviewMf2=data[1].review; this.starsMf2=+data[1].stars;//console.log(this.reviewMf2);
 } );

  this.homeService.getCommentsforMf().subscribe((data:Comments[]) => { this.reviewMf3=data[2].review; this.starsMf3=+data[2].stars;//console.log(this.reviewMf3);
 } );


  this.homeService.getCommentsforStocks().subscribe((data:Stocks[]) => { this.reviewStocks1 = data[0].review; this.starsStocks1=+data[0].stars; console.log(this.starsStocks1)
 } );
  this.homeService.getCommentsforStocks().subscribe((data:Stocks[]) => { this.reviewStocks2 = data[1].review; this.starsStocks2=+data[1].stars; 
 } );
   this.homeService.getCommentsforStocks().subscribe((data:Stocks[]) => { this.reviewStocks3 = data[2].review; this.starsStocks3=+data[2].stars; 
 } );


  this.homeService.getCommentsforBullion().subscribe((data:Bullions[]) => { this.reviewBullion1=data[0].review; this.starsBullion1=+data[0].stars; 
 } );

 this.homeService.getCommentsforBullion().subscribe((data:Bullions[]) => { this.reviewBullion2=data[1].review; this.starsBullion2=+data[1].stars; 
 } );

this.homeService.getCommentsforBullion().subscribe((data:Bullions[]) => { this.reviewBullion3=data[2].review; this.starsBullion3=+data[2].stars;
 } );

 
  this.homeService.getCommentsforBanking().subscribe((data:Banking[]) => { this.reviewBank1 = data[0].review; this.starsBank1=+data[0].stars; 
 } );
  this.homeService.getCommentsforBanking().subscribe((data:Banking[]) => { this.reviewBank2 = data[1].review; this.starsBank2=+data[1].stars; 
 } );
  this.homeService.getCommentsforBanking().subscribe((data:Banking[]) => { this.reviewBank3 = data[2].review; this.starsBank3=+data[2].stars; 
 } );



   
}
        
  
ngOnInit() {}

 //This function is for Scroll Spy
onClick(divId){
    let division = document.querySelector("#"+divId);
    if (division){
        division.scrollIntoView({ behavior: 'smooth' });
        this.http.get('https://hn.algolia.com/api/v1/search_by_date?query=stocks&tags=story').subscribe((data: any) => {
            this.news = data;


        })
         

    }
}
  }
