export interface Comments {
    id:string;
    review:string;
    stars:string;

}