
export interface Banking {
    id:string;
    review:string;
    stars:string;

}