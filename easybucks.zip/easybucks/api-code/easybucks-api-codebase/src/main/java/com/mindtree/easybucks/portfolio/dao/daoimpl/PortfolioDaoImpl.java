package com.mindtree.easybucks.portfolio.dao.daoimpl;


import java.util.List;

import javax.persistence.NoResultException;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucks.portfolio.dao.PortfolioDao;
import com.mindtree.easybucks.portfolio.entity.Portfolio;
import com.mindtree.easybucks.portfolio.exception.daoexception.PortfolioDaoException;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.signup.service.EasyService.UserService;

@Repository
@Transactional("transactionManager")
public class PortfolioDaoImpl implements PortfolioDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	private UserService userServ;
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public Session getSession(){
		return sessionFactory.getCurrentSession();
	}

	public boolean addToPortfolio(Portfolio portfolio) throws PortfolioDaoException {
		try{
			getSession().save(portfolio);
			return true;
		}
		catch(HibernateException e){
			throw new PortfolioDaoException("Error In saving user details in Dao  " , e.getCause());
		}
	}

	public boolean deletePortfolio(Portfolio portfolio) throws PortfolioDaoException {
		try{
			getSession().delete(portfolio);
			return true;
		}
		catch(HibernateException e){
			throw new PortfolioDaoException("Error In deleting user details in Dao  " , e.getCause());
		}
	}

	@SuppressWarnings("unchecked")
	public List<Portfolio> getAllPortfolio() throws PortfolioDaoException {
		try{
			
			return getSession().createQuery("FROM Portfolio").list();
		}
		catch(HibernateException e){
			throw new PortfolioDaoException("Error In geting user details in Dao  " , e.getCause());
		}
	}

	public Portfolio getPortfolioByUserId(int userId) throws PortfolioDaoException {
		try{
			String select = "FROM Portfolio WHERE user = :para";
			
			User user = userServ.getUserById(userId);	
			
			Query query = getSession().createQuery(select);
			query.setParameter("para", user);
			@SuppressWarnings("unchecked")
			List<Portfolio> userList = query.list();
			return userList.get(0);
		}
		catch(HibernateException e){
			throw new PortfolioDaoException("Error In getting user details by userId in Dao  " , e.getCause());
		}
		catch(NoResultException resultException){
			throw new PortfolioDaoException("Error in getting user details", resultException.getCause());
		}
		catch(IndexOutOfBoundsException outOfBoundException){
			throw new PortfolioDaoException("No Portfolio for the given user", outOfBoundException.getCause());
		}
	}

	public boolean updatePortfolio(Portfolio portfolio) throws PortfolioDaoException {
		try{
			getSession().update(portfolio);
			return true;
		}
		catch(HibernateException e){
			throw new PortfolioDaoException("Error In updating Portfolio", e.getCause());
		}
	}
	
	

}
