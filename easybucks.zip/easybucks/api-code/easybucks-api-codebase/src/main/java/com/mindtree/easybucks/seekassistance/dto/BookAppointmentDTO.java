package com.mindtree.easybucks.seekassistance.dto;

public class BookAppointmentDTO 
{
	private int investor;
	private int advisor;
	private String reason;
	private String appointmentDate;
	private String place;
	private String status;
	public BookAppointmentDTO() {
		super();
		
	}
	@Override
	public String toString() {
		return "BookAppointment [investor=" + investor + ", advisor=" + advisor + ", reason=" + reason
				+ ", appointmentDate=" + appointmentDate + ", place=" + place + ", status=" + status + "]";
	}
	public int getInvestor() {
		return investor;
	}
	public void setInvestor(int investor) {
		this.investor = investor;
	}
	public int getAdvisor() {
		return advisor;
	}
	public void setAdvisor(int advisor) {
		this.advisor = advisor;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public String getAppointmentDate() {
		return appointmentDate;
	}
	public void setAppointmentDate(String appointmentDate) {
		this.appointmentDate = appointmentDate;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
}
