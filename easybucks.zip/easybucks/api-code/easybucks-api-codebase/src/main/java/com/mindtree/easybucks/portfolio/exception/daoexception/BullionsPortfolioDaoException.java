package com.mindtree.easybucks.portfolio.exception.daoexception;

import com.mindtree.easybucks.portfolio.exception.PortfolioException;

public class BullionsPortfolioDaoException extends PortfolioException {

	private static final long serialVersionUID = 1L;

	public BullionsPortfolioDaoException() {
		super();
	}

	public BullionsPortfolioDaoException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		
	}
	
	

}
