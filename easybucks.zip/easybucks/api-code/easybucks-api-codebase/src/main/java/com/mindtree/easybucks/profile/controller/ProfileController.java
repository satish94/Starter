package com.mindtree.easybucks.profile.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.easybucks.profile.dto.ProfileDto;
import com.mindtree.easybucks.profile.services.ProfileService;
import com.mindtree.easybucks.signup.entity.User;

@RestController
@CrossOrigin(origins={"http://localhost:4200"}, maxAge = 4800, allowCredentials = "false")
@RequestMapping(value = "/profile")
public class ProfileController {

	@Autowired
	public ProfileService profileSerivce;

	@Qualifier(value = "profileService")
	public void SetProfileService(ProfileService profileSerivce) {
		this.profileSerivce = profileSerivce;
	}

	@RequestMapping(value = "/{userId}", method = RequestMethod.GET, produces="application/json")
	public User getProfile(@PathVariable("userId") int userId) {
	
		return this.profileSerivce.getProfile(userId);

	}

	@RequestMapping(value = "/update", method = RequestMethod.POST, consumes="application/json")
	public User updateProfile(@RequestBody ProfileDto profileDto) {

		return this.profileSerivce.updateProfile(profileDto);
	}
}
