package com.mindtree.easybucks.portfolio.exception.daoexception;

import com.mindtree.easybucks.portfolio.exception.PortfolioException;

public class PortfolioDaoException extends PortfolioException {

	private static final long serialVersionUID = 1L;

	public PortfolioDaoException() {
		super();
	}

	public PortfolioDaoException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}
	
	

}
