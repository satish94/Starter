package com.mindtree.easybucks.watchlist.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.easybucks.products.entities.Banking;
import com.mindtree.easybucks.products.exceptions.serviceexceptions.ProductsServiceException;
import com.mindtree.easybucks.products.service.BankingService;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.signup.service.EasyService.UserService;
import com.mindtree.easybucks.watchlist.exception.serviceexception.WatchlistServiceException;
import com.mindtree.easybucks.watchlist.services.bankingservice.BankingWatchlistService;

@CrossOrigin
@RestController
@RequestMapping(value="/watchlist/banking")
public class BankingWatchlistController {

	@Autowired
	private UserService userService;
	@Autowired
	private BankingWatchlistService bankingWatchlistService;
	@Autowired
	private BankingService bankingService; 
	
	@RequestMapping(value="/all/{id}", method = RequestMethod.GET)
	public List<Banking>  getAllBanking( @PathVariable("id") Integer id) {
		List<Banking> banks = new ArrayList<Banking>();
		try {
			 banks = this.bankingWatchlistService.getBankingWatchlistByUser(userService.getUserById(id));
			return banks;
		} catch (WatchlistServiceException e) {
			 banks = null;
			return banks;
		}
	}
	
	@RequestMapping(value="{userid}/{bid}", method = RequestMethod. GET)
	public String AddToBankingWatchlist( @PathVariable("userid") int userid, @PathVariable("bid") int bid) {
			 try {
				Banking bank = bankingService.getBanking(bid);
				 User user = userService.getUserById(userid);
				 this.bankingWatchlistService.addToBankingWatchlist(user, bank);
				 return "Product successfully added";
			} catch (ProductsServiceException e) {
				return(e.getMessage()+"\n"+e.getCause());
			} catch (WatchlistServiceException e) {
				return(e.getMessage()+"\n"+e.getCause());
			}		
	}
	
	@RequestMapping(value="delete/{userid}/{bid}", method = RequestMethod.DELETE)
	public String deleteFromWatchlist(@PathVariable("userid") int userid , @PathVariable("bid") int bid)
	{
		 try {
			 Banking bank=bankingService.getBanking(bid);
			 User user = userService.getUserById(userid);
			 this.bankingWatchlistService.deleteFromBankingWatchlist(user, bank);
			 return "product deleted successfully";
		} catch (WatchlistServiceException e) {
			return(e.getMessage()+"\n"+e.getCause());
		} catch (ProductsServiceException e) {
			return(e.getMessage()+"\n"+e.getCause());
		}
		
	}
}
