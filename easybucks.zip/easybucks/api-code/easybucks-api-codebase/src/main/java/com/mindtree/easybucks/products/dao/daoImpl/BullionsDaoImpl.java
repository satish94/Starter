package com.mindtree.easybucks.products.dao.daoImpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucks.products.dao.BullionsDao;
import com.mindtree.easybucks.products.entities.Bullions;
import com.mindtree.easybucks.products.exceptions.daoexceptions.ProductsDaoException;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.signup.service.EasyService.UserService;
import com.mindtree.easybucks.watchlist.exception.serviceexception.WatchlistServiceException;
import com.mindtree.easybucks.watchlist.services.bullionservice.BullionWatchlistService;

@Transactional("transactionManager")
@Repository
public class BullionsDaoImpl implements BullionsDao {

	private static final Logger logger = LoggerFactory.getLogger(BullionsDaoImpl.class);

	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	UserService userService;
	
	@Autowired
	BullionWatchlistService watchlist ;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	public Session getSession() throws ProductsDaoException {
			return this.sessionFactory.getCurrentSession();
	}
	
	public void closeSession() {
		this.sessionFactory.close();
	}

	public String addBullions(Bullions bullions) throws ProductsDaoException {
		String message ;
		try {
			getSession().save(bullions);
			message =  "Bullions Added Successfully";
		} catch (ProductsDaoException e) {
			message = e.getMessage() + " caused by " + e.getCause() ;
		}
		return message ;
	}

	public List<Bullions> getAllBullions() throws ProductsDaoException {
		List<Bullions> bullions = new ArrayList<Bullions>();
		try {
			bullions = getSession().createQuery("from Bullions").list();
		} catch (ProductsDaoException e) {
			logger.info(e.getMessage() + " caused by " + e.getCause());
			bullions = null;
		}
		return bullions;
	}
	
	public Bullions getBullions(int id) throws ProductsDaoException {

		Bullions bullions = new Bullions();
		try {
			bullions = getSession().get(Bullions.class, new Integer(id));
		} catch (ProductsDaoException e) {
			logger.info(e.getMessage() + " caused by " + e.getCause());
			bullions = null;
		}
		return bullions;
	}
	
	public String deleteBullions(int id) throws ProductsDaoException {

		Bullions bullions = new Bullions();
		List<User> users = new ArrayList<User>();
		users = userService.getUsers();
		bullions = getBullions(id) ;
		for (User user : users) {
			try {
				watchlist.deleteFromBullionWatchlist(user, bullions) ;
			} catch (WatchlistServiceException e) {
				throw new ProductsDaoException("Unable to delete from watchlist", e);
			}
		}
		try {
			getSession().delete(bullions);
			return ("Bullions Deleted Successfully");
		} catch (ProductsDaoException e) {
			return (e.getMessage() + " caused by " + e.getCause());
		}
	}
}
