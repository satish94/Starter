package com.mindtree.easybucks.products.service.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.easybucks.products.dao.BankingDao;
import com.mindtree.easybucks.products.entities.Banking;
import com.mindtree.easybucks.products.exceptions.daoexceptions.ProductsDaoException;
import com.mindtree.easybucks.products.exceptions.serviceexceptions.ProductsServiceException;
import com.mindtree.easybucks.products.service.BankingService;

@Service
public class BankingServiceImpl implements BankingService {
	
	@Autowired
	private BankingDao bankingDao ;
	
	public void setBankingDao(BankingDao bankingDao) {
		this.bankingDao = bankingDao;
	}
	
	public String addBanking(Banking banking) throws ProductsServiceException {
		try {
			return(this.bankingDao.addBanking(banking)) ;
		} catch (ProductsDaoException e) {
			throw new ProductsServiceException("Unable to add to banking",e) ;
		}
	}

	public List<Banking> getAllBanking() throws ProductsServiceException {
		try {
			return this.bankingDao.getAllBanking();
		} catch (ProductsDaoException e) {
			throw new ProductsServiceException("Unable to fetch list from banking",e) ;
		}
	}

	public Banking getBanking(int id) throws ProductsServiceException {
		try {
			return this.bankingDao.getBanking(id);
		} catch (ProductsDaoException e) {
			throw new ProductsServiceException("Unable to fetch from banking",e) ;
		}
	}
	
	public String deleteBanking(int id) throws ProductsServiceException {
		try {
			return this.bankingDao.deleteBanking(id);
		} catch (ProductsDaoException e) {
			throw new ProductsServiceException("Unable to delete from banking",e) ;
		}
	}
	
}
