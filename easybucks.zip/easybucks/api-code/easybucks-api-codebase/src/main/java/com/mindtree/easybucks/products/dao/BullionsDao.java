package com.mindtree.easybucks.products.dao;

import java.util.List;

import com.mindtree.easybucks.products.entities.Bullions;
import com.mindtree.easybucks.products.exceptions.daoexceptions.ProductsDaoException;

public interface BullionsDao {

	String addBullions(Bullions bullions) throws ProductsDaoException ;
	List<Bullions> getAllBullions() throws ProductsDaoException ;
	Bullions getBullions(int id) throws ProductsDaoException ;
	String deleteBullions(int id) throws ProductsDaoException ;
}
