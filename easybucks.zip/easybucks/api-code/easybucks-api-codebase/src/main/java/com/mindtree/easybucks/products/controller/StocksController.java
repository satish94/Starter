package com.mindtree.easybucks.products.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.easybucks.products.entities.Stocks;
import com.mindtree.easybucks.products.exceptions.serviceexceptions.ProductsServiceException;
import com.mindtree.easybucks.products.service.StocksService;

@CrossOrigin
@RestController
@RequestMapping(value="/products/stocks")
public class StocksController {
	
	@Autowired
	private StocksService stocksService ;

	public void setStocksService(StocksService stocksService) {
		this.stocksService = stocksService;
	}
	
	@RequestMapping(value="/add", method = RequestMethod.POST)
	public String addStocks(@RequestBody Stocks stocks)
	{
		try {
			return this.stocksService.addStocks(stocks);
		} catch (ProductsServiceException e1) {
			return (e1.getMessage()+"\n"+e1.getCause());
		}
	}

	@RequestMapping(value="/all", method = RequestMethod.GET)
	public List<Stocks> getAllStocks(){
		List<Stocks> stocksList=new ArrayList();
		try {
			stocksList=this.stocksService.getAllStocks();
		} catch (ProductsServiceException e) {
			stocksList= null ;
		}
		return stocksList;
	}

	@RequestMapping(value="/delete/{Id}", method = RequestMethod.DELETE)
	public String deleteStocks(@PathVariable("Id")int id)
	{
		try {
			return this.stocksService.deleteStocks(id) ;
		} catch (ProductsServiceException e1) {
			return(e1.getMessage()+"\n"+e1.getCause());
		}
	}
	
	@RequestMapping(value="/{Id}", method = RequestMethod.GET)
	public Stocks getStocks(@PathVariable("Id")int id){
		Stocks stocks = new Stocks() ;
		try {
			stocks = this.stocksService.getStocks(id) ;
		} catch (ProductsServiceException e) {
			stocks = null ;
		}
		return stocks ;
	}
}
