package com.mindtree.easybucks.signup.service;

 
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.easybucks.signup.dao.UserDao;
import com.mindtree.easybucks.signup.dto.AdvisorRequestsDto;
import com.mindtree.easybucks.signup.dto.AdvisorRequestsUpdateDto;
import com.mindtree.easybucks.signup.dto.SignUpDto;
import com.mindtree.easybucks.signup.entity.AdvisorRequests;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.signup.entity.UserRole;
import com.mindtree.easybucks.signup.service.EasyService.UserService;
 
@Service
public class UserServiceImp implements UserService {
 
	@Autowired
	private UserDao userDao;
	
	public String adduser(SignUpDto signUpDto) {
			User user=new User();
			UserRole userRole=new UserRole();
			user.setUserName(signUpDto.getUserName());
			user.setUserEmail(signUpDto.getUserEmail().toLowerCase());
			user.setUserPassword(signUpDto.getUserPassword());
			String role=signUpDto.getUserRole();
			int roleId=0;
			if(role.equals("admin"))
				roleId=1;
			if(role.equals("advisor"))
				roleId=3;
			if(role.equals("investor"))
				roleId=3;
			userRole.setRoleId(roleId);
			user.setUserRole(userRole);
			user.setUserIncome(0);
			user.setUserPhone(0);
			userDao.adduser(user);
			return "Successfully registered";	
	}

	public List<User> getUsers() {
			return userDao.getUser();
	}
	public User getUserById(int userId){
		return userDao.getUserById(userId);
	}

	public List<String> getEmail() {
		
		return userDao.getEmail();
	}
	public boolean deleteUser(int userId)
	{
		return userDao.deleteUser(userId);
	}
	
	public boolean addAdvisorRequest(AdvisorRequestsDto advisorRequestsDto)
	{
		AdvisorRequests advisorRequests=new AdvisorRequests();
		advisorRequests.setEmail(advisorRequestsDto.getEmail());;
		advisorRequests.setStatus(advisorRequestsDto.getStatus());
		return userDao.addAdvisorRequest(advisorRequests);
	}
	
	public AdvisorRequests updateAdvisorRequest(AdvisorRequestsUpdateDto advisorRequestsUpdateDto)
	{
		AdvisorRequests advisorRequests=new AdvisorRequests();
		advisorRequests.setAdvisorRequestId(advisorRequestsUpdateDto.getAdvisorRequestId());
		advisorRequests.setEmail(advisorRequestsUpdateDto.getEmail());;
		advisorRequests.setStatus(advisorRequestsUpdateDto.getStatus());
		return userDao.updateAdvisorRequest(advisorRequests);
	}
	
	public boolean deleteAdvisorRequest(int advisorRequestId)
	{
		return userDao.deleteAdvisorRequest(advisorRequestId);
	}
	
	public List<AdvisorRequests>  getALLAdvisorRequests()
	{
		return userDao.getALLAdvisorRequests();
	}
}
