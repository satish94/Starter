package com.mindtree.easybucks.portfolio.exception.daoexception;

import com.mindtree.easybucks.portfolio.exception.PortfolioException;

public class MFPortfolioDaoException extends PortfolioException {

	private static final long serialVersionUID = 1L;

	public MFPortfolioDaoException() {
		super();
	}

	public MFPortfolioDaoException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}
	
	

}
