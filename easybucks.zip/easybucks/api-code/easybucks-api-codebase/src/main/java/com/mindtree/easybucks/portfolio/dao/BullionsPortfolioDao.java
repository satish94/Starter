package com.mindtree.easybucks.portfolio.dao;

import com.mindtree.easybucks.portfolio.entity.BullionsPortfolio;
import com.mindtree.easybucks.portfolio.exception.daoexception.BullionsPortfolioDaoException;

public interface BullionsPortfolioDao {
	
	public BullionsPortfolio getBullionsPortfolioById(int bulliondPortId) throws BullionsPortfolioDaoException;
	
	public boolean deleteBullionsPortfolioById(int bullionsPortId ) throws BullionsPortfolioDaoException;

}
