package com.mindtree.easybucks.products.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.easybucks.products.entities.MutualFunds;
import com.mindtree.easybucks.products.exceptions.serviceexceptions.ProductsServiceException;
import com.mindtree.easybucks.products.service.MutualFundsService;

@CrossOrigin
@RestController
@RequestMapping(value="/products/mutualfunds")
public class MutualFundsController {
	
	@Autowired
	private MutualFundsService mutualFundsService ;
	
	public void setMutualFundsService(MutualFundsService mutualFundsService) {
		this.mutualFundsService = mutualFundsService;
	}
	@RequestMapping(value="/add", method = RequestMethod.POST)
	public String addMutualFunds(@RequestBody MutualFunds mutualFunds)
	{
		try {
			return this.mutualFundsService.addMutualFunds(mutualFunds);
		} catch ( ProductsServiceException e1) {
			return (e1.getMessage()+"\n"+e1.getCause());
		}
	}
	
	@RequestMapping(value="/all", method = RequestMethod.GET)
	public List<MutualFunds> getAllMutualFunds(){
		List<MutualFunds> mutualFundsList=new ArrayList();
		try {
			mutualFundsList=this.mutualFundsService.getAllFunds();
		} catch (ProductsServiceException e) {
			mutualFundsList= null ;
		}
		return mutualFundsList;
	}
	
	@RequestMapping(value="/delete/{Id}", method = RequestMethod.DELETE)
	public String deleteMutualFunds(@PathVariable("Id")int id)
	{
		try {
			return this.mutualFundsService.deleteMutualFunds(id) ;
		} catch (ProductsServiceException e1) {
			return(e1.getMessage()+"\n"+e1.getCause());
		}
	}
	
	@RequestMapping(value="/{Id}", method = RequestMethod.GET)
	public MutualFunds getMutualFunds(@PathVariable("Id")int id){
		MutualFunds mutualFunds = new MutualFunds() ;
		try {
			mutualFunds = this.mutualFundsService.getMutualFunds(id) ;
		} catch (ProductsServiceException e) {
			mutualFunds = null ;
		}
		return mutualFunds ;
	}
}
