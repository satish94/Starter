package com.mindtree.easybucks.products.dao.daoImpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucks.products.dao.BankingDao;
import com.mindtree.easybucks.products.entities.Banking;
import com.mindtree.easybucks.products.exceptions.daoexceptions.ProductsDaoException;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.signup.service.EasyService.UserService;
import com.mindtree.easybucks.watchlist.exception.serviceexception.WatchlistServiceException;
import com.mindtree.easybucks.watchlist.services.bankingservice.BankingWatchlistService;

@Repository
@Transactional("transactionManager")
public class BankingDaoImpl implements BankingDao {

	private static final Logger logger = LoggerFactory.getLogger(BankingDaoImpl.class);

	@Autowired
	private SessionFactory sessionFactory;

	@Autowired
	UserService userService;

	@Autowired
	BankingWatchlistService watchlist;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	public Session getSession() throws ProductsDaoException {
		return this.sessionFactory.getCurrentSession();
	}

	public String addBanking(Banking banking) throws ProductsDaoException {
		String message;
		try {
			getSession().save(banking);
			message = "Banking Added Successfully";
		} catch (ProductsDaoException e) {
			message = e.getMessage() + " caused by " + e.getCause();
		}
		return message;
	}

	public List<Banking> getAllBanking() throws ProductsDaoException {

		List<Banking> bankings = new ArrayList<Banking>();
		try {
			bankings = getSession().createQuery("from Banking").list();
		} catch (ProductsDaoException e) {
			logger.info(e.getMessage() + " caused by " + e.getCause());
			bankings = null;
		}
		return bankings;
	}

	public Banking getBanking(int id) throws ProductsDaoException {

		Banking banking = new Banking();
		try {
			banking = getSession().get(Banking.class, new Integer(id));
		} catch (ProductsDaoException e) {
			logger.info(e.getMessage() + " caused by " + e.getCause());
			banking = null;
		}
		return banking;
	}

	public String deleteBanking(int id) throws ProductsDaoException {

		Banking banking = new Banking();
		List<User> users = new ArrayList<User>();
		users = userService.getUsers();
		banking = getBanking(id);
		for (User user : users) {
			try {
				watchlist.deleteFromBankingWatchlist(user, banking);
			} catch (WatchlistServiceException e) {
				throw new ProductsDaoException("Unable to delete from watchlist", e);
			}
		}
		try {
			System.out.println("Delete");
			getSession().delete(banking);
			return ("Banking Deleted Successfully");
		} catch (ProductsDaoException e) {
			return (e.getMessage() + " caused by " + e.getCause());
		}
	}
}
