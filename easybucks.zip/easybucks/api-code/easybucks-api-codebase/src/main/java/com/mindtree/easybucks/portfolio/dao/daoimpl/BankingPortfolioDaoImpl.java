package com.mindtree.easybucks.portfolio.dao.daoimpl;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucks.portfolio.dao.BankingPortfolioDao;
import com.mindtree.easybucks.portfolio.entity.BankingPortfolio;
import com.mindtree.easybucks.portfolio.exception.daoexception.BankingPortfolioDaoException;

@Repository
@Transactional("transactionManager")
public class BankingPortfolioDaoImpl implements BankingPortfolioDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public Session getSession(){
		return sessionFactory.getCurrentSession();
	}

	public BankingPortfolio getBankingPortfolioById(int bankingPortId) throws BankingPortfolioDaoException {
		try{
			return getSession().get(BankingPortfolio.class, new Integer(bankingPortId));
		}
		catch(HibernateException e){
			throw new BankingPortfolioDaoException("Error in getting Banking Portfolio in Banking Dao", e.getCause());
		}
	}

	public boolean deletePortfolioById(int bankingPortId) throws BankingPortfolioDaoException {
		try{
			BankingPortfolio bankingPort = getBankingPortfolioById(bankingPortId);
			getSession().delete(bankingPort);
			return true;
		}
		catch(HibernateException e){
			throw new BankingPortfolioDaoException("Error in deleting Banking Portfolio in Banking Dao", e.getCause());
		}
	}

}






