package com.mindtree.easybucks.products.exceptions;

public class ProductsExceptions extends Exception{

	private static final long serialVersionUID = 1L;

	public ProductsExceptions() {
		super();
	}

	public ProductsExceptions(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}
	

}
