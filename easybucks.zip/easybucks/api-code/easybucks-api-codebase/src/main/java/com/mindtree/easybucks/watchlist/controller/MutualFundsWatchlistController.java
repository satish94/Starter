package com.mindtree.easybucks.watchlist.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.easybucks.products.entities.MutualFunds;
import com.mindtree.easybucks.products.exceptions.serviceexceptions.ProductsServiceException;
import com.mindtree.easybucks.products.service.MutualFundsService;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.signup.service.EasyService.UserService;
import com.mindtree.easybucks.watchlist.exception.serviceexception.WatchlistServiceException;
import com.mindtree.easybucks.watchlist.services.mutualfundservice.MutualFundWatchlistService;

@CrossOrigin
@RestController
@RequestMapping(value="/watchlist/mutualfunds")
public class MutualFundsWatchlistController {
	@Autowired
	private UserService userService;

	@Autowired
	private MutualFundWatchlistService mutualFundWatchlistService;
	@Autowired
	private MutualFundsService mutualFundsService;
	
	
	@RequestMapping(value="/all/{id}", method = RequestMethod.GET)
	public List<MutualFunds>  getAllMutualFunds( @PathVariable("id") Integer id) {
		List<MutualFunds> mutualFunds = new ArrayList<MutualFunds>();
		try {
			mutualFunds = this.mutualFundWatchlistService.getMutualFundWatchlistByUser(userService.getUserById(id));
			return mutualFunds;
		} catch (WatchlistServiceException e) {
			mutualFunds=null;
			return mutualFunds;
		}
	}
	
	@RequestMapping(value="{userid}/{mfid}", method = RequestMethod.GET)
	public String AddToMutualFundsWatchlist( @PathVariable("userid") int userid, @PathVariable("mfid") int mfid) {
			 try {
				MutualFunds mutualFund=mutualFundsService.getMutualFunds(mfid);
				 User user = userService.getUserById(userid);
				 this.mutualFundWatchlistService.addToMutualFundWatchlist(user, mutualFund);
				 return "product added successfully";
			} catch (ProductsServiceException e) {
				return(e.getMessage()+"\n"+e.getCause());
			} catch (WatchlistServiceException e) {
				return(e.getMessage()+"\n"+e.getCause());
			}
		
	}
	@RequestMapping(value="delete/{userid}/{mfid}", method = RequestMethod.DELETE)
	public String deleteFromWatchlist(@PathVariable("userid") int userid , @PathVariable("mfid") int mfid)
	{
		 try {
			MutualFunds mutualFund=mutualFundsService.getMutualFunds(mfid);
			 User user = userService.getUserById(userid);
			 this.mutualFundWatchlistService.deleteFromMutualFundWatchlist(user, mutualFund);
			return "product deleted successfully";
		} catch (ProductsServiceException e) {
			return(e.getMessage()+"\n"+e.getCause());
		} catch (WatchlistServiceException e) {
			return(e.getMessage()+"\n"+e.getCause());
		}
		
	}
	
}
