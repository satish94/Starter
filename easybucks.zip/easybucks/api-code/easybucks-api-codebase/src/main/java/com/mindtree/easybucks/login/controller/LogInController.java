package com.mindtree.easybucks.login.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.easybucks.login.dto.LogIn;
import com.mindtree.easybucks.login.dto.LogInResponse;
import com.mindtree.easybucks.login.dto.NewPassword;
import com.mindtree.easybucks.login.exceptions.LoginException;
import com.mindtree.easybucks.login.services.LogInService;
import com.mindtree.easybucks.signup.entity.User;

@CrossOrigin
@RestController
@RequestMapping(value = "/login")
public class LogInController {
	
	@Autowired
	private LogInService logInService;
	
	@Autowired
	private JavaMailSender mailSender;
	
	
	@RequestMapping(value = "/authentication", method = RequestMethod.POST)
	public LogInResponse login(@RequestBody LogIn logIn){
		
		User user = new User();
		user.setUserEmail(logIn.getEmail());
		user.setUserPassword(logIn.getPassword());
		return logInService.authentication(user);
	}
	
	@RequestMapping(value = "/sendemail", method = RequestMethod.POST)
	public int sendMail(@RequestBody String mail){
		
		 //creates a simple e-mail object
        SimpleMailMessage email = new SimpleMailMessage();
        email.setTo(mail);
        email.setSubject("OTP forget password");
        
        int random =  (int)(Math.random()*10000000+1);
        String msg = "Your OTP for forget password is : "+ random +"\n Do not share it with anyone";
        email.setText(msg);
        
        //sends the e-mail
        mailSender.send(email);
         
        //forwards to the view named "Result"
        return random;
	}
	
	@RequestMapping(value = "/changepassword", method = RequestMethod.POST)
	public int resetPassword(@RequestBody NewPassword newPassword ){
				
		int result;
		try{
			result = logInService.changePassword(newPassword);
		}
		catch(LoginException logException){
			result = 0;
		}
		
		return result;
		
	}
	
}












