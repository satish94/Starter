package com.mindtree.easybucks.seekassistance.services.servicesImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.mindtree.easybucks.seekassistance.dao.SeekAssistanceDAO;
import com.mindtree.easybucks.seekassistance.dto.BookAppointmentDTO;
import com.mindtree.easybucks.seekassistance.dto.BookAppointmentUpdateDTO;
import com.mindtree.easybucks.seekassistance.dto.SeekAssistanceDTO;
import com.mindtree.easybucks.seekassistance.dto.SeekAssistanceUpdateDTO;
import com.mindtree.easybucks.seekassistance.entities.BookAppointment;
import com.mindtree.easybucks.seekassistance.entities.SeekAssistance;
import com.mindtree.easybucks.seekassistance.services.SeekAssistanceService;
import com.mindtree.easybucks.signup.entity.User;



@Service
public class SeekAssistanceServiceImpl implements  SeekAssistanceService
{
	@Autowired
	private SeekAssistanceDAO seekAssistanceDAO;
	
	public void setSeekAssistanceDAO(SeekAssistanceDAO seekAssistanceDAO) {
		this.seekAssistanceDAO = seekAssistanceDAO;
	}

	public List<SeekAssistance> getALLSeekAssistanceDetails() {
		
		return seekAssistanceDAO.getALLSeekAssistanceDetails();
	}
	
	public boolean addSeekAssistance(SeekAssistanceDTO seekAssistancedto) {
		
		SeekAssistance seekAssistance=new SeekAssistance();
		seekAssistance.setInvestorId(seekAssistancedto.getInvestor());
		seekAssistance.setAdvisorId(seekAssistancedto.getAdvisor());
		seekAssistance.setQuery(seekAssistancedto.getQuery());
		seekAssistance.setAnswer(seekAssistancedto.getAnswer());
		seekAssistance.setStatus(seekAssistancedto.getStatus());
		
		return this.seekAssistanceDAO.addSeekAssistance(seekAssistance);
	}
	
	public SeekAssistance updateSeekAssistanceDetail(SeekAssistanceUpdateDTO seekAssistanceUpdatedto) {
		
		SeekAssistance seekAssistance=new SeekAssistance();
		seekAssistance.setSeekAssistanceId(seekAssistanceUpdatedto.getSeekAssistanceId());
		seekAssistance.setInvestorId(seekAssistanceUpdatedto.getInvestor());
		seekAssistance.setAdvisorId(seekAssistanceUpdatedto.getAdvisor());
		seekAssistance.setQuery(seekAssistanceUpdatedto.getQuery());
		seekAssistance.setAnswer(seekAssistanceUpdatedto.getAnswer());
		seekAssistance.setStatus(seekAssistanceUpdatedto.getStatus());
		
		return seekAssistanceDAO.updateSeekAssistanceDetail(seekAssistance);
	}
	
	public boolean deleteSeekAssistance(int seekAssistanceId) {
		
		return this.seekAssistanceDAO.deleteSeekAssistance(seekAssistanceId);
	}
	
	public List<User> getALLUsersDetails() {
		
		return seekAssistanceDAO.getALLUsersDetails();
	}
	
	public boolean addBookAppointment(BookAppointmentDTO bookAppointmentdto)
	{
		BookAppointment bookAppointment=new BookAppointment();
		bookAppointment.setInvestorId(bookAppointmentdto.getInvestor());
		bookAppointment.setAdvisorId(bookAppointmentdto.getAdvisor());
		bookAppointment.setReason(bookAppointmentdto.getReason());
		bookAppointment.setAppointmentDate(bookAppointmentdto.getAppointmentDate());
		bookAppointment.setPlace(bookAppointmentdto.getPlace());
		bookAppointment.setStatus(bookAppointmentdto.getStatus());
		return seekAssistanceDAO.addBookAppointment(bookAppointment);
	}
	
	public BookAppointment updateBookAppointment(BookAppointmentUpdateDTO bookAppointmentUpdatedto)
	{
		BookAppointment bookAppointment=new BookAppointment();
		bookAppointment.setBookAppointmentId(bookAppointmentUpdatedto.getBookAppointmentId());
		bookAppointment.setInvestorId(bookAppointmentUpdatedto.getInvestor());
		bookAppointment.setAdvisorId(bookAppointmentUpdatedto.getAdvisor());
		bookAppointment.setReason(bookAppointmentUpdatedto.getReason());
		bookAppointment.setAppointmentDate(bookAppointmentUpdatedto.getAppointmentDate());
		bookAppointment.setPlace(bookAppointmentUpdatedto.getPlace());
		bookAppointment.setStatus(bookAppointmentUpdatedto.getStatus());
		return seekAssistanceDAO.updateBookAppointment(bookAppointment);
	}
	
	public List<BookAppointment> getALLAppointmentDetails()
	{
		return seekAssistanceDAO.getALLAppointmentDetails();
	}
	
	public boolean deleteBookAppointment(int bookAppointmentId)
	{
		return this.seekAssistanceDAO.deleteBookAppointment(bookAppointmentId);
	}
}
