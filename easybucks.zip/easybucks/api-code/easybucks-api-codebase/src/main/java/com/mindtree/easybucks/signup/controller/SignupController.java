package com.mindtree.easybucks.signup.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.easybucks.signup.dto.AdvisorRequestsDto;
import com.mindtree.easybucks.signup.dto.AdvisorRequestsUpdateDto;
import com.mindtree.easybucks.signup.dto.Response;
import com.mindtree.easybucks.signup.dto.SignUpDto;
import com.mindtree.easybucks.signup.entity.AdvisorRequests;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.signup.service.EasyService.UserService;
 

@RestController
@RequestMapping(value="/signup")
public class SignupController {
	
	@Autowired
	private UserService userService;
	
	@ResponseBody
	@RequestMapping(value = "/getusers", method = RequestMethod.GET)
	public List<User> listUser()  {
		List<User> listUser = userService.getUsers();
		return listUser; 
    }
	
	
	@RequestMapping(value = "/adduser", produces = "application/json", consumes = "application/json")
	@ResponseBody
	public Response insertUser(@RequestBody SignUpDto signUpDto) {
         Response response = new Response();
		if(!((userService.getEmail().toString().toLowerCase()).contains(signUpDto.getUserEmail().toLowerCase())))
			 response.setText(userService.adduser(signUpDto));
		else response.setText("Already exist !!!");
		return response;
	}
	
	@RequestMapping(value="/{userId}", method = RequestMethod.GET)
	public User getUser(@PathVariable("userId") int userId ) {
		return this.userService.getUserById(userId);
	}
	
	@RequestMapping(value="/deleteuser/{userId}", method = RequestMethod.DELETE)
	public boolean deleteUser(@PathVariable("userId") int userId)
	{
		return this.userService.deleteUser(userId);
	}
	
	@RequestMapping(value="/addAdvisorRequest", method = RequestMethod.POST, consumes="application/json")
	public boolean addAdvisorRequest(@RequestBody AdvisorRequestsDto advisorRequestsDto)
	{
		return this.userService.addAdvisorRequest(advisorRequestsDto);
	}
	
	@RequestMapping(value="/updateAdvisorRequest", method = RequestMethod.PUT, consumes="application/json")
	public AdvisorRequests updateAdvisorRequest(@RequestBody AdvisorRequestsUpdateDto advisorRequestsUpdateDto)
	{
		return this.userService.updateAdvisorRequest(advisorRequestsUpdateDto);
	}
	
	@RequestMapping(value="/deleteAdvisorRequest/{advisorRequestId}", method = RequestMethod.DELETE)
	public boolean deleteAdvisorRequest(@PathVariable("advisorRequestId") int advisorRequestId) {
		return this.userService.deleteAdvisorRequest(advisorRequestId);
	}
	
	@RequestMapping(value="/allAdvisorRequests", method = RequestMethod.GET, produces="application/json")
	public List<AdvisorRequests>  getAllAdvisorRequests() {
		return this.userService.getALLAdvisorRequests();
	}
}
