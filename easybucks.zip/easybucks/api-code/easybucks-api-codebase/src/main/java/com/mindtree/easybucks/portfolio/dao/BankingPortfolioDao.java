package com.mindtree.easybucks.portfolio.dao;

import com.mindtree.easybucks.portfolio.entity.BankingPortfolio;
import com.mindtree.easybucks.portfolio.exception.daoexception.BankingPortfolioDaoException;

public interface BankingPortfolioDao {
	
	public BankingPortfolio getBankingPortfolioById(int BankingPortId) throws BankingPortfolioDaoException;
	
	public boolean deletePortfolioById(int BankingPortId) throws BankingPortfolioDaoException;

}
