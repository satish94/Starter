package com.mindtree.easybucks.products.dao.daoImpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucks.products.dao.MutualFundsDao;
import com.mindtree.easybucks.products.entities.MutualFunds;
import com.mindtree.easybucks.products.exceptions.daoexceptions.ProductsDaoException;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.signup.service.EasyService.UserService;
import com.mindtree.easybucks.watchlist.exception.serviceexception.WatchlistServiceException;
import com.mindtree.easybucks.watchlist.services.mutualfundservice.MutualFundWatchlistService;

@Repository
@Transactional("transactionManager")
public class MutualFundsDaoImpl implements MutualFundsDao {

	private static final Logger logger = LoggerFactory.getLogger(MutualFundsDaoImpl.class);

	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	UserService userService;
	
	@Autowired
	MutualFundWatchlistService	 watchlist ;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	public Session getSession() throws ProductsDaoException {
			return this.sessionFactory.getCurrentSession();
	}
	
	public String addMutualFunds(MutualFunds mutualFunds) throws ProductsDaoException {
		String message ;
		try {
			getSession().save(mutualFunds);
			message = "MutualFunds Added Successfully" ;
		} catch (ProductsDaoException e) {
			message = e.getMessage() + " caused by " + e.getCause();
		}
		return message ;
	}

	public List<MutualFunds> getAllFunds() throws ProductsDaoException {
		List<MutualFunds> mutualFundsList = new ArrayList<MutualFunds>();

		try {
			mutualFundsList = getSession().createQuery("from MutualFunds").list();
			return mutualFundsList;
		} catch (ProductsDaoException e) {
			logger.info(e.getMessage() + " caused by " + e.getCause());
			mutualFundsList = null;
		}
		return mutualFundsList;
	}
	
	public MutualFunds getMutualFunds(int id) throws ProductsDaoException {
		MutualFunds mutualFunds = new MutualFunds();
		try {
			mutualFunds = getSession().get(MutualFunds.class, new Integer(id));
		} catch (ProductsDaoException e) {
			logger.info(e.getMessage() + " caused by " + e.getCause());
			mutualFunds = null;
		}
		return mutualFunds;
	}
	
	public String deleteMutualFunds(int id) throws ProductsDaoException {

		MutualFunds mutualFunds = new MutualFunds();
		List<User> users = new ArrayList<User>();
		users = userService.getUsers();
		mutualFunds = getMutualFunds(id) ;
		for (User user : users) {
			try {
				watchlist.deleteFromMutualFundWatchlist(user, mutualFunds) ;
			} catch (WatchlistServiceException e) {
				throw new ProductsDaoException("Unable to delete from watchlist", e);
			}
		}
		try {
			getSession().delete(mutualFunds);
			return "Mutual Funds Deleted Succesfully";
		} catch (ProductsDaoException e) {
			return (e.getMessage() + " caused by " + e.getCause());
		}
	}
}
