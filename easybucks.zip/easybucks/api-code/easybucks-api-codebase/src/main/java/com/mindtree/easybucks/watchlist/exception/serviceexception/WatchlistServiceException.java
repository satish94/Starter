package com.mindtree.easybucks.watchlist.exception.serviceexception;

import com.mindtree.easybucks.watchlist.exception.WatchlistException;

public class WatchlistServiceException extends WatchlistException {

	private static final long serialVersionUID = 1L;

	public WatchlistServiceException() {
		super();
	}

	public WatchlistServiceException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}
	

}
