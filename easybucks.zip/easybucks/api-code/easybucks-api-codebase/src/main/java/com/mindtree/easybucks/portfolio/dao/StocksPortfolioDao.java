package com.mindtree.easybucks.portfolio.dao;

import com.mindtree.easybucks.portfolio.entity.StocksPortfolio;
import com.mindtree.easybucks.portfolio.exception.daoexception.StocksPortfolioDaoException;

public interface StocksPortfolioDao {
	
	public StocksPortfolio getStocksPortfolioById(int stocksPortId) throws StocksPortfolioDaoException;
	
	public boolean deleteStocksPortfolioById(int stocksPortId) throws StocksPortfolioDaoException;

}
