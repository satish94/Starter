package com.mindtree.easybucks.portfolio.dao;

import com.mindtree.easybucks.portfolio.entity.MFPortfolio;
import com.mindtree.easybucks.portfolio.exception.daoexception.MFPortfolioDaoException;

public interface MFPortfolioDao {
	
	public MFPortfolio getMFPortfolioById(int MFPortId) throws MFPortfolioDaoException;
	
	public boolean deleteMFPortfolioById(int MFPortId) throws MFPortfolioDaoException;

}
