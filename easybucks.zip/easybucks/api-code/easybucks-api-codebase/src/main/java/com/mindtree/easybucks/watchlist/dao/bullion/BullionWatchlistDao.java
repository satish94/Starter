package com.mindtree.easybucks.watchlist.dao.bullion;

import java.util.List;
import java.util.Set;

import com.mindtree.easybucks.products.entities.Bullions;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.watchlist.exception.daoexception.WatchlistDaoException;

public interface BullionWatchlistDao {
	
	public boolean addToBullionWatchlist(User user,Bullions bullion) throws WatchlistDaoException;
	public boolean deleteFromBullionWatchlist(User user,Bullions bullion)throws WatchlistDaoException;
	public List<Bullions> getBullionWatchlistByUser(User user)throws WatchlistDaoException;
	public Set<Bullions> getBullionWatchlistByUser1(User user)throws WatchlistDaoException;
}
