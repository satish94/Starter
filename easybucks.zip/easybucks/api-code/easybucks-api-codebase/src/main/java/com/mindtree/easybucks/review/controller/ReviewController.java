package com.mindtree.easybucks.review.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.easybucks.review.dto.Users;
import com.mindtree.easybucks.review.entity.WriteReviewBanking;
import com.mindtree.easybucks.review.entity.WriteReviewBullion;
import com.mindtree.easybucks.review.entity.WriteReviewMf;
import com.mindtree.easybucks.review.entity.WriteReviewStocks;
import com.mindtree.easybucks.review.service.ReviewProductsService;

@CrossOrigin
@RestController
@RequestMapping(value="/review")
public class ReviewController {
	
	@Autowired
	private ReviewProductsService reviewProductsService;
	
	@Qualifier(value="/reviewProductsService")
	public void setReviewProductsService(ReviewProductsService reviewProductsService) {
		this.reviewProductsService = reviewProductsService;
	}
	
	@RequestMapping(value="/reviewProductsService", method = RequestMethod.POST)
	public void addComments(@RequestBody Users write) {
		if(write.getProduct().equals("Mutual Funds"))
		{
			
			reviewProductsService.addCommentsToWriteReviewMf(write);
		}
		if(write.getProduct().equals("Stocks"))
		{
			reviewProductsService.addCommentsToWriteReviewStocks(write);
		}
		if(write.getProduct().equals("Bullions"))
		{
			reviewProductsService.addCommentsToWriteReviewBullion(write);
		}
		if(write.getProduct().equals("Banking"))
		{
			reviewProductsService.addCommentsToWriteReviewBanking(write);
		}
		
	}
	
	@RequestMapping(value="/allMfComments", method = RequestMethod.GET)
	public List<WriteReviewMf> getAllMfReviews(){
		return reviewProductsService.getMfReview();
	}
	
	@RequestMapping(value="/allBullionComments", method = RequestMethod.GET)
	public List<WriteReviewBullion> getAllBullionReviews(){
		return reviewProductsService.getBullionReview();
	}
	
	@RequestMapping(value="/allBankingComments", method = RequestMethod.GET)
	public List<WriteReviewBanking> getAllBankingReviews(){
		return reviewProductsService.getBankingReview();
	}
	
	@RequestMapping(value="/allStocksComments", method = RequestMethod.GET)
	public List<WriteReviewStocks> getAllStocksReviews(){
		return reviewProductsService.getStocksReview();
	}
	
	@RequestMapping(value="/rowStocks/{stocksId}", method = RequestMethod.DELETE)
	public boolean deleteStocks(@PathVariable("stocksId") int stocksId) {
		return this.reviewProductsService.deleteStocks(stocksId);
	}
	
	@RequestMapping(value="/rowMf/{MfId}", method = RequestMethod.DELETE)
	public boolean deleteMf(@PathVariable("MfId") int MfId) {
		return this.reviewProductsService.deleteMf(MfId);
	}
	
	@RequestMapping(value="/rowBank/{BankId}", method = RequestMethod.DELETE)
	public boolean deleteBanking(@PathVariable("BankId") int BankId) {
		return this.reviewProductsService.deleteBanking(BankId);
	}
	
	
	@RequestMapping(value="/rowBullion/{BullionId}", method = RequestMethod.DELETE)
	public boolean deleteBullion(@PathVariable("BullionId") int BullionId) {
		return this.reviewProductsService.deleteBullion(BullionId);
	}


	

	

}
