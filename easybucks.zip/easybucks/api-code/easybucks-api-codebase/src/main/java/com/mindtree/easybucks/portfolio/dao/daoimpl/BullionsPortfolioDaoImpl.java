package com.mindtree.easybucks.portfolio.dao.daoimpl;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucks.portfolio.dao.BullionsPortfolioDao;
import com.mindtree.easybucks.portfolio.entity.BullionsPortfolio;
import com.mindtree.easybucks.portfolio.exception.daoexception.BullionsPortfolioDaoException;

@Repository
@Transactional("transactionManager")
public class BullionsPortfolioDaoImpl implements BullionsPortfolioDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public Session getSession(){
		return sessionFactory.getCurrentSession();
	}

	public BullionsPortfolio getBullionsPortfolioById(int bullionsPortId) throws BullionsPortfolioDaoException {
		try{
			return getSession().get(BullionsPortfolio.class, new Integer(bullionsPortId));
		}
		catch(HibernateException e){
			throw new BullionsPortfolioDaoException("Error in getting portfolio in Bullions Dao", e.getCause());
		}
	}

	public boolean deleteBullionsPortfolioById(int bullionsPortId) throws BullionsPortfolioDaoException {
		try{
			BullionsPortfolio bullionsPort = getBullionsPortfolioById(bullionsPortId);
			getSession().delete(bullionsPort);
			return true;
		}
		catch(HibernateException e){
			throw new BullionsPortfolioDaoException("Error in deleting Bullions Portfolio in Bullions Dao", e.getCause());
		}
	}
	

}
