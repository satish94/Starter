package com.mindtree.easybucks.products.dao.daoImpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucks.products.dao.StocksDao;
import com.mindtree.easybucks.products.entities.Stocks;
import com.mindtree.easybucks.products.exceptions.daoexceptions.ProductsDaoException;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.signup.service.EasyService.UserService;
import com.mindtree.easybucks.watchlist.exception.serviceexception.WatchlistServiceException;
import com.mindtree.easybucks.watchlist.services.stockmarketservice.StockWatchlistService;

@Repository
@Transactional("transactionManager")
public class StocksDaoImpl implements StocksDao {

	private static final Logger logger = LoggerFactory.getLogger(StocksDaoImpl.class);

	@Autowired
	private SessionFactory sessionFactory;
	
	@Autowired
	UserService userService;
	
	@Autowired
	StockWatchlistService watchlist ;

	public void setSessionFactory(SessionFactory sf) {
		this.sessionFactory = sf;
	}

	public Session getSession() throws ProductsDaoException {
		return this.sessionFactory.getCurrentSession();
	}

	public String addStocks(Stocks stocks) throws ProductsDaoException {
		String message;
		try {
			getSession().save(stocks);
			message = "Stocks added successfully";
		} catch (ProductsDaoException e) {
			message = e.getMessage() + " caused by " + e.getCause();
		}
		return message;
	}

	public List<Stocks> getAllStocks() throws ProductsDaoException {
		List<Stocks> stocksList = new ArrayList<Stocks>();
		try {
			stocksList = getSession().createQuery("from Stocks").list();
		} catch (ProductsDaoException e) {
			logger.info(e.getMessage() + " caused by " + e.getCause());
			stocksList = null;
		}
		return stocksList;
	}

	public Stocks getStocks(int id) throws ProductsDaoException {
		Stocks stocks = new Stocks();
		try {
			stocks = getSession().get(Stocks.class, new Integer(id));
		} catch (ProductsDaoException e) {
			logger.info(e.getMessage() + " caused by " + e.getCause());
			stocks = null;
		}
		return stocks;
	}

	public String deleteStocks(int id) throws ProductsDaoException {

		Stocks stocks = new Stocks();
		List<User> users = new ArrayList<User>();
		users = userService.getUsers();
		stocks = getStocks(id) ;
		for (User user : users) {
			try {
				watchlist.deleteFromStockWatchlist(user, stocks) ;
			} catch (WatchlistServiceException e) {
				throw new ProductsDaoException("Unable to delete from watchlist", e);
			}
		}
		try {
			getSession().delete(stocks);
			return ("Stocks Deleted Successfully");
		} catch (ProductsDaoException e) {
			return (e.getMessage() + " caused by " + e.getCause());
		}
	}
}
