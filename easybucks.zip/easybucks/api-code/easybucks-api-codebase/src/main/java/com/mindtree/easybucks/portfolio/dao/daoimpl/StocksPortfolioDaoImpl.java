package com.mindtree.easybucks.portfolio.dao.daoimpl;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucks.portfolio.dao.StocksPortfolioDao;
import com.mindtree.easybucks.portfolio.entity.StocksPortfolio;
import com.mindtree.easybucks.portfolio.exception.daoexception.StocksPortfolioDaoException;


@Repository
@Transactional("transactionManager")
public class StocksPortfolioDaoImpl implements StocksPortfolioDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public Session getSession(){
		return sessionFactory.getCurrentSession();
	}

	public StocksPortfolio getStocksPortfolioById(int stocksPortId) throws StocksPortfolioDaoException {
		try{
			return getSession().get(StocksPortfolio.class, new Integer(stocksPortId));
		}
		catch(HibernateException e){
			throw new StocksPortfolioDaoException("Error in getting StocksPortfolio in Stocs Dao", e.getCause());
		}
	}

	public boolean deleteStocksPortfolioById(int stocksPortId) throws StocksPortfolioDaoException {
		
		StocksPortfolio stocksPort;
		
		try{
			stocksPort = getStocksPortfolioById(stocksPortId);
			getSession().delete(stocksPort);
			return true;
		}
		catch(HibernateException e){
			throw new StocksPortfolioDaoException("Error in delete Stocks in Stocks Dao", e.getCause());
		}
	}
}
