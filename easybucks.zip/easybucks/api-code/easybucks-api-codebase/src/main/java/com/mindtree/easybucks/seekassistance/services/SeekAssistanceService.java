package com.mindtree.easybucks.seekassistance.services;

import java.util.List;

import com.mindtree.easybucks.seekassistance.dto.BookAppointmentDTO;
import com.mindtree.easybucks.seekassistance.dto.BookAppointmentUpdateDTO;
import com.mindtree.easybucks.seekassistance.dto.SeekAssistanceDTO;
import com.mindtree.easybucks.seekassistance.dto.SeekAssistanceUpdateDTO;
import com.mindtree.easybucks.seekassistance.entities.BookAppointment;
import com.mindtree.easybucks.seekassistance.entities.SeekAssistance;
import com.mindtree.easybucks.signup.entity.User;


public interface SeekAssistanceService 
{
	//Get all the seek assistance details
	List<SeekAssistance> getALLSeekAssistanceDetails();

	//Add new entry in seek Assistance table
	boolean addSeekAssistance(SeekAssistanceDTO seekAssistancedto);

		//Update Seek Assistance table
	SeekAssistance updateSeekAssistanceDetail(SeekAssistanceUpdateDTO seekAssistanceUpdatedto);

	//Delete seek assistance entry
	boolean deleteSeekAssistance(int seekAssistanceId);
	
	
	
	List<User> getALLUsersDetails();
	
	boolean addBookAppointment(BookAppointmentDTO bookAppointmentdto);
	
	BookAppointment updateBookAppointment(BookAppointmentUpdateDTO bookAppointmentUpdatedto);

	List<BookAppointment> getALLAppointmentDetails();
	
	boolean deleteBookAppointment(int bookAppointmentId);

}
