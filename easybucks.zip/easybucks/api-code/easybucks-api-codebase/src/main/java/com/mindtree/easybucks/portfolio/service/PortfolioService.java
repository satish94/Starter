package com.mindtree.easybucks.portfolio.service;

import java.util.List;

import com.mindtree.easybucks.portfolio.entity.Portfolio;
import com.mindtree.easybucks.portfolio.exception.serviceexception.PortfolioServiceException;

public interface PortfolioService {
	
	public boolean addToPortfolio(Portfolio portfolio) throws PortfolioServiceException;
	
	public boolean deletePortfolio(Portfolio portfolio) throws PortfolioServiceException;
	
	public boolean updateToPortfolio(Portfolio portfolio) throws PortfolioServiceException;
	
	public List<Portfolio> getAllPortfolio() throws PortfolioServiceException;
	
	public Portfolio getPortfolioByUserId(int userId) throws PortfolioServiceException;

}
