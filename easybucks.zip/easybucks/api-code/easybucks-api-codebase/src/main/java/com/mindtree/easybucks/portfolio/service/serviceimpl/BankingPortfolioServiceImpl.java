package com.mindtree.easybucks.portfolio.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.easybucks.portfolio.dao.BankingPortfolioDao;
import com.mindtree.easybucks.portfolio.dao.PortfolioDao;
import com.mindtree.easybucks.portfolio.entity.BankingPortfolio;
import com.mindtree.easybucks.portfolio.entity.Portfolio;
import com.mindtree.easybucks.portfolio.exception.daoexception.BankingPortfolioDaoException;
import com.mindtree.easybucks.portfolio.exception.daoexception.PortfolioDaoException;
import com.mindtree.easybucks.portfolio.exception.serviceexception.BankingPortfolioServiceException;
import com.mindtree.easybucks.portfolio.exception.serviceexception.StocksPortfolioServiceException;
import com.mindtree.easybucks.portfolio.service.BankingPortfolioService;
import com.mindtree.easybucks.products.entities.Banking;
import com.mindtree.easybucks.products.exceptions.serviceexceptions.ProductsServiceException;
import com.mindtree.easybucks.products.service.BankingService;
import com.mindtree.easybucks.signup.service.EasyService.UserService;

@Service
public class BankingPortfolioServiceImpl implements BankingPortfolioService {
	
	@Autowired
	private PortfolioDao portfolioDao;
	
	@Autowired
	private UserService userServ;
	
	@Autowired
	private BankingService bankingServ;
	
	@Autowired
	private BankingPortfolioDao bankingPortDao;
	

	public BankingPortfolio getBankingPortfolio(int prodId, int noOfMonths, double amount) throws BankingPortfolioServiceException {
		
		BankingPortfolio bankingPort = new BankingPortfolio();
		Banking bankingProd;
		try{
			bankingProd = bankingServ.getBanking(prodId);
		}
		catch(ProductsServiceException e){
			throw new BankingPortfolioServiceException("Error in getting products in Banking Service", e.getCause());
		}
		
		bankingPort.setBankingProdId(bankingProd);
		bankingPort.setNoOfMonths(noOfMonths);
		bankingPort.setAmount(amount);
		return bankingPort;
	}


	public boolean addBankingPortfolioByUserId(int prodId, int userId, int noOfMonths, double amount)
			throws BankingPortfolioServiceException {
		Portfolio portfolio = new Portfolio();
		
		if(noOfMonths<0){
			return false;
		}
		
		try{
			portfolio = portfolioDao.getPortfolioByUserId(userId);
		}
		catch(PortfolioDaoException e){
			
			try{
				portfolio.setUser(userServ.getUserById(userId));
				portfolioDao.addToPortfolio(portfolio);
			}
			catch(PortfolioDaoException ex){
				throw new BankingPortfolioServiceException("Error in getting portfolio by id in Banking portfolio service", ex.getCause());
			}
		}
		
		List<BankingPortfolio> bankingPortList = portfolio.getBankingPort();
		
		try{
			bankingPortList.add(getBankingPortfolio(prodId, noOfMonths, amount));
		}
		catch(BankingPortfolioServiceException e){
			throw e;
		}
		catch(NullPointerException e){
			bankingPortList = new ArrayList<BankingPortfolio> ();
			bankingPortList.add(getBankingPortfolio(prodId, noOfMonths, amount));
		}
		
		portfolio.setBankingPort(bankingPortList);
		
		try{
			return portfolioDao.updatePortfolio(portfolio);
		}
		catch(PortfolioDaoException e){
			throw new BankingPortfolioServiceException("Error in updating banking portfolio in banking sevice", e.getCause());
		}
	}

	public boolean deleteBankingPortfolioByUserId(int bankingPortId, int userId)
			throws BankingPortfolioServiceException {
		Portfolio portfolio;
		try{
			portfolio = portfolioDao.getPortfolioByUserId(userId);
		}
		catch(PortfolioDaoException e){
			throw new BankingPortfolioServiceException("Error in getting portfolio by user Id in Banking service", e.getCause());
		}
		
		List<BankingPortfolio> bankingPortList = portfolio.getBankingPort();

		for(int i = 0; i<bankingPortList.size();i++){
			BankingPortfolio bankingPort = bankingPortList.get(i);
			if(bankingPort.getBankingPortId() == bankingPortId){
				bankingPortList.remove(bankingPort);
				i--;
			}
		}
		
		portfolio.setBankingPort(bankingPortList);
		
		try{
			 portfolioDao.updatePortfolio(portfolio);
		}
		catch(PortfolioDaoException e){
			throw new BankingPortfolioServiceException("Error in updating portfolio by user id in banking service", e.getCause());
		}
		try{
			return bankingPortDao.deletePortfolioById(bankingPortId);
		}
		catch(BankingPortfolioDaoException e){
			throw new BankingPortfolioServiceException("Error in deleting StocksPortfolio", e.getCause());
		}
		
	}

	public List<BankingPortfolio> getPortfolioByUserId(int userId) throws BankingPortfolioServiceException {
		Portfolio portfolio;
		
		try{
			portfolio = portfolioDao.getPortfolioByUserId(userId);
			return portfolio.getBankingPort();
		}
		catch(PortfolioDaoException e){
			throw new BankingPortfolioServiceException("Error in getting portfolio by userId in banking Service", e.getCause());
		}
	}


}





