package com.mindtree.easybucks.review.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="REVIEW_MF")
public class WriteReviewMf {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="M_ID")
	private int id;
	
	@Column
	private String review;
	
	@Column
	private String stars;
	

	public WriteReviewMf(int id, String review, String stars) {
		super();
		this.id = id;
		this.review = review;
		this.stars = stars;
		
	}
	

	public String getReview() {
		return review;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public void setReview(String review) {
		this.review = review;
	}

	public String getStars() {
		return stars;
	}

	public void setStars(String stars) {
		this.stars = stars;
	}

	public WriteReviewMf() {
		super();
		
	}
	
	
	

}