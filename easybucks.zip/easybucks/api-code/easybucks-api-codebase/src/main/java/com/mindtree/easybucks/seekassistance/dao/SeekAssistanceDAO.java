package com.mindtree.easybucks.seekassistance.dao;

import java.util.List;

import com.mindtree.easybucks.seekassistance.entities.BookAppointment;
import com.mindtree.easybucks.seekassistance.entities.SeekAssistance;
import com.mindtree.easybucks.signup.entity.User;


public interface SeekAssistanceDAO 
{
	List<SeekAssistance> getALLSeekAssistanceDetails();
	
	boolean addSeekAssistance(SeekAssistance seekAssistance);

	SeekAssistance updateSeekAssistanceDetail(SeekAssistance seekAssistance);

	boolean deleteSeekAssistance(int seekAssistanceId);
	
	List<User> getALLUsersDetails();
	
	boolean addBookAppointment(BookAppointment bookAppointment);
	
	BookAppointment updateBookAppointment(BookAppointment bookAppointment);
	
	List<BookAppointment> getALLAppointmentDetails();
	
	boolean deleteBookAppointment(int bookAppointmentId);
}
