package com.mindtree.easybucks.signup.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.easybucks.signup.dao.UserRoleDao;

import com.mindtree.easybucks.signup.entity.UserRole;
import com.mindtree.easybucks.signup.service.EasyService.UserRoleService;
@Service
public class UserRoleServiceImpl implements UserRoleService {

	@Autowired
	private UserRoleDao userRoleDao;

	public boolean adduserRole(UserRole userRole) {
			userRoleDao.addUserRole(userRole);
			return true;
	}

	public List<UserRole> getUserRole() {
			return userRoleDao.getUserRole();
	}

	public UserRole getUserRoleById(int id) {
			return userRoleDao.getUserRoleById(id);	
	}
	
	
	

}
