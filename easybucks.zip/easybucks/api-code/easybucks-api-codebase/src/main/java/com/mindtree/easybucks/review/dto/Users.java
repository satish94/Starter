package com.mindtree.easybucks.review.dto;

public class Users {
	
private String product;
private String comment;
private String rating;
public Users() {
	super();
	
}
public Users(String product, String comment, String rating) {
	super();
	this.product = product;
	this.comment = comment;
	this.rating = rating;
}


public String getProduct() {
	return product;
}
public void setProduct(String product) {
	this.product = product;
}
public String getComment() {
	return comment;
}
public void setComment(String comment) {
	this.comment = comment;
}
public String getRating() {
	return rating;
}
public void setRating(String rating) {
	this.rating = rating;
}


}
