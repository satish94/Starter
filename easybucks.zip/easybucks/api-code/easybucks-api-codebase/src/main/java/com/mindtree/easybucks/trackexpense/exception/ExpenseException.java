package com.mindtree.easybucks.trackexpense.exception;

public class ExpenseException extends Exception {

	private static final long serialVersionUID = 1L;

	public ExpenseException() {
		super();
	}

	public ExpenseException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}
	

}
