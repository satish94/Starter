package com.mindtree.easybucks.portfolio.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.mindtree.easybucks.products.entities.Banking;

@Entity
@Table(name = "banking_portfolio")
public class BankingPortfolio {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "banking_port_id")
	private int bankingPortId;
	
	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "banking_prod_id")
	private Banking bankingProdId;
	
	@Column(name  = "no_of_months")
	private int noOfMonths;
	
	@Column(name = "maturity_value")
	private int maturityValue;
	
	@Column(name = "amount")
	private double amount ;
	
	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public int getBankingPortId() {
		return bankingPortId;
	}

	public void setBankingPortId(int bankingPortId) {
		this.bankingPortId = bankingPortId;
	}

	public Banking getBankingProdId() {
		return bankingProdId;
	}

	public void setBankingProdId(Banking bankingProdId) {
		this.bankingProdId = bankingProdId;
	}

	public int getNoOfMonths() {
		return noOfMonths;
	}

	public void setNoOfMonths(int noOfMonths) {
		this.noOfMonths = noOfMonths;
	}

	public int getMaturityValue() {
		return maturityValue;
	}

	public void setMaturityValue(int maturityValue) {
		this.maturityValue = maturityValue;
	}

	@Override
	public String toString() {
		return "BankingPortfolio [bankingPortId=" + bankingPortId + ", bankingProdId=" + bankingProdId + ", noOfMonths="
				+ noOfMonths + ", maturityValue=" + maturityValue + ", amount=" + amount + "]";
	}

}
