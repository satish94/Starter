package com.mindtree.easybucks.products.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="stocks")
public class Stocks {

	@Column
	@Id
	@GeneratedValue(generator = "increment")
	@GenericGenerator(name = "increment", strategy = "increment")
	private int id ;
	
	@Column
	private String name;
	@Column
	private String code;
	@Column
	private double currTradingPrice;
	@Column
	private double lastTradingPrice ;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public double getCurrTradingPrice() {
		return currTradingPrice;
	}
	public void setCurrTradingPrice(double currTradingPrice) {
		this.currTradingPrice = currTradingPrice;
	}
	public double getLastTradingPrice() {
		return lastTradingPrice;
	}
	public void setLastTradingPrice(double lastTradingPrice) {
		this.lastTradingPrice = lastTradingPrice;
	}
	
	public Stocks() {
		super();
	}
	
	public Stocks(int id, String name, String code, double currTradingPrice, double lastTradingPrice) {
		super();
		this.id = id;
		this.name = name;
		this.code = code;
		this.currTradingPrice = currTradingPrice;
		this.lastTradingPrice = lastTradingPrice;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		result = prime * result + id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Stocks other = (Stocks) obj;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		if (id != other.id)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Stocks [id=" + id + ", name=" + name + ", code=" + code + ", currTradingPrice=" + currTradingPrice
				+ ", lastTradingPrice=" + lastTradingPrice + "]";
	}
}
