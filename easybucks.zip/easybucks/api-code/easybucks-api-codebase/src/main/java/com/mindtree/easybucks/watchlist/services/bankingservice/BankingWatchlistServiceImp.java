package com.mindtree.easybucks.watchlist.services.bankingservice;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.easybucks.products.entities.Banking;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.watchlist.dao.banking.BankingWatchlistDao;
import com.mindtree.easybucks.watchlist.exception.daoexception.WatchlistDaoException;
import com.mindtree.easybucks.watchlist.exception.serviceexception.WatchlistServiceException;

@Service
public class BankingWatchlistServiceImp implements BankingWatchlistService {
	@Autowired
	private BankingWatchlistDao bankingWatchlistDao;

	public boolean addToBankingWatchlist(User user, Banking bank) throws WatchlistServiceException {
		try {
			return bankingWatchlistDao.addToBankingWatchlist(user, bank);
		} catch (WatchlistDaoException e) {
			throw new WatchlistServiceException("Unable to add data from service",e) ;
		}
	}

	public boolean deleteFromBankingWatchlist(User user, Banking bank) throws WatchlistServiceException {
		try {
			return bankingWatchlistDao.deleteFromBankingWatchlist(user, bank);
		} catch (WatchlistDaoException e) {
			throw new WatchlistServiceException("Unable to delete data from service",e) ;
		}
	}
	public List<Banking> getBankingWatchlistByUser(User user) throws WatchlistServiceException {
		try {
			return bankingWatchlistDao.getBankingWatchlistByUser(user);
		} catch (WatchlistDaoException e) {
			throw new WatchlistServiceException("Unable to get data from service",e) ;
		}
	}
	
	public Set<Banking> getBankingWatchlistByUser1(User user) throws WatchlistServiceException {
		try {
			return bankingWatchlistDao.getBankingWatchlistByUser1(user);
		} catch (WatchlistDaoException e) {
			throw new WatchlistServiceException("Unable to get data from service",e) ;
		}
	}

}
