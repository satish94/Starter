package com.mindtree.easybucks.watchlist.services.mutualfundservice;

import java.util.List;
import java.util.Set;

import com.mindtree.easybucks.products.entities.MutualFunds;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.watchlist.exception.serviceexception.WatchlistServiceException;

public interface MutualFundWatchlistService {
	
	public boolean addToMutualFundWatchlist(User user,MutualFunds mutualFunds) throws WatchlistServiceException;
	public boolean deleteFromMutualFundWatchlist(User user,MutualFunds mutualFunds ) throws WatchlistServiceException;
	List<MutualFunds> getMutualFundWatchlistByUser(User user) throws WatchlistServiceException;
	Set<MutualFunds> getMutualFundWatchlistByUser1(User user) throws WatchlistServiceException;
}
