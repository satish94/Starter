package com.mindtree.easybucks.portfolio.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.easybucks.portfolio.entity.Portfolio;
import com.mindtree.easybucks.portfolio.exception.PortfolioException;
import com.mindtree.easybucks.portfolio.service.BankingPortfolioService;
import com.mindtree.easybucks.portfolio.service.BullionsPortfolioService;
import com.mindtree.easybucks.portfolio.service.MFPortfolioService;
import com.mindtree.easybucks.portfolio.service.PortfolioService;
import com.mindtree.easybucks.portfolio.service.StocksPortfolioService;

@RestController
@CrossOrigin
@RequestMapping(value = "/portfolio")
public class PortfolioController {
	
	@Autowired
	private StocksPortfolioService stocksPortServ;
	
	@Autowired
	private BankingPortfolioService bankingPortServ;
	
	@Autowired
	private BullionsPortfolioService bullionsPortServ;
	
	@Autowired
	private MFPortfolioService mfPortServ;
	
	@Autowired
	private PortfolioService portServ;
	
	@RequestMapping(value = "/addstocks/{prodId}/{userId}/{noOfStocks}", method = RequestMethod.GET)
	public int addStocks(@PathVariable("prodId") int prodId,@PathVariable("userId") int userId,@PathVariable("noOfStocks") int noOfStocks ){
		System.out.println(prodId);
		System.out.println(userId);
		System.out.println(noOfStocks);
		
		try{
			stocksPortServ.addStocksPortfolioByUserId(prodId, userId, noOfStocks);
			return 1;
		}
		catch(PortfolioException e){
			return 2;
		}
	}
	
	@RequestMapping(value = "/addbanking/{prodId}/{userId}/{noOfMonths}/{amount}", method = RequestMethod.GET)
	public int addBanking(@PathVariable("prodId") int prodId,@PathVariable("userId") int userId,@PathVariable("noOfMonths") int noOfMonths,@PathVariable("amount") double amount  ){
		System.out.println(prodId);
		System.out.println(userId);
		System.out.println(noOfMonths);
		
		try{
			bankingPortServ.addBankingPortfolioByUserId(prodId, userId, noOfMonths,amount);
			return 1;
		}
		catch(PortfolioException e){
			e.printStackTrace();
			return 0;
		}
	}
	
	@RequestMapping(value = "/addbullion/{prodId}/{userId}/{quantity}", method = RequestMethod.GET)
	public int addBullion(@PathVariable("prodId") int prodId,@PathVariable("userId") int userId,@PathVariable("quantity") int quantity ){
		System.out.println(prodId);
		System.out.println(userId);
		System.out.println(quantity);
		
		try{
			bullionsPortServ.addBullionsPortfolioByUserId(prodId, userId, quantity);
			return 1;
		}
		catch(PortfolioException e){
			e.printStackTrace();
			return 0;
		}
	}
	
	@RequestMapping(value = "/addmfportfolio/{prodId}/{userId}/{quantity}", method = RequestMethod.GET)
	public int addMFPortfolio(@PathVariable("prodId") int prodId,@PathVariable("userId") int userId,@PathVariable("quantity") int quantity ){
		System.out.println(prodId);
		System.out.println(userId);
		System.out.println(quantity);
		
		try{
			mfPortServ.addMFPortfolioByUserId(prodId, userId, quantity);
			return 1;
		}
		catch(PortfolioException e){
			e.printStackTrace();
			return 0;
		}
	}
	
	@RequestMapping(value = "/getPortfolio/{userId}")
	public Portfolio getPortfolio(@PathVariable("userId") int userId){
		try{
			return portServ.getPortfolioByUserId(userId);
		}
		catch(PortfolioException e){
			e.printStackTrace();
			System.out.println(e.getMessage()+e.getCause());
			return null;
		}
	}
	
	@RequestMapping(value = "/deleteStocks/{stocksPortId}/{userId}", method = RequestMethod.GET)
	public int deleteStocks(@PathVariable("stocksPortId") int stocksPortId, @PathVariable("userId") int userId){
		
		try{
			stocksPortServ.deleteStocksPortfolioByUserId(stocksPortId, userId);
			return 1;
		}
		catch(PortfolioException e){
			e.printStackTrace();
			System.out.println(e.getMessage()+e.getCause());
			return 2;
		}
	}
	
	@RequestMapping(value = "/deletebanking/{bankingPortId}/{userId}", method = RequestMethod.GET)
	public int deleteBanking(@PathVariable("bankingPortId") int bankingPortId, @PathVariable("userId") int userId){
		
		try{
			bankingPortServ.deleteBankingPortfolioByUserId(bankingPortId, userId);
			return 1;
		}
		catch(PortfolioException e){
			e.printStackTrace();
			System.out.println(e.getMessage()+e.getCause());
			return 2;
		}
	}
		
		@RequestMapping(value = "/deletebullions/{bullionsPortId}/{userId}", method = RequestMethod.GET)
		public int deleteBullions(@PathVariable("bullionsPortId") int bullionsPortId, @PathVariable("userId") int userId){
			
			try{
				bullionsPortServ.deleteBullionsPortfolioByUserId(bullionsPortId, userId);
				return 1;
			}
			catch(PortfolioException e){
				e.printStackTrace();
				System.out.println(e.getMessage()+e.getCause());
				return 2;
			}	
		}
	
		@RequestMapping(value = "/deletemf/{mfPortId}/{userId}", method = RequestMethod.GET)
		public int deletemf(@PathVariable("mfPortId") int mfPortId, @PathVariable("userId") int userId){
			
			try{
				mfPortServ.deleteMFPortfolioByUserId(mfPortId, userId);
				return 1;
			}
			catch(PortfolioException e){
				e.printStackTrace();
				System.out.println(e.getMessage()+e.getCause());
				return 2;
			}	
		}
	
	
}





