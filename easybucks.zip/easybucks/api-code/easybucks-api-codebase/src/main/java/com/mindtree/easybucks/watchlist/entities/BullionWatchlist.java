package com.mindtree.easybucks.watchlist.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.mindtree.easybucks.products.entities.Bullions;
import com.mindtree.easybucks.signup.entity.User;

@Entity
@Table(name="bullionwatchlist")
public class BullionWatchlist {
	@Id
	@GeneratedValue(generator = "increment")
	@GenericGenerator(name = "increment", strategy = "increment")
	private int bullionWatchlistId;
	@OneToOne
	@JoinColumn(name="userId")
	private User user;
	@ManyToMany
	private Set<Bullions> bullionsList = new HashSet<Bullions>(0);
	public BullionWatchlist() {
		super();
	}
	public BullionWatchlist(int bullionWatchlistId, User user, Set<Bullions> bullionsList) {
		super();
		this.bullionWatchlistId = bullionWatchlistId;
		this.user = user;
		this.bullionsList = bullionsList;
	}
	public int getBullionWatchlistId() {
		return bullionWatchlistId;
	}
	public void setBullionWatchlistId(int bullionWatchlistId) {
		this.bullionWatchlistId = bullionWatchlistId;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Set<Bullions> getBullionsList() {
		return bullionsList;
	}
	public void setBullionsList(Set<Bullions> bullionsList) {
		this.bullionsList = bullionsList;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + bullionWatchlistId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BullionWatchlist other = (BullionWatchlist) obj;
		if (bullionWatchlistId != other.bullionWatchlistId)
			return false;
		return true;
	}
	
	
	

}
