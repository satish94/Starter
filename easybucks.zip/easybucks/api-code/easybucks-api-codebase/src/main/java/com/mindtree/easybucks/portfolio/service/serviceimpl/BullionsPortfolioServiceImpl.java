package com.mindtree.easybucks.portfolio.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.easybucks.portfolio.dao.BullionsPortfolioDao;
import com.mindtree.easybucks.portfolio.dao.PortfolioDao;
import com.mindtree.easybucks.portfolio.entity.BullionsPortfolio;
import com.mindtree.easybucks.portfolio.entity.Portfolio;
import com.mindtree.easybucks.portfolio.exception.daoexception.BullionsPortfolioDaoException;
import com.mindtree.easybucks.portfolio.exception.daoexception.PortfolioDaoException;
import com.mindtree.easybucks.portfolio.exception.serviceexception.BullionsPortfolioServiceException;
import com.mindtree.easybucks.portfolio.service.BullionsPortfolioService;
import com.mindtree.easybucks.products.entities.Bullions;
import com.mindtree.easybucks.products.exceptions.serviceexceptions.ProductsServiceException;
import com.mindtree.easybucks.products.service.BullionsService;
import com.mindtree.easybucks.signup.service.EasyService.UserService;

@Service
public class BullionsPortfolioServiceImpl implements BullionsPortfolioService {
	
	@Autowired
	private PortfolioDao portfolioDao;
	
	@Autowired
	private BullionsService bullionServ;
	
	@Autowired
	private UserService userServ;
	
	@Autowired
	private BullionsPortfolioDao bullionsPortDao;
	

	public BullionsPortfolio getBullionsPortfolio(int prodId, int quantity) throws BullionsPortfolioServiceException {
		
		BullionsPortfolio bullionsPortfolio = new BullionsPortfolio();
		Bullions bullionsProd;
		try{
			bullionsProd = bullionServ.getBullions(prodId);
		}
		catch(ProductsServiceException e){
			throw new BullionsPortfolioServiceException("Error in getting products in Bullions Service", e.getCause());
		}
		
		bullionsPortfolio.setBullionProd(bullionsProd);
		bullionsPortfolio.setPurchasePrice(bullionsProd.getPrice());
		bullionsPortfolio.setQuantity(quantity);
		
		return bullionsPortfolio;
	}

	

	public boolean addBullionsPortfolioByUserId(int prodId, int userId, int quantity)
			throws BullionsPortfolioServiceException {
		Portfolio portfolio = new Portfolio();
		try{
			portfolio = portfolioDao.getPortfolioByUserId(userId);
		}
		catch(PortfolioDaoException e){
			
			try{
				portfolio.setUser(userServ.getUserById(userId));
				portfolioDao.addToPortfolio(portfolio);
			}
			catch(PortfolioDaoException ex){
				throw new BullionsPortfolioServiceException("Error in getting portfolio by user id in bullion service", ex.getCause());
			}
		}
		
		List<BullionsPortfolio> bullionsPortList = portfolio.getBullionsPort();
		
		try{
			bullionsPortList.add(getBullionsPortfolio(prodId, quantity));
		}
		catch(BullionsPortfolioServiceException e){
			throw e;
		}
		catch(NullPointerException e){
			bullionsPortList = new ArrayList<BullionsPortfolio>();
			bullionsPortList.add(getBullionsPortfolio(prodId, quantity));
		}
		portfolio.setBullionsPort(bullionsPortList);
		
		try{
			return portfolioDao.updatePortfolio(portfolio);
		}
		catch(PortfolioDaoException e){
			throw new BullionsPortfolioServiceException("Error in updating portfolio in bullions Service", e.getCause());
		}
	}

	public boolean deleteBullionsPortfolioByUserId(int bullionsPortId, int userId)
			throws BullionsPortfolioServiceException {
		Portfolio portfolio;
		try{
			portfolio = portfolioDao.getPortfolioByUserId(userId);
		}
		catch(PortfolioDaoException e){
			throw new BullionsPortfolioServiceException("Error in getting portfolio by user id in bullion service", e.getCause());
		}
		
		List<BullionsPortfolio> bullionsPortList = portfolio.getBullionsPort();

		for(int i = 0; i<bullionsPortList.size();i++){
			BullionsPortfolio bullionPort = bullionsPortList.get(i);
			if(bullionPort.getBullionsPortId() == bullionsPortId){
				bullionsPortList.remove(bullionPort);
				i--;
			}
		}
		
		portfolio.setBullionsPort(bullionsPortList);
		
		try{
			portfolioDao.updatePortfolio(portfolio);
		}
		catch(PortfolioDaoException e){
			throw new BullionsPortfolioServiceException("Error in updating portfolio in bullions Service", e.getCause());
		}
		try{
			return bullionsPortDao.deleteBullionsPortfolioById(bullionsPortId);
		}
		catch(BullionsPortfolioDaoException e){
			throw new BullionsPortfolioServiceException("Error in deleting StocksPortfolio", e.getCause());
		}
		
	}

	public List<BullionsPortfolio> getBullionsPortfolioByUserId(int userId) throws BullionsPortfolioServiceException {
		Portfolio portfolio;
		
		try{
			System.out.println("in getBulions Service");
			portfolio = portfolioDao.getPortfolioByUserId(userId);
			return portfolio.getBullionsPort();
		}
		catch(PortfolioDaoException e){
			throw new BullionsPortfolioServiceException("Error in getting portfolio by user id", e.getCause());
		}
	}


}
