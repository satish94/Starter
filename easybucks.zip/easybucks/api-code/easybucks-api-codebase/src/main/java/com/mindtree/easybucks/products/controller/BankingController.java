package com.mindtree.easybucks.products.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.easybucks.products.entities.Banking;
import com.mindtree.easybucks.products.exceptions.serviceexceptions.ProductsServiceException;
import com.mindtree.easybucks.products.service.BankingService;

@CrossOrigin
@RestController
@RequestMapping(value="/products/banking")
public class BankingController {
	
	@Autowired
	private BankingService bankingService ;

	public void setBankingService(BankingService bankingService) {
		this.bankingService = bankingService;
	}
	
	@RequestMapping(value="/add", method = RequestMethod.POST)
	public String addBanking(@RequestBody Banking banking)
	{
		try {
			return(this.bankingService.addBanking(banking));
		} catch (ProductsServiceException e1) {
			return(e1.getMessage()+"\n"+e1.getCause());
		}
	}
	
	@RequestMapping(value="/all", method = RequestMethod.GET)
	public List<Banking> getAllBanking(){
		List<Banking> bankingList=new ArrayList();
		try {
			bankingList=this.bankingService.getAllBanking();
		} catch (ProductsServiceException e) {
			bankingList= null ;
		}
		return bankingList;
	}
	
	@RequestMapping(value="/{Id}", method = RequestMethod.GET)
	public Banking getBanking(@PathVariable("Id")int id){
		Banking banking = new Banking() ;
		try {
			banking = this.bankingService.getBanking(id) ;
		} catch (ProductsServiceException e) {
			banking = null ;
		}
		return banking ;
	}
	
	@RequestMapping(value="/delete/{Id}", method = RequestMethod.DELETE)
	public String deleteBanking(@PathVariable("Id")int id)
	{
		try {
			return this.bankingService.deleteBanking(id) ;
		} catch (ProductsServiceException e1) {
			return(e1.getMessage()+"\n"+e1.getCause());
		}
	}
}
