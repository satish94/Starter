package com.mindtree.easybucks.profile.services;

import com.mindtree.easybucks.profile.dto.ProfileDto;
import com.mindtree.easybucks.signup.entity.User;

public interface ProfileService {

	User getProfile(int userId);

	User updateProfile(ProfileDto profileDto);

}
