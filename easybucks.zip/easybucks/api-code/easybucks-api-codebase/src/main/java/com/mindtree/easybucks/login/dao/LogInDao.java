package com.mindtree.easybucks.login.dao;

import com.mindtree.easybucks.login.exceptions.daoexceptions.LogInDaoImplException;
import com.mindtree.easybucks.signup.entity.User;

public interface LogInDao {
	
	public User getUserByEmail(String userEmail) throws LogInDaoImplException;
	
	public boolean updatePassword(User user) throws LogInDaoImplException;

}
