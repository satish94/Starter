package com.mindtree.easybucks.portfolio.service;

import java.util.List;

import com.mindtree.easybucks.portfolio.entity.StocksPortfolio;
import com.mindtree.easybucks.portfolio.exception.serviceexception.StocksPortfolioServiceException;

public interface StocksPortfolioService {
	
	public StocksPortfolio getStocksPortfolio(int prodId,int noOfStocks) throws StocksPortfolioServiceException;
	
	public boolean addStocksPortfolioByUserId(int prodId, int userId,int noOfStocks) throws StocksPortfolioServiceException;
	
	public boolean deleteStocksPortfolioByUserId(int stocksPortId, int userId) throws StocksPortfolioServiceException;
	
	public List<StocksPortfolio> getStocksPortfolioByuserId(int userId) throws StocksPortfolioServiceException;

}
