package com.mindtree.easybucks.products.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="MutualFunds")
public class MutualFunds {
	
	@Column
	@Id
	@GeneratedValue(generator = "increment")
	@GenericGenerator(name = "increment", strategy = "increment")
	private int id ;
	
	@Column
	private String scheme;
	@Column
	private String code;
	@Column
	private double netAssetValue;
	@Column
	private double repurchasePrice ;
	@Column
	private double salePrice ;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getScheme() {
		return scheme;
	}
	public void setScheme(String scheme) {
		this.scheme = scheme;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public double getNetAssetValue() {
		return netAssetValue;
	}
	public void setNetAssetValue(double netAssetValue) {
		this.netAssetValue = netAssetValue;
	}
	public double getRepurchasePrice() {
		return repurchasePrice;
	}
	public void setRepurchasePrice(double repurchasePrice) {
		this.repurchasePrice = repurchasePrice;
	}
	public double getSalePrice() {
		return salePrice;
	}
	public void setSalePrice(double salePrice) {
		this.salePrice = salePrice;
	}
	public MutualFunds() {
		super();
	}
	public MutualFunds(int id, String scheme, String code, double netAssetValue, double repurchasePrice,
			double salePrice) {
		super();
		this.id = id;
		this.scheme = scheme;
		this.code = code;
		this.netAssetValue = netAssetValue;
		this.repurchasePrice = repurchasePrice;
		this.salePrice = salePrice;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((code == null) ? 0 : code.hashCode());
		result = prime * result + id;
		long temp;
		temp = Double.doubleToLongBits(netAssetValue);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(repurchasePrice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		temp = Double.doubleToLongBits(salePrice);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((scheme == null) ? 0 : scheme.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MutualFunds other = (MutualFunds) obj;
		if (code == null) {
			if (other.code != null)
				return false;
		} else if (!code.equals(other.code))
			return false;
		if (id != other.id)
			return false;
		if (Double.doubleToLongBits(netAssetValue) != Double.doubleToLongBits(other.netAssetValue))
			return false;
		if (Double.doubleToLongBits(repurchasePrice) != Double.doubleToLongBits(other.repurchasePrice))
			return false;
		if (Double.doubleToLongBits(salePrice) != Double.doubleToLongBits(other.salePrice))
			return false;
		if (scheme == null) {
			if (other.scheme != null)
				return false;
		} else if (!scheme.equals(other.scheme))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "MutualFunds [id=" + id + ", scheme=" + scheme + ", code=" + code + ", netAssetValue=" + netAssetValue
				+ ", repurchasePrice=" + repurchasePrice + ", salePrice=" + salePrice + "]";
	}	
}
