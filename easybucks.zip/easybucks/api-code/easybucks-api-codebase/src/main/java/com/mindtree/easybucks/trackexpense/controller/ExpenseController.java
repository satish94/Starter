package com.mindtree.easybucks.trackexpense.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mindtree.easybucks.signup.service.EasyService.UserService;
import com.mindtree.easybucks.trackexpense.entities.Expense;
import com.mindtree.easybucks.trackexpense.exception.serviceexception.ExpenseServiceException;
import com.mindtree.easybucks.trackexpense.service.ExpenseService;

@RestController
@CrossOrigin
@RequestMapping(value="/expense")
public class ExpenseController {
	@Autowired
	private ExpenseService expenseService;
	@Autowired
	private UserService userService;
	
	@RequestMapping(value="/add/{userId}", method = RequestMethod.POST)
	public String addExpense(@RequestBody Expense expense,@PathVariable ("userId") int userId)
	{
		expense.setUser(this.userService.getUserById(userId));
		try {
			this.expenseService.addExpense(expense);
			return "added successfully";
		} catch (ExpenseServiceException e) {
			String s = "message : "+e.getMessage()+"cause : "+e.getCause();
			return s;
		}
	}
	
	@RequestMapping(value="/delete/{userId}/{eid}", method = RequestMethod.DELETE)
	public String deleteExpense(@PathVariable("eid") int eid , @PathVariable("userId") int userId)
	{
		Expense expense = new Expense();
		try {
			expense = getExpenseById(userId, eid);
			this.expenseService.deleteExpense(expense);
			return "product deleted successfully";
		} catch (ExpenseServiceException e) {
			String s = "message : "+e.getMessage()+"cause : "+e.getCause();
			return s;
		}
	}
	
	@RequestMapping(value="/update", method = RequestMethod.PUT)
	public Expense updateExpense(@RequestBody Expense expense)
	{
		Expense ex = new Expense();
		try {
			ex= this.expenseService.updateExpense(expense);
		} catch (ExpenseServiceException e) {
			System.out.println("cant update");
		}
		return ex;
	}
	
	@RequestMapping(value="/{userid}/{eid}", method = RequestMethod. GET)
	public Expense getExpenseById(@PathVariable("userid") int userid, @PathVariable("eid") int eid)
	{
		Expense ex = new Expense();
		try {
			ex = this.expenseService.getExpenseById(eid);
		} catch (ExpenseServiceException e) {
			System.out.println("cant get");
		}
		return ex;
	}
	
	@RequestMapping(value="/{userId}/all", method = RequestMethod.GET)
	public List<Expense> getAllExpenses(@PathVariable("userId") Integer userId)
	{
		List<Expense> expenses = new ArrayList<Expense>();
		try {
			expenses = this.expenseService.getAllExpenses(userId);
		} catch (ExpenseServiceException e) {
			expenses = null;
		}
		return expenses;
	}
}
