package com.mindtree.easybucks.signup.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="advisor_requests")
public class AdvisorRequests 
{
	@Id
	@Column(name="advisor_requests")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int advisorRequestId;
	
	@Column(name="email")
	private String email;
	
	@Column(name="status")
	private String status;

	public AdvisorRequests() {
		super();
		
	}

	public int getAdvisorRequestId() {
		return advisorRequestId;
	}

	public void setAdvisorRequestId(int advisorRequestId) {
		this.advisorRequestId = advisorRequestId;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	

	
	
	
}
