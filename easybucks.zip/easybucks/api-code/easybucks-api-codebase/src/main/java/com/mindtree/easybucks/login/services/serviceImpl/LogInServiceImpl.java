package com.mindtree.easybucks.login.services.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.easybucks.login.dao.LogInDao;
import com.mindtree.easybucks.login.dto.LogInResponse;
import com.mindtree.easybucks.login.dto.NewPassword;
import com.mindtree.easybucks.login.exceptions.daoexceptions.LogInDaoImplException;
import com.mindtree.easybucks.login.exceptions.serviceexceptions.LogInServiceImplException;
import com.mindtree.easybucks.login.services.LogInService;
import com.mindtree.easybucks.signup.entity.User;

@Service
public class LogInServiceImpl implements LogInService {
	
	@Autowired
	private LogInDao logInDao;

	public LogInDao getLogInDao() {
		return logInDao;
	}

	public void setLogInDao(LogInDao logInDao) {
		this.logInDao = logInDao;
	}

	public LogInResponse authentication(User logUser){
		
		String userEmail = logUser.getUserEmail().toLowerCase();
		User dbUser;
		LogInResponse response = new LogInResponse();
		try{
			dbUser = logInDao.getUserByEmail(userEmail);
		}catch(LogInDaoImplException logDaoException){
			response.setResponse("User Not Registered");
			return response;
		}
		
		if(dbUser.getUserPassword().equals(logUser.getUserPassword())){
				response.setResponse("Success");
				response.setUser(dbUser);
			}
			else{
				response.setResponse("Password Incorrect");
			}		
		return response;
	}
	
	public int changePassword( NewPassword newPassword) throws LogInServiceImplException{
		
		String email = newPassword.getEmail().toLowerCase();
		User user;
		try{
			user = logInDao.getUserByEmail(email);
		}
		catch(LogInDaoImplException logDaoException){
			throw new LogInServiceImplException("cannot change password error in service", logDaoException.getCause());
		}

		user.setUserPassword(newPassword.getNewPassword());
		
		try{
			logInDao.updatePassword(user);
			return 1;
		}
		catch(LogInDaoImplException logDaoException){
			throw new LogInServiceImplException("error in updating password", logDaoException.getCause());
		}
		
	}

}





