package com.mindtree.easybucks.portfolio.dao.daoimpl;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.mindtree.easybucks.portfolio.dao.MFPortfolioDao;
import com.mindtree.easybucks.portfolio.entity.MFPortfolio;
import com.mindtree.easybucks.portfolio.exception.daoexception.MFPortfolioDaoException;

@Repository
@Transactional("transactionManager")
public class MFPortfolioDaoImpl implements MFPortfolioDao {
	
	@Autowired
	private SessionFactory sessionFactory;
	
	public Session getSession(){
		return sessionFactory.getCurrentSession();
	}

	public MFPortfolio getMFPortfolioById(int mfPortId) throws MFPortfolioDaoException {
		try{
			return getSession().get(MFPortfolio.class, new Integer(mfPortId));
		}
		catch(HibernateException e){
			throw new MFPortfolioDaoException("Error in getting MF Portfolio in Mf Dao", e.getCause());
		}
	}

	public boolean deleteMFPortfolioById(int mfPortId) throws MFPortfolioDaoException {
		try{
			MFPortfolio mfPort = getMFPortfolioById(mfPortId);
			getSession().delete(mfPort);
			return true;
		}
		catch(HibernateException e){
			throw new MFPortfolioDaoException("Error in deleting MF Portfolio in Mf Dao", e.getCause());
		}
	}
	
}






