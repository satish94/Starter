package com.mindtree.easybucks.seekassistance.dto;

public class SeekAssistanceDTO 
{
	private int investor;
	private int advisor;
	private String query;
	private String answer;
	private String status;
	public SeekAssistanceDTO() {
		super();
		
	}
	@Override
	public String toString() {
		return "SeekAssistanceDTO [investor=" + investor + ", advisor=" + advisor + ", query=" + query + ", answer="
				+ answer + ", status=" + status + "]";
	}
	public int getInvestor() {
		return investor;
	}
	public void setInvestor(int investor) {
		this.investor = investor;
	}
	public int getAdvisor() {
		return advisor;
	}
	public void setAdvisor(int advisor) {
		this.advisor = advisor;
	}
	public String getQuery() {
		return query;
	}
	public void setQuery(String query) {
		this.query = query;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
	
}
