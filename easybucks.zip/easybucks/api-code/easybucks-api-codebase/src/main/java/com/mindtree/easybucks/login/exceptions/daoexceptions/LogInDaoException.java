package com.mindtree.easybucks.login.exceptions.daoexceptions;

import com.mindtree.easybucks.login.exceptions.LoginException;

public class LogInDaoException extends LoginException {

	private static final long serialVersionUID = 1L;

	public LogInDaoException() {
		super();
	}

	public LogInDaoException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
