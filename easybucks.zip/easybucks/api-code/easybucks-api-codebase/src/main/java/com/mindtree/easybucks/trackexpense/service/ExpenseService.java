package com.mindtree.easybucks.trackexpense.service;

import java.util.List;

import com.mindtree.easybucks.trackexpense.entities.Expense;
import com.mindtree.easybucks.trackexpense.exception.serviceexception.ExpenseServiceException;

public interface ExpenseService {
	
	public boolean addExpense(Expense expense) throws ExpenseServiceException ;
	public boolean deleteExpense(Expense expense) throws ExpenseServiceException;
	public Expense updateExpense(Expense expense) throws ExpenseServiceException ;
	public Expense getExpenseById(int id) throws ExpenseServiceException;
	public List<Expense> getAllExpenses(int userId) throws ExpenseServiceException;

}
