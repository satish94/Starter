package com.mindtree.easybucks.watchlist.services.stockmarketservice;

import java.util.List;
import java.util.Set;
import com.mindtree.easybucks.products.entities.Stocks;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.watchlist.exception.serviceexception.WatchlistServiceException;

public interface StockWatchlistService {
	
	public boolean addToStockWatchlist(User user,Stocks stock) throws WatchlistServiceException;
	public boolean deleteFromStockWatchlist(User user, Stocks stock ) throws WatchlistServiceException;
	public List<Stocks> getStockWatchlistByUser(User user) throws WatchlistServiceException;
	public Set<Stocks> getStockWatchlistByUser1(User user) throws WatchlistServiceException;

}
