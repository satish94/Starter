package com.mindtree.easybucks.portfolio.exception.daoexception;

import com.mindtree.easybucks.portfolio.exception.PortfolioException;

public class StocksPortfolioDaoException extends PortfolioException {

	private static final long serialVersionUID = 1L;

	public StocksPortfolioDaoException() {
		super();
	}

	public StocksPortfolioDaoException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}
	
	

}
