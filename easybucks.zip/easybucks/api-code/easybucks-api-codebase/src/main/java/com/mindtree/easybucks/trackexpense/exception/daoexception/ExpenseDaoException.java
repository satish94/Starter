package com.mindtree.easybucks.trackexpense.exception.daoexception;

import com.mindtree.easybucks.trackexpense.exception.ExpenseException;

public class ExpenseDaoException extends ExpenseException{

	private static final long serialVersionUID = 1L;

	public ExpenseDaoException() {
		super();
	}

	public ExpenseDaoException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

	
	
}
