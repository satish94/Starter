package com.mindtree.easybucks.login.services;

import com.mindtree.easybucks.login.dto.LogInResponse;
import com.mindtree.easybucks.login.dto.NewPassword;
import com.mindtree.easybucks.login.exceptions.serviceexceptions.LogInServiceImplException;
import com.mindtree.easybucks.signup.entity.User;

public interface LogInService {
	
	public LogInResponse authentication(User user);
	
	public int changePassword(NewPassword newPassword) throws LogInServiceImplException;

}
