package com.mindtree.easybucks.watchlist.services.bullionservice;

import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.easybucks.products.entities.Bullions;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.watchlist.dao.bullion.BullionWatchlistDao;
import com.mindtree.easybucks.watchlist.exception.daoexception.WatchlistDaoException;
import com.mindtree.easybucks.watchlist.exception.serviceexception.WatchlistServiceException;

@Service
public class BullionWatchlistServiceImp implements BullionWatchlistService {

	@Autowired
	private BullionWatchlistDao bullionWatchlistDao;
	

	public boolean addToBullionWatchlist(User user, Bullions bullion) throws WatchlistServiceException {
		try {
			return bullionWatchlistDao.addToBullionWatchlist(user, bullion);
		} catch (WatchlistDaoException e) {
			throw new WatchlistServiceException("Unable to add data from service",e) ;
		}
	}

	public boolean deleteFromBullionWatchlist(User user, Bullions bullion) throws WatchlistServiceException {
		try {
			return bullionWatchlistDao.deleteFromBullionWatchlist(user, bullion);
		} catch (WatchlistDaoException e) {
			throw new WatchlistServiceException("Unable to delete data from service",e) ;
		}
	}
	public List<Bullions> getBullionWatchlistByUser(User user) throws WatchlistServiceException {
		try {
			return bullionWatchlistDao.getBullionWatchlistByUser(user);
		} catch (WatchlistDaoException e) {
			throw new WatchlistServiceException("Unable to get data from service",e) ;
		}
	}
	
	public Set<Bullions> getBullionWatchlistByUser1(User user) throws WatchlistServiceException {
		try {
			return bullionWatchlistDao.getBullionWatchlistByUser1(user);
		} catch (WatchlistDaoException e) {
			throw new WatchlistServiceException("Unable to get data from service",e) ;
		}
	}

}
