package com.mindtree.easybucks.portfolio.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.easybucks.portfolio.dao.MFPortfolioDao;
import com.mindtree.easybucks.portfolio.dao.PortfolioDao;
import com.mindtree.easybucks.portfolio.entity.MFPortfolio;
import com.mindtree.easybucks.portfolio.entity.Portfolio;
import com.mindtree.easybucks.portfolio.exception.daoexception.MFPortfolioDaoException;
import com.mindtree.easybucks.portfolio.exception.daoexception.PortfolioDaoException;
import com.mindtree.easybucks.portfolio.exception.serviceexception.MFPortfolioServiceException;
import com.mindtree.easybucks.portfolio.service.MFPortfolioService;
import com.mindtree.easybucks.products.entities.MutualFunds;
import com.mindtree.easybucks.products.exceptions.serviceexceptions.ProductsServiceException;
import com.mindtree.easybucks.products.service.MutualFundsService;
import com.mindtree.easybucks.signup.service.EasyService.UserService;

@Service
public class MFPortfolioServiceImpl implements MFPortfolioService {
	
	@Autowired
	private PortfolioDao portfolioDao;
	
	@Autowired
	private MutualFundsService mfServ;
	
	@Autowired
	private UserService userServ;
	
	@Autowired
	private MFPortfolioDao mfPortDao;
	

	public MFPortfolio getMFPortfolio(int prodId, int quantity) throws MFPortfolioServiceException {
		
		MFPortfolio mfPort = new MFPortfolio();
		MutualFunds mfProd;
		
		try{
			mfProd = mfServ.getMutualFunds(prodId);
		}
		catch(ProductsServiceException e){
			throw new MFPortfolioServiceException("Error in getting products in MF service", e.getCause());
		}
		
		mfPort.setMfProd(mfProd);
		mfPort.setPurchasePrice(mfProd.getSalePrice());
		mfPort.setPurNAV(mfProd.getNetAssetValue());
		mfPort.setQuantity(quantity);
		
		return mfPort;
	}

	public boolean addMFPortfolioByUserId(int prodId, int userId, int quantity) throws MFPortfolioServiceException {
		
		Portfolio portfolio = new Portfolio();
		
		try{
			portfolio = portfolioDao.getPortfolioByUserId(userId);
		}
		catch(PortfolioDaoException e){
			
			try{
				portfolio.setUser(userServ.getUserById(userId));
				portfolioDao.addToPortfolio(portfolio);
			}
			catch(PortfolioDaoException ex)
			{
				throw new MFPortfolioServiceException("Error in getting portfolio by userId in MF service", ex.getCause());
			}
		}
		
		List<MFPortfolio> mfPortList = portfolio.getMfPort();
		
		try{
			mfPortList.add(getMFPortfolio(prodId, quantity));
		}
		catch(MFPortfolioServiceException e){
			throw e;
		}
		catch(NullPointerException e){
			mfPortList = new ArrayList<MFPortfolio>();
			mfPortList.add(getMFPortfolio(prodId,quantity));
		}
		portfolio.setMfPort(mfPortList);
		
		try{
			return portfolioDao.updatePortfolio(portfolio);
		}
		catch(PortfolioDaoException e){
			throw new MFPortfolioServiceException("Error in updating portfolio in MF Service", e.getCause());
		}
	}

	public boolean deleteMFPortfolioByUserId(int mfPortId, int userId) throws MFPortfolioServiceException {
		
		Portfolio portfolio;
		
		try{
			portfolio = portfolioDao.getPortfolioByUserId(userId);
		}
		catch(PortfolioDaoException e){
			throw new MFPortfolioServiceException("Error in getting portfolio in MF Service", e.getCause());
		}
		
		List<MFPortfolio> mfPortList = portfolio.getMfPort();
		

		for(int i = 0; i<mfPortList.size();i++){
			MFPortfolio mfPort = mfPortList.get(i);
			if(mfPort.getMfPortId() == mfPortId){
				mfPortList.remove(mfPort);
				i--;
			}
		}
		
		portfolio.setMfPort(mfPortList);
		
		try{
			portfolioDao.updatePortfolio(portfolio);
		}
		catch(PortfolioDaoException e){
			throw new MFPortfolioServiceException("Error in updating Portfolio", e.getCause());
		}
		
		try{
			return mfPortDao.deleteMFPortfolioById(mfPortId);
		}
		catch(MFPortfolioDaoException e){
			throw new MFPortfolioServiceException("Error in deleting StocksPortfolio", e.getCause());
		}
		
		
	}

	public List<MFPortfolio> getMFPortfolioByUserId(int userId) throws MFPortfolioServiceException {
		try{
			Portfolio portfolio = portfolioDao.getPortfolioByUserId(userId);
			return portfolio.getMfPort();
		}
		catch(PortfolioDaoException e){
			throw new MFPortfolioServiceException ("Error in getting portfolio by id in MF Service",e.getCause());
		}
	}


}
