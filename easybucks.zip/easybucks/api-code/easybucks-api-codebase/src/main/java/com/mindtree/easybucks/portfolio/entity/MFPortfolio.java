package com.mindtree.easybucks.portfolio.entity;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.mindtree.easybucks.products.entities.MutualFunds;

@Entity
@Table(name = "mf_portfolio")
public class MFPortfolio {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "mf_port_id")
	private int mfPortId;
	
	@ManyToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "mf_prod_id")
	private MutualFunds mfProd;
	
	@Column(name = "purchase_price")
	private double purchasePrice;
	
	@Column
	private int quantity;
	
	@Column(name = "maturity_value")
	private int maturityValue;
	
	@Column(name = "pur_nav")
	private double purNAV;

	public int getMfPortId() {
		return mfPortId;
	}

	public void setMfPortId(int mfPortId) {
		this.mfPortId = mfPortId;
	}

	public MutualFunds getMfProd() {
		return mfProd;
	}

	public void setMfProd(MutualFunds mfProd) {
		this.mfProd = mfProd;
	}

	public double getPurchasePrice() {
		return purchasePrice;
	}

	public void setPurchasePrice(double purchasePrice) {
		this.purchasePrice = purchasePrice;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public int getMaturityValue() {
		return maturityValue;
	}

	public void setMaturityValue(int maturityValue) {
		this.maturityValue = maturityValue;
	}

	public double getPurNAV() {
		return purNAV;
	}

	public void setPurNAV(double purNAV) {
		this.purNAV = purNAV;
	}

	@Override
	public String toString() {
		return "MFPortfolio [mfPortId=" + mfPortId + ", mfProd=" + mfProd + ", purchasePrice=" + purchasePrice
				+ ", quantity=" + quantity + ", maturityValue=" + maturityValue + ", purNAV=" + purNAV + "]";
	}
	
	
}





