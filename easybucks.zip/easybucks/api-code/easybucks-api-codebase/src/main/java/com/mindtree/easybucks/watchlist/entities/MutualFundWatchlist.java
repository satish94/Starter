package com.mindtree.easybucks.watchlist.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

import com.mindtree.easybucks.products.entities.MutualFunds;
import com.mindtree.easybucks.signup.entity.User;

@Entity
@Table(name="mutualfundwatchlist")
public class MutualFundWatchlist {

	@Id
	@GeneratedValue(generator = "increment")
	@GenericGenerator(name = "increment", strategy = "increment")
	private int mutualFundWatchlistId;
	@OneToOne
	@JoinColumn(name="userId")
	private User user;
	@ManyToMany
	private Set<MutualFunds> mutualFundsList = new HashSet<MutualFunds>(0);
	
	public MutualFundWatchlist() {
		super();
	}
	
	
	public MutualFundWatchlist(int mutualFundWatchlistId, User user, Set<MutualFunds> mutualFundsList) {
		super();
		this.mutualFundWatchlistId = mutualFundWatchlistId;
		this.user = user;
		this.mutualFundsList = mutualFundsList;
	}
	
	


	public int getMutualFundWatchlistId() {
		return mutualFundWatchlistId;
	}


	public void setMutualFundWatchlistId(int mutualFundWatchlistId) {
		this.mutualFundWatchlistId = mutualFundWatchlistId;
	}


	public User getUser() {
		return user;
	}


	public void setUser(User user) {
		this.user = user;
	}


	public Set<MutualFunds> getMutualFundsList() {
		return mutualFundsList;
	}


	public void setMutualFundsList(Set<MutualFunds> mutualFundsList) {
		this.mutualFundsList = mutualFundsList;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + mutualFundWatchlistId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MutualFundWatchlist other = (MutualFundWatchlist) obj;
		if (mutualFundWatchlistId != other.mutualFundWatchlistId)
			return false;
		return true;
	}
	
	
	
	
	
}
