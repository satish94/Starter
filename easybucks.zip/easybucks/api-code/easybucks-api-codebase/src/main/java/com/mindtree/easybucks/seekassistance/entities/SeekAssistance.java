package com.mindtree.easybucks.seekassistance.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="seek_assistance")
public class SeekAssistance 
{
	@Id
	@Column(name="seek_assistance_id")
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int seekAssistanceId;
	
	@Column(name="investor_id")
	private int investorId;
	
	@Column(name="advisor_id")
	private int advisorId;
	
	@Column(name="query")
	private String query;
	
	@Column(name="answer")
	private String answer;
	
	@Column(name="status")
	private String status;

	public SeekAssistance() {
		super();
	}

	@Override
	public String toString() {
		return "SeekAssistance [seekAssistanceId=" + seekAssistanceId + ", investor=" + investorId + ", advisor="
				+ advisorId + ", query=" + query + ", answer=" + answer + ", status=" + status + "]";
	}

	public int getSeekAssistanceId() {
		return seekAssistanceId;
	}

	public void setSeekAssistanceId(int seekAssistanceId) {
		this.seekAssistanceId = seekAssistanceId;
	}

	public int getInvestorId() {
		return investorId;
	}

	public void setInvestorId(int investorId) {
		this.investorId = investorId;
	}

	public int getAdvisorId() {
		return advisorId;
	}

	public void setAdvisorId(int advisorId) {
		this.advisorId = advisorId;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	

	

	
	
	
	
	
}
