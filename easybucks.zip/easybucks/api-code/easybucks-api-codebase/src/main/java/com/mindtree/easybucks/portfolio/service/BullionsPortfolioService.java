package com.mindtree.easybucks.portfolio.service;

import java.util.List;

import com.mindtree.easybucks.portfolio.entity.BullionsPortfolio;
import com.mindtree.easybucks.portfolio.exception.serviceexception.BullionsPortfolioServiceException;

public interface BullionsPortfolioService {
	
	public BullionsPortfolio getBullionsPortfolio(int prodId, int quantity) throws BullionsPortfolioServiceException;
	
	public boolean addBullionsPortfolioByUserId(int prodId, int userId, int quantity) throws BullionsPortfolioServiceException;
	
	public boolean deleteBullionsPortfolioByUserId(int bullionsPortId, int userId) throws BullionsPortfolioServiceException;
	
	public List<BullionsPortfolio> getBullionsPortfolioByUserId(int userId) throws BullionsPortfolioServiceException;

}
