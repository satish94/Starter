package com.mindtree.easybucks.portfolio.service;

import java.util.List;

import com.mindtree.easybucks.portfolio.entity.BankingPortfolio;
import com.mindtree.easybucks.portfolio.exception.serviceexception.BankingPortfolioServiceException;

public interface BankingPortfolioService {
	
	public BankingPortfolio getBankingPortfolio(int prodId,int noOfMonths, double amount) throws BankingPortfolioServiceException;
	
	public boolean addBankingPortfolioByUserId(int prodId, int userId,int noOfMonths,double amount) throws BankingPortfolioServiceException;
	
	public boolean deleteBankingPortfolioByUserId(int BankingPortId, int userId) throws BankingPortfolioServiceException;
	
	public List<BankingPortfolio> getPortfolioByUserId(int userId) throws BankingPortfolioServiceException;

}
