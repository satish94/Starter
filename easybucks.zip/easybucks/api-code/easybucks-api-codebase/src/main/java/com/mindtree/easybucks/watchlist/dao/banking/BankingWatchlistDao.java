package com.mindtree.easybucks.watchlist.dao.banking;

import java.util.List;
import java.util.Set;

import com.mindtree.easybucks.products.entities.Banking;
import com.mindtree.easybucks.signup.entity.User;
import com.mindtree.easybucks.watchlist.exception.daoexception.WatchlistDaoException;

public interface BankingWatchlistDao {
	
	public boolean addToBankingWatchlist(User user,Banking bank) throws WatchlistDaoException;
	public boolean deleteFromBankingWatchlist(User user,Banking bank) throws WatchlistDaoException;
	public List<Banking> getBankingWatchlistByUser(User user) throws WatchlistDaoException;
	public Set<Banking> getBankingWatchlistByUser1(User user) throws WatchlistDaoException;

}
