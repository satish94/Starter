package com.mindtree.easybucks.portfolio.service.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.easybucks.portfolio.dao.PortfolioDao;
import com.mindtree.easybucks.portfolio.dao.StocksPortfolioDao;
import com.mindtree.easybucks.portfolio.entity.Portfolio;
import com.mindtree.easybucks.portfolio.entity.StocksPortfolio;
import com.mindtree.easybucks.portfolio.exception.daoexception.PortfolioDaoException;
import com.mindtree.easybucks.portfolio.exception.daoexception.StocksPortfolioDaoException;
import com.mindtree.easybucks.portfolio.exception.serviceexception.StocksPortfolioServiceException;
import com.mindtree.easybucks.portfolio.service.StocksPortfolioService;
import com.mindtree.easybucks.products.entities.Stocks;
import com.mindtree.easybucks.products.exceptions.serviceexceptions.ProductsServiceException;
import com.mindtree.easybucks.products.service.StocksService;
import com.mindtree.easybucks.signup.service.EasyService.UserService;

@Service
public class StocksPortfolioServiceImpl implements StocksPortfolioService {
	
	@Autowired
	private PortfolioDao portfolioDao;
	
	@Autowired
	private StocksService stocksService;
	
	@Autowired
	private UserService userServ;
	
	@Autowired
	private StocksPortfolioDao stocksPortDao;

	public StocksPortfolio getStocksPortfolio(int prodId,int noOfStocks) throws StocksPortfolioServiceException{
		
		StocksPortfolio stocksPortfolio = new StocksPortfolio();
		Stocks stocks ;
		try{
			stocks= stocksService.getStocks(prodId);
		}
		catch(ProductsServiceException e){
			throw new StocksPortfolioServiceException("Error in get products in Stocks Service", e.getCause());
		}
		
		stocksPortfolio.setNoOfShares(noOfStocks);
		stocksPortfolio.setStocksProd(stocks);
		stocksPortfolio.setPurchasePrice(stocks.getCurrTradingPrice());
		
		return stocksPortfolio;
		
	}

	public boolean addStocksPortfolioByUserId(int prodId, int userId, int noOfStocks)
			throws StocksPortfolioServiceException {
		Portfolio portfolio = new Portfolio();
		try{
			portfolio = portfolioDao.getPortfolioByUserId(userId);
		}
		catch(PortfolioDaoException e){
			try{
				portfolio.setUser(userServ.getUserById(userId));
				portfolioDao.addToPortfolio(portfolio);
			}
			catch(PortfolioDaoException ex){
				throw new StocksPortfolioServiceException("Error in adding portfolio in Stocks Service", ex.getCause());
			}
		}
		
		List<StocksPortfolio> stocksPortList = portfolio.getStocksPort();
		try{
			stocksPortList.add(getStocksPortfolio(prodId, noOfStocks));
		}
		catch(StocksPortfolioServiceException e){
			throw e;
		}
		catch(NullPointerException e){
			stocksPortList = new ArrayList<StocksPortfolio>();
			stocksPortList.add(getStocksPortfolio(prodId,noOfStocks));
		}
		portfolio.setStocksPort(stocksPortList);
		
		try{
			return portfolioDao.updatePortfolio(portfolio);
		}
		catch(PortfolioDaoException e){
			throw new StocksPortfolioServiceException("Error in updating portfolio in stocks Service", e.getCause());
		}
		catch(Exception e){
			throw new StocksPortfolioServiceException("Error in updating portfolio in stocks Service", e.getCause());
		}
	}

	public boolean deleteStocksPortfolioByUserId(int stocksPortId, int userId)
			throws StocksPortfolioServiceException {
		Portfolio portfolio;
		try{
			portfolio = portfolioDao.getPortfolioByUserId(userId);
		}
		catch(PortfolioDaoException e){
			throw new StocksPortfolioServiceException("Error in getting portfolio in stocks Service", e.getCause());
		}
		List<StocksPortfolio> stockPortList = portfolio.getStocksPort();
		
		for(int i = 0; i<stockPortList.size();i++){
			StocksPortfolio stockPort = stockPortList.get(i);
			if(stockPort.getStocksPortId() == stocksPortId){
				stockPortList.remove(stockPort);
				i--;
			}
		}
		portfolio.setStocksPort(stockPortList);
		
		try{
			 portfolioDao.updatePortfolio(portfolio);
		}
		catch(PortfolioDaoException e){
			throw new StocksPortfolioServiceException("Error in updating portfolio in Stocks Service", e.getCause());
		}

		try{
			return stocksPortDao.deleteStocksPortfolioById(stocksPortId);
		}
		catch(StocksPortfolioDaoException e){
			throw new StocksPortfolioServiceException("Error in deleting StocksPortfolio", e.getCause());
		}
		
	}

	public List<StocksPortfolio> getStocksPortfolioByuserId(int userId) throws StocksPortfolioServiceException {
		try{
			Portfolio portfolio = portfolioDao.getPortfolioByUserId(userId);
			return portfolio.getStocksPort();
		}
		catch(PortfolioDaoException e){
			throw new StocksPortfolioServiceException("Error in getting portfolio in Stocks Service", e.getCause());
		}
	}
	
	

}





