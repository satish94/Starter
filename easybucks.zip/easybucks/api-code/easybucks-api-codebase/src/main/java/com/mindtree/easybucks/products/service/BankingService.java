package com.mindtree.easybucks.products.service;

import java.util.List;

import com.mindtree.easybucks.products.entities.Banking;
import com.mindtree.easybucks.products.exceptions.serviceexceptions.ProductsServiceException;

public interface BankingService {
	
	String addBanking(Banking banking) throws ProductsServiceException ;
	List<Banking> getAllBanking() throws ProductsServiceException ;
	Banking getBanking(int id) throws ProductsServiceException ;
	String deleteBanking(int id) throws ProductsServiceException ;
}
