package com.mindtree.easybucks.products.exceptions.serviceexceptions ;

import com.mindtree.easybucks.products.exceptions.ProductsExceptions;

public class ProductsServiceException extends ProductsExceptions{

	private static final long serialVersionUID = 1L;

	public ProductsServiceException() {
		super();
	}
	public ProductsServiceException(String arg0, Throwable arg1) {
		super(arg0,arg1);
	}
}
